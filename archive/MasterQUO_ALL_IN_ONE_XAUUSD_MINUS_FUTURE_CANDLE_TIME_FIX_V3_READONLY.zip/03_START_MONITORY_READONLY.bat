@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
echo MASTERQUO CANDIDATE - READONLY - DEMO - NO ORDERS - TELEGRAM OFF.
if not exist "%~dp0.venv\Scripts\python.exe" goto INSTALL_FIRST
if not exist "%~dp001_PROGRAM_GLOWNY_10_ULEPSZEN\M00U_RUNTIME.py" goto MISSING_CODE
"%~dp0.venv\Scripts\python.exe" -c "import MetaTrader5,numpy"
if errorlevel 1 goto INSTALL_FIRST
start "MasterQUO M00U Supervisor" "%~dp003A_RUN_M00U.bat"
start "MasterQUO MT5 Diagnostics" "%~dp003B_RUN_MT5_ADAPTER.bat"
start "MasterQUO Readonly Viewer" "%~dp003C_RUN_VIEWER.bat"
echo Uruchomiono 3 procesy w osobnych oknach; Ctrl+C zatrzymuje adapter i viewer.
echo Upewnij sie, ze terminal MT5 jest zalogowany na DEMO i symbol XAUUSD- istnieje.
pause
exit /b 0
:INSTALL_FIRST
echo [BLAD] Najpierw uruchom 01_INSTALUJ_ZALEZNOSCI.bat.
pause
exit /b 1
:MISSING_CODE
echo [BLAD] Brak plikow programu. Rozpakuj caly ZIP do nowego folderu.
pause
exit /b 1
