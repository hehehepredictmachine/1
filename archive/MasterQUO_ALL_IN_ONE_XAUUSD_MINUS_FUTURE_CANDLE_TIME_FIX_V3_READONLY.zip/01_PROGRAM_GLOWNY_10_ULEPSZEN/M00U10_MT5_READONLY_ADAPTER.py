#!/usr/bin/env python3
"""Optional Windows MT5 -> evidence -> all ten modules. No order_send, no screenshots.

Only the trading terminal's currently accessible historical bars are used.
Quote and instrument currency economics are not guessed; economics are passed in by
an explicitly reviewed research JSON file. This remains a diagnostic pipeline.
"""
from __future__ import annotations
import argparse,json,pathlib,time,sys
from datetime import datetime,timezone
from RUN_UPGRADES_READONLY import run_all
from mq_upgrades.common import safe_json,when

ROOT=pathlib.Path(__file__).resolve().parent
TF={'D1':'TIMEFRAME_D1','H4':'TIMEFRAME_H4','H1':'TIMEFRAME_H1',
    'M15':'TIMEFRAME_M15','M5':'TIMEFRAME_M5','M1':'TIMEFRAME_M1'}

def stamp_epoch(value):
    return datetime.fromtimestamp(int(value), timezone.utc).isoformat().replace('+00:00', 'Z')


def _now_epoch(as_of=None):
    as_of = as_of or datetime.now(timezone.utc)
    if as_of.tzinfo is None:
        raise ValueError('AS_OF_MUST_BE_TIMEZONE_AWARE')
    return as_of.timestamp()


def closed_bars(mt5, symbol, tf, count, as_of=None, quality=None):
    """Only use bars for which the next *observed* opening is not in the future.

    Never infer that the current terminal bar is closed. A future open from the
    broker or a clock discrepancy cannot act as proof of availability. Retain
    sufficient earlier candles; NEVER rewrite server timestamps or backdate bars.
    """
    if tf not in TF or not 1 <= count <= 2000:
        raise ValueError('INVALID_TIMEFRAME_OR_HISTORY_COUNT')
    flag = getattr(mt5, TF[tf])
    # Buffer lets us exclude unconfirmed future/extra bars without losing history.
    raw = mt5.copy_rates_from_pos(symbol, flag, 0, count + 16)
    if raw is None or len(raw) < count + 1:
        raise ValueError(f'INSUFFICIENT_MT5_HISTORY:{tf}:required={count+1}:received={0 if raw is None else len(raw)}')
    seq = sorted((int(x['time']), x) for x in raw)
    if len({t for t, _ in seq}) != len(seq):
        raise ValueError('DUPLICATE_MT5_BARS:' + tf)
    asof = _now_epoch(as_of)
    # A bar is confirmed only if the actual next bar is observed AND its open
    # occurred no later than our UTC as-of; never use a scheduled future close.
    eligible = []
    future_unconfirmed = []
    for i in range(len(seq) - 1):
        sec, x = seq[i]
        next_sec = seq[i+1][0]
        if next_sec <= sec:
            raise ValueError('NON_MONOTONIC_MT5_BARS:' + tf)
        if next_sec > asof:
            future_unconfirmed.append(next_sec)
            continue
        o, h, l, c = (float(x[k]) for k in ('open', 'high', 'low', 'close'))
        import math
        if not all(math.isfinite(v) and v > 0 for v in (o, h, l, c)) or not l <= min(o, c) <= max(o, c) <= h:
            raise ValueError('INVALID_MT5_OHLC:' + tf)
        tv = int(x['tick_volume'])
        if tv < 0:
            raise ValueError('INVALID_MT5_TICK_VOLUME:' + tf)
        eligible.append({'time': stamp_epoch(sec), 'available_at': stamp_epoch(next_sec),
                         'open': o, 'high': h, 'low': l, 'close': c,
                         'tick_volume': tv, 'closed': True, 'source': 'MT5'})
    if quality is not None:
        quality.update({'timeframe': tf, 'raw_bars': len(seq),
                        'excluded_unconfirmed': len(future_unconfirmed),
                        'current_bar_open_raw_utc': stamp_epoch(seq[-1][0]),
                        'current_bar_open_ahead_seconds': round(max(0,seq[-1][0]-asof),3),
                        'last_verified_available_at':eligible[-1]['available_at'] if eligible else None,
                        'last_verified_age_seconds':round(asof - _now_epoch(datetime.fromisoformat(eligible[-1]['available_at'].replace('Z','+00:00'))),3) if eligible else None})
    if len(eligible) < count:
        raise ValueError(f'INSUFFICIENT_VERIFIED_CLOSED_BARS:{tf}:verified={len(eligible)}:required={count}:check_broker_clock')
    return eligible[-count:]


def clock_diagnostics(mt5, symbol, as_of=None):
    """Read-only clock evidence; does not guess or silently fix UTC offsets."""
    as_of=as_of or datetime.now(timezone.utc)
    ts=_now_epoch(as_of)
    result={'symbol':symbol, 'utc_now':stamp_epoch(ts), 'timeframes':{},
            'execution_permission':'BLOCKED', 'timestamp_correction_applied':False}
    if not mt5.symbol_select(symbol,True):
        return dict(result, status='SYMBOL_NOT_AVAILABLE')
    tick=mt5.symbol_info_tick(symbol)
    if tick is None:
        result['tick_status']='MT5_QUOTE_UNAVAILABLE'
    else:
        skew=float(tick.time)-ts
        result['tick_status']='AHEAD_OF_UTC' if skew > 60 else ('STALE' if skew < -120 else 'TIME_NEAR_UTC')
        result['tick_raw_utc']=stamp_epoch(tick.time)
        result['tick_delta_seconds']=round(skew,2)
    for tf in TF:
        raw=mt5.copy_rates_from_pos(symbol,getattr(mt5,TF[tf]),0,4)
        if raw is None or len(raw)<2:
            result['timeframes'][tf]={'status':'NO_HISTORY','received':0 if raw is None else len(raw)}
            continue
        opens=sorted(int(x['time']) for x in raw)
        result['timeframes'][tf]={
            'open_times_raw_utc':[stamp_epoch(x) for x in opens],
            'newest_bar_ahead_seconds':round(opens[-1]-ts,2),
            'future_open_count':sum(x>ts for x in opens),
            'last_observable_next_open_raw_utc':stamp_epoch(opens[-2]),
        }
    return result


def from_mt5(mt5,symbol='XAUUSD-',dxy_symbol=None,count=90,economics=None,supervisor=None,as_of=None):
    now=as_of or datetime.now(timezone.utc)
    if now.tzinfo is None:raise ValueError('AS_OF_MUST_BE_TIMEZONE_AWARE')
    if not mt5.symbol_select(symbol,True):raise ValueError('SYMBOL_NOT_AVAILABLE:'+symbol)
    quality={}
    rates={}
    for tf in TF:
        d={}
        rates[tf]=closed_bars(mt5,symbol,tf,count,as_of=now,quality=d)
        quality[tf]=d
    tk=mt5.symbol_info_tick(symbol)
    if tk is None:raise ValueError('MT5_QUOTE_UNAVAILABLE')
    ahead=float(tk.time)-now.timestamp()
    # A future broker tick is *not* a verified live quote; fail closed with
    # a clear diagnostic instead of blindly subtracting a guessed offset.
    if ahead>60:
        raise ValueError(f'BROKER_TICK_AHEAD_OF_UTC:seconds={round(ahead,1)}:run_06_DIAGNOZA_CZASU_MT5')
    quote={'time':stamp_epoch(tk.time),'bid':float(tk.bid),'ask':float(tk.ask)}
    cross={'XAUUSD':[{'time':bar['available_at'],'close':bar['close']} for bar in rates['H1']]}
    if dxy_symbol:
        if mt5.symbol_select(dxy_symbol,True):
            try:cross['DXY']=[{'time':bar['available_at'],'close':bar['close']}
                              for bar in closed_bars(mt5,dxy_symbol,'H1',count,as_of=now)]
            except (ValueError,TypeError):pass
    if supervisor is None or not isinstance(supervisor,dict):
        supervisor={'system_state':'MISSING'}
    timing_warning=any(x['current_bar_open_ahead_seconds']>60 for x in quality.values())
    return {'as_of':now.isoformat().replace('+00:00','Z'),'bars':rates,
            'quote':quote,'cross_market':cross,'economics':economics or {},
            'runtime':supervisor,'side':'LONG','technical_decision':'WAIT',
            'orders_enabled':False,'telegram_enabled':False,
            'source':'MT5_TERMINAL_READ_ONLY','macro_events':[],
            'mt5_bar_clock_diagnostics':quality,
            'time_alignment_status':'WARNING_BROKER_CLOCK_CHECK' if timing_warning else 'OBSERVED_NEXT_OPEN_PROOF'}

def run_cli(argv=None):
    ap=argparse.ArgumentParser(description='Read-only MT5 10-stage diagnostics (Windows)')
    ap.add_argument('--symbol',default='XAUUSD-');ap.add_argument('--dxy-symbol')
    ap.add_argument('--diagnose-clock',action='store_true',help='Show raw MT5 tick and candle timestamps; do not run analysis')
    ap.add_argument('--bars',type=int,default=90);ap.add_argument('--once',action='store_true')
    ap.add_argument('--every-seconds',type=int,default=15)
    ap.add_argument('--economics-json')
    ap.add_argument('--output',default=str(ROOT/'runtime'/'M00U10_MT5_REPORT.json'))
    args=ap.parse_args(argv)
    if not 40<=args.bars<=2000 or not 5<=args.every_seconds<=3600:
        ap.error('Invalid bars or interval')
    econ={}
    if args.economics_json:
        econ=json.loads(pathlib.Path(args.economics_json).read_text(encoding='utf-8'))
        if not isinstance(econ,dict):ap.error('Economics must be JSON object')
    try:import MetaTrader5 as mt5
    except ImportError:
        print('Install MetaTrader5 on Windows; offline environment cannot connect',file=sys.stderr)
        return 2
    if not mt5.initialize():
        print('MT5 connection failed:',mt5.last_error(),file=sys.stderr);return 3
    try:
        if args.diagnose_clock:
            print(json.dumps(clock_diagnostics(mt5,args.symbol),ensure_ascii=False,indent=2),flush=True)
            return 0
        while True:
            try:
                health=ROOT/'runtime'/'M00U_SAFE_MONITOR.json'
                sup=json.loads(health.read_text(encoding='utf-8')) if health.exists() else {'system_state':'MISSING'}
                sample=from_mt5(mt5,args.symbol,args.dxy_symbol,args.bars,econ,sup)
                report=run_all(sample)
                report['mt5_bar_clock_diagnostics']=sample['mt5_bar_clock_diagnostics']
                report['time_alignment_status']=sample['time_alignment_status']
                safe_json(args.output,report)
                print(report['as_of'],report['summary']['display_decision'],report['summary']['system_status'],flush=True)
            except (OSError,ValueError,TypeError,KeyError) as exc:
                failure={'as_of':datetime.now(timezone.utc).isoformat().replace('+00:00','Z'),
                         'status':'DATA_ERROR','reason':str(exc),'decision':'NO_TRADE',
                         'execution_permission':'BLOCKED','research_only':True}
                safe_json(args.output,failure)
                print('BLOCKED',str(exc),'-- wykonaj 06_DIAGNOZA_CZASU_MT5.bat jesli problem dotyczy czasu',flush=True)
            if args.once:break
            time.sleep(args.every_seconds)
    except KeyboardInterrupt:pass
    finally:mt5.shutdown()
    return 0

if __name__=='__main__':raise SystemExit(run_cli())
