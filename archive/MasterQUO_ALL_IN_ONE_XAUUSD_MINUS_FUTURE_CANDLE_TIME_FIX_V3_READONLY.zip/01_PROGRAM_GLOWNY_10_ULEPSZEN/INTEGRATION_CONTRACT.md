# Contract — MasterQUO 10 Enhancements CANDIDATE

- **Compatibility**: `schema_version=2.0.0`, `prompt_version=4.1.0` within the frozen M00U configuration. No upgrades rewrite strategy registries M08 or execution owners M11/M14.
- **Authority**: each UXX returns `execution_permission: BLOCKED`. `RUN_UPGRADES_READONLY.run_all()` returns `CANDIDATE`, never `LIVE_APPROVED`; terminal adapter exposes `NO_TRADE/WAIT` only.
- **Clock**: all times must be timezone-aware; closed-candle `available_at <= as_of`. MT5 adapter uses *next actual broker bar open* as the conservative availability proof for the previous bar.
- **Source**: M00U supervises original `legacy_core`. The optional MT5 adapter is a *second* independent read-only diagnostic process. It is not yet part of M00U automatic restart supervision; status is not misrepresented as LIVE CERTIFIED.
- **Gating**: U02/U06/U07/U08 must report missing data and cannot upgrade a diagnostic to a trade. U03 requires actual broker quote and configured cost economics. U04 requires exited trades; U05 requires preregistered probabilities and independent labels; U09 is proposal-only.
- **Data provenance**: M04N event history requires first-seen and release-time audit. Today's FF/MM calendar may not be used to reconstruct prior knowledge. U07 cross-market pairs must share exact historical as-of timestamps.
- **Output**: use `runtime/M00U10_REPORT.json` (offline) or `runtime/M00U10_MT5_REPORT.json` (local terminal); atomic JSON writes; `source_fingerprint` SHA-256 for reproducibility.
- **Audit**: included offline tests are software tests, not MT5 DEMO validation, not regulatory assurance or evidence of any profitability. OOS tests on real broker data remain `NOT_RUN`.
