# MasterQUO — 10 ulepszeń (CANDIDATE v1.0.0)

**Stan:** lokalny prototyp badawczo-diagnostyczny, *bez składania zleceń*. Bazowy M00U uruchamia dotychczasowe moduły read-only. Dziewięć kolejnych modułów to niezależne kalkulatory, połączone wspólnym runnerem `RUN_UPGRADES_READONLY.py` i opcjonalnym adapterem MT5. **To nie jest audyt rentowności ani zatwierdzony bot LIVE.**

## Kolejność budowy

1. **U01 / M00U Unified Runtime** — nadzór nad procesami news/MT5/macro, kontrola plików SHA-256, logi SQLite, restart limit, singleton Windows, wygaszanie starych danych. Kod: `M00U_RUNTIME.py`; poprzednie 130 plików w `legacy_core/` pozostają niezmienione.
2. **U02 / Adaptive Regime** — reżim trend/range/volatile z efektywności cenowej, nachylenia w ATR i zmienności; tylko zamknięte świece. `mq_upgrades/u02_regime.py`.
3. **U03 / Execution Quality** — szacowanie spreadu, prowizji w obie strony, poślizgu i RR netto, bez zakładania spreadu 0 na rachunku Zero. `mq_upgrades/u03_execution.py`.
4. **U04 / OOS Guard** — chronologiczny DEV/OOS, embargo, pełne zakończenia transakcji, próg liczebności i brak samoczynnej promocji. `mq_upgrades/u04_oos.py`.
5. **U05 / Calibration Diagnostics** — Brier score, ECE i tabele niezależnej kalibracji; bez udawania potwierdzonego procentu pewności. `mq_upgrades/u05_calibration.py`.
6. **U06 / Session & Liquidity** — okna Londyn/Nowy Jork z uwzględnieniem DST, potwierdzone pivoty i *potencjalne* sweepy; bez roszczeń o prawdziwy order flow. `mq_upgrades/u06_liquidity.py`.
7. **U07 / Cross-Market** — as-of obserwacje XAU, DXY i innych serii, dane świeże, korelacja opisowa; brak założenia stałej relacji XAU–USD. `mq_upgrades/u07_crossmarket.py`.
8. **U08 / News Surprise** — pomiar forecast vs actual tylko po znanej godzinie publikacji, brak przyszłych prognoz, kontrola brakujących baz normalizacji. `mq_upgrades/u08_surprise.py`.
9. **U09 / Controlled Learning** — białe listy parametrów, ograniczenia zakresu, jawne propozycje, human approval, niezależne OOS i forward DEMO przed zmianą strategii. `mq_upgrades/u09_learning.py`.
10. **U10 / Explainability** — provenance, reason codes, statusy dziewięciu zależności, niezależna blokada zleceń oraz konserwatywny widok WAIT/NO_TRADE. `mq_upgrades/u10_explain.py`.

## Instalacja Windows

1. Rozpakuj **zbiorczy ZIP** w nowym katalogu (nie kopiuj na stary instalator).
2. MetaTrader 5 musi być uruchomiony i zalogowany na **DEMO**. W PowerShell: `py -3 -m pip install MetaTrader5 numpy tzdata`.
3. Sprawdź poprawność środowiska: `py -3 M00U_RUNTIME.py doctor`.
4. Kontrolowany nadzór nad dotychczasowymi procesami: `py -3 M00U_RUNTIME.py run` albo `START_MASTERQUO_UNIFIED_READONLY.bat`.
5. W **drugim** oknie PowerShell uruchom diagnozę wskaźników i kontekstu: `py -3 M00U10_MT5_READONLY_ADAPTER.py --symbol XAUUSD --every-seconds 15`; albo `START_M00U10_MT5_READONLY.bat`.
6. W **trzecim** oknie: `py -3 M00U10_VIEWER.py --file runtime/M00U10_MT5_REPORT.json` (lub `.bat`).
7. Wyłączenie M00U: `py -3 M00U_RUNTIME.py stop`. Adapter kończy się po Ctrl+C w swoim oknie. To są dwa niezależne procesy w wydaniu kandydackim; M00U nie restartuje adaptera M00U10.

Jeśli symbol u brokera to np. `XAUUSDm`, przekaż `--symbol XAUUSDm`. Opcjonalny dolar: `--dxy-symbol SYMBOL_U_BROKERA`. **Nie wpisuj sztucznych instrumentów.** Komendy nie zawierają `order_send`, nie korzystają ze zrzutów ekranu ani OCR. Telegram pozostaje wyłączony.

### Ograniczenia danych

- U03 bez jawnie wpisanych danych o prowizji, walucie konta i wartości punktu będzie `NOT_RUN`. **Rachunek Zero nie oznacza zerowych opłat.** Jeśli używasz danych konta w walucie innej niż USD, konieczne jest jawne przeliczenie i walidacja wartości kontraktu.
- U04/U05 wymagają rzeczywistych dzienników, zewnętrznych wyników i zamrożonych predykcji z M06R/M06T; automatyczny odczyt MT5 sam ich nie wytworzy.
- U08 wymaga zarchiwizowanych `schedule_first_seen_at`, `forecast_recorded_at` i `actual_published_at`. Tygodniowy aktualny kalendarz FF/MM nie daje historycznego momentu poznania danych. Można wpiąć archiwum M04N/M06H po dopasowaniu kontraktu. W obecnym adapterze MT5 źródło wydarzeń jest puste, więc U08 celowo zwraca `PENDING`.
- U06 wykorzystuje cenowe pivoty i sesje, ale nie ma pełnego order book. U07 zadziała dopiero, gdy broker udostępnia drugą serię odpowiednią do badań. M15 zachowuje decyzję właściciela M14.
- M00U i U10 nie są dodatkowym, niezależnie certyfikowanym firewallem zleceń. Do bezpiecznego wykonania potrzebny byłby osobny testowany broker gateway oraz niezależne kontrolery uprawnień.

## Testy offline, bez MT5

```powershell
py -3 -m unittest M00U_TESTS -q
py -3 -m unittest discover -s tests -p "TEST_*.py" -q
py -3 MAKE_SYNTHETIC_EXAMPLE.py
py -3 RUN_UPGRADES_READONLY.py --input examples/SYNTHETIC_CONTEXT.json --output examples/SYNTHETIC_REPORT.json
py -3 M00U10_VIEWER.py --file examples/SYNTHETIC_REPORT.json --once
```

Wszystkie dane z `examples/` są **SYNTETYCZNE**. Raport zawsze zawiera `execution_permission=BLOCKED`. Wygenerowany po kilku godzinach podgląd pokaże stare dane jako `NO_TRADE`, co jest zamierzone.

## Kontrakt wejściowy kalkulatorów

`RUN_UPGRADES_READONLY.py` przyjmuje obiekt JSON zawierający: `as_of` (UTC), `bars` z `closed=true`, `time` i obowiązkowym `available_at`, `quote` z rzeczywistym timestamp/Bid/Ask, `economics` z jawnie zatwierdzonymi kosztami, `cross_market` z czasem dostępności punktów, opcjonalne `macro_events`, `trades`, `predictions`, `learning`, `folds`. Używa tylko dostępnych na ten moment informacji. Po błędzie danych wyświetla `NO_TRADE`, nigdy LONG z rekonstruowanych danych.

Nie włączono automatycznej promocji strategii ani modyfikowania plików bazowych. Zmiany kolejnych UXX są oddzielne od niezmienionych modułów M01–M16 i M04N.
