@echo off
cd /d "%~dp0"
echo MASTERQUO 10 CANDIDATES - READ ONLY / NO ORDERS
py -3 M00U10_MT5_READONLY_ADAPTER.py --symbol XAUUSD --every-seconds 15
pause
