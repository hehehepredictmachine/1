@echo off
cd /d "%~dp0"
py -3 -m unittest -v M00U_TESTS
pause
