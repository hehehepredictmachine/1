"""Regression scenarios for MT5 future timestamp anomalies; no real orders or network."""
import sys
import unittest
from datetime import datetime,timezone,timedelta
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from M00U10_MT5_READONLY_ADAPTER import closed_bars,from_mt5,clock_diagnostics
from RUN_UPGRADES_READONLY import run_all

NOW=datetime(2026,10,8,18,37,tzinfo=timezone.utc)
CURRENT=int(NOW.timestamp())

class BrokerStub:
    TIMEFRAME_D1=1;TIMEFRAME_H4=2;TIMEFRAME_H1=3;TIMEFRAME_M15=4;TIMEFRAME_M5=5;TIMEFRAME_M1=6
    def __init__(self, future=0, tick_offset=0, bad_ohlc=False):
        self.future=future; self.tick_offset=tick_offset; self.bad_ohlc=bad_ohlc
    def symbol_select(self,sym,enabled):return sym=='XAUUSD-'
    def symbol_info_tick(self,sym):
        return type('Tick',(),{'time':CURRENT+self.tick_offset,'bid':2600.,'ask':2600.25})()
    def copy_rates_from_pos(self,sym,tf,pos,count):
        # Return requested history; the newest bar(s) can lie after the UTC clock.
        step={1:86400,2:14400,3:3600,4:900,5:300,6:60}[tf]
        newest=CURRENT-(CURRENT%step)+self.future*step
        data=[]
        for i in range(count):
            c=2500.0+i*0.01
            data.append({'time':newest-(count-i-1)*step,
                         'open':c,'high':c+1,'low':c-1,'close':c+0.2,'tick_volume':55})
        if self.bad_ohlc:data[-20]['low']=data[-20]['high']+1
        return data

class FutureCandleRegression(unittest.TestCase):
    def test_normal_closed_proof(self):
        rows=closed_bars(BrokerStub(),'XAUUSD-','M1',90,as_of=NOW)
        self.assertEqual(len(rows),90)
        self.assertTrue(all(datetime.fromisoformat(b['available_at'].replace('Z','+00:00'))<=NOW for b in rows))
    def test_broker_future_open_excluded_not_backdated(self):
        quality={}
        rows=closed_bars(BrokerStub(future=3),'XAUUSD-','M1',90,as_of=NOW,quality=quality)
        self.assertEqual(len(rows),90)
        self.assertGreaterEqual(quality['excluded_unconfirmed'],2)
        self.assertGreater(quality['current_bar_open_ahead_seconds'],0)
        self.assertLessEqual(datetime.fromisoformat(rows[-1]['available_at'].replace('Z','+00:00')),NOW)
    def test_future_timestamp_stays_blocked_if_no_history(self):
        with self.assertRaisesRegex(ValueError,'INSUFFICIENT_VERIFIED_CLOSED_BARS'):
            closed_bars(BrokerStub(future=150),'XAUUSD-','M1',90,as_of=NOW)
    def test_real_pipeline_future_bar_not_crash(self):
        sample=from_mt5(BrokerStub(future=1),count=90,as_of=NOW)
        result=run_all(sample)
        self.assertEqual(result['execution_permission'],'BLOCKED')
        self.assertNotEqual(result['summary']['system_status'],'LIVE_AUTHORIZED')
        self.assertTrue(all(datetime.fromisoformat(x['available_at'].replace('Z','+00:00'))<=NOW for bars in sample['bars'].values() for x in bars))
    def test_future_broker_tick_not_silently_shifted(self):
        with self.assertRaisesRegex(ValueError,'BROKER_TICK_AHEAD_OF_UTC'):
            from_mt5(BrokerStub(future=1,tick_offset=3*3600),count=90,as_of=NOW)
    def test_clock_diagnostics_raw_source(self):
        d=clock_diagnostics(BrokerStub(future=2,tick_offset=3*3600),'XAUUSD-',as_of=NOW)
        self.assertEqual(d['tick_status'],'AHEAD_OF_UTC')
        self.assertFalse(d['timestamp_correction_applied'])
        self.assertGreater(d['timeframes']['M1']['future_open_count'],0)
    def test_bad_ohlc_blocks(self):
        with self.assertRaisesRegex(ValueError,'INVALID_MT5_OHLC'):
            closed_bars(BrokerStub(bad_ohlc=True),'XAUUSD-','M1',90,as_of=NOW)
    def test_timezone_naive_rejected(self):
        with self.assertRaisesRegex(ValueError,'AS_OF_MUST_BE_TIMEZONE_AWARE'):
            closed_bars(BrokerStub(),'XAUUSD-','M1',90,as_of=datetime(2026,10,8,18,37))

if __name__=='__main__':unittest.main()
