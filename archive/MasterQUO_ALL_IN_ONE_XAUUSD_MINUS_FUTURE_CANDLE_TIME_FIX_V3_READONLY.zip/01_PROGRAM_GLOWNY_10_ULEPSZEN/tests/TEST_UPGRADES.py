"""Run using python -m unittest discover -s tests -p TEST_UPGRADES.py -v."""
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import unittest
from datetime import datetime,timedelta,timezone
from tempfile import TemporaryDirectory
import json,subprocess
from mq_upgrades import u02_regime as R,u03_execution as E,u04_oos as O,u05_calibration as C,u06_liquidity as L,u07_crossmarket as X,u08_surprise as S,u09_learning as G,u10_explain as D
from mq_upgrades.common import when,num,candles,fingerprint,safe_json
from RUN_UPGRADES_READONLY import run_all

T=datetime(2026,10,8,12,tzinfo=timezone.utc)
def ts(t):return t.isoformat().replace('+00:00','Z')
def bars(n=75,start=T-timedelta(hours=80),step=timedelta(hours=1),trend=1):
    rows=[]
    for i in range(n):
        c=2500+i*trend*0.4 + (i%4-1.5)*0.11
        rows.append({'time':ts(start+step*i),'open':c-0.1,'high':c+0.6,'low':c-0.6,'close':c,'closed':True,'available_at':ts(start+step*i)})
    return rows
def quote():return {'time':ts(T),'bid':2600.,'ask':2600.25}
def tradelist(n=55):
    return [{'id':f'A{i}', 'signal_time':ts(T-timedelta(days=110-i)), 'exit_time':ts(T-timedelta(days=110-i)+timedelta(minutes=20)), 'net_r':1.0 if i%3 else -0.5} for i in range(n)]
class Common(unittest.TestCase):
    def test_utc(self):self.assertEqual(when('2026-10-08T12:00:00Z'),T)
    def test_naive(self):
        with self.assertRaises(ValueError):when('2026-10-08T12:00:00')
    def test_nonfinite(self):
        for val in (float('nan'),float('inf'),True,'3'):
            with self.subTest(val=val),self.assertRaises(ValueError):num(val)
    def test_candle_sort(self):
        data=bars(5);data[-1]['time']=data[0]['time']
        with self.assertRaises(ValueError):candles(data)
    def test_forming(self):
        data=bars(5);data[0]['closed']=False
        with self.assertRaises(ValueError):candles(data)
    def test_ohlc(self):
        data=bars(5);data[-1]['low']=data[-1]['high']+1
        with self.assertRaises(ValueError):candles(data)
    def test_fingerprint(self):self.assertEqual(fingerprint({'a':1,'b':2}),fingerprint({'b':2,'a':1}))
    def test_atomic(self):
        with TemporaryDirectory() as d:
            p=Path(d)/'f.json';safe_json(p,{'x':1});self.assertEqual(json.loads(p.read_text())['x'],1)
class Regime(unittest.TestCase):
    def test_trend_up(self):self.assertEqual(R.analyze(bars())['regime'],'TREND_UP')
    def test_trend_down(self):self.assertEqual(R.analyze(bars(trend=-1))['regime'],'TREND_DOWN')
    def test_short(self):self.assertEqual(R.analyze(bars(8))['status'],'PENDING')
    def test_forming_blocked(self):
        a=bars();a[-1]['closed']=False;self.assertEqual(R.analyze(a)['status'],'PENDING')
    def test_no_authority(self):self.assertEqual(R.analyze(bars())['execution_permission'],'BLOCKED')
    def test_bad_lookback(self):self.assertEqual(R.analyze(bars(),lookback=0)['status'],'PENDING')
class Execution(unittest.TestCase):
    def test_long(self):
        r=E.estimate(quote(),'LONG',1,2.5,100,0.03,3,6,as_of=T)
        self.assertEqual(r['status'],'PASS');self.assertAlmostEqual(r['estimated_cost_roundtrip'],36)
    def test_short(self):self.assertEqual(E.estimate(quote(),'SHORT',1,2.5,100,0.03)['status'],'PASS')
    def test_zero_spread_not_inferred(self):self.assertGreater(E.estimate(quote(),'LONG',1,2.5,100,0.03)['spread_cost'],0)
    def test_crossed(self):self.assertEqual(E.estimate({'time':ts(T),'bid':2,'ask':1},'LONG',1,2,100,0)['status'],'NOT_RUN')
    def test_stale(self):self.assertEqual(E.estimate(quote(),'LONG',1,2,100,0,as_of=T+timedelta(seconds=8))['status'],'NOT_RUN')
    def test_future(self):self.assertEqual(E.estimate(quote(),'LONG',1,2,100,0,as_of=T-timedelta(seconds=2))['status'],'NOT_RUN')
    def test_missing_contract_value(self):self.assertEqual(E.estimate(quote(),'LONG',1,2,None,0)['status'],'NOT_RUN')
    def test_negative_cost(self):self.assertEqual(E.estimate(quote(),'LONG',1,-2,100,0)['status'],'NOT_RUN')
    def test_stress(self):self.assertLess(E.stress(quote(),'LONG',1,2,100,.1)[0]['estimated_cost_roundtrip'],E.stress(quote(),'LONG',1,2,100,.1)[2]['estimated_cost_roundtrip'])
class OOS(unittest.TestCase):
    def test_sample_insufficient(self):self.assertEqual(O.validate(tradelist(),ts(T-timedelta(days=80)+timedelta(hours=12)),ts(T-timedelta(days=79)))['status'],'INSUFFICIENT_OOS')
    def test_pass(self):
        r=O.validate(tradelist(70),ts(T-timedelta(days=100)+timedelta(hours=12)),ts(T-timedelta(days=99)),min_oos=20)
        self.assertEqual(r['status'],'PASS');self.assertFalse(r['promotion_allowed'])
    def test_overlap(self):self.assertEqual(O.validate([],ts(T),ts(T))['status'],'NOT_RUN')
    def test_embargo(self):
        r=O.validate(tradelist(),ts(T-timedelta(days=95)),ts(T-timedelta(days=90)),embargo_seconds=600000)
        self.assertEqual(r['status'],'NOT_RUN')
    def test_duplicate(self):
        a=tradelist();a.append(a[0]);self.assertEqual(O.validate(a,ts(T-timedelta(days=100)),ts(T-timedelta(days=99)))['status'],'NOT_RUN')
    def test_zero_minimum_rejected(self):
        self.assertEqual(O.validate([],ts(T-timedelta(days=2)),ts(T),min_oos=0)['status'],'NOT_RUN')
    def test_negative_embargo_rejected(self):
        self.assertEqual(O.validate([],ts(T-timedelta(days=2)),ts(T),embargo_seconds=-1)['status'],'NOT_RUN')
    def test_bad_r(self):
        a=tradelist();a[0]['net_r']=float('nan');self.assertEqual(O.validate(a,ts(T-timedelta(days=100)),ts(T-timedelta(days=99)))['status'],'NOT_RUN')
class Calibration(unittest.TestCase):
    def data(self,n=60):
        return [{'as_of':ts(T+timedelta(hours=i)),'prediction_recorded_at':ts(T+timedelta(hours=i)),
                 'predicted_probability':0.8 if i%2 else 0.2,'outcome':i%2} for i in range(n)]
    def test_ok(self):self.assertEqual(C.evaluate(self.data(),ts(T-timedelta(days=2)),ts(T),min_oos=30)['status'],'PASS')
    def test_not_claim_calibrated(self):self.assertFalse(C.evaluate(self.data(),ts(T-timedelta(days=2)),ts(T),min_oos=30)['calibrated'])
    def test_insufficient(self):self.assertEqual(C.evaluate(self.data(2),ts(T-timedelta(days=2)),ts(T))['status'],'INSUFFICIENT_OOS')
    def test_future_prediction(self):
        data=self.data();data[2]['prediction_recorded_at']=ts(T+timedelta(days=20))
        self.assertEqual(C.evaluate(data,ts(T-timedelta(days=2)),ts(T))['status'],'NOT_RUN')
    def test_bad_prob(self):
        data=self.data();data[0]['predicted_probability']=1.01
        self.assertEqual(C.evaluate(data,ts(T-timedelta(days=2)),ts(T))['status'],'NOT_RUN')
    def test_zero_minimum_rejected(self):self.assertEqual(C.evaluate([],ts(T-timedelta(days=2)),ts(T),min_oos=0)['status'],'NOT_RUN')
    def test_bad_bin_count(self):self.assertEqual(C.evaluate([],ts(T-timedelta(days=2)),ts(T),bins=1)['status'],'NOT_RUN')
    def test_frozen_late(self):self.assertEqual(C.evaluate(self.data(),ts(T+timedelta(days=2)),ts(T))['status'],'NOT_RUN')
class Liquidity(unittest.TestCase):
    def test_sessions(self):self.assertIn('london_active',L.analyze(bars())['session'])
    def test_short(self):self.assertEqual(L.analyze(bars(4))['status'],'PENDING')
    def test_no_orderflow_claim(self):self.assertFalse(L.analyze(bars())['real_order_flow_available'])
    def test_confirmed_pivot_no_future(self):
        data=bars(12)
        for i,p in enumerate([4,5,8,7,5,4,4,5,6,7,8,9]):
            data[i].update(open=p,high=p+1,low=p-1,close=p)
        out=L.analyze(data,pivot_left=2,pivot_right=2)
        self.assertEqual(out['status'],'PASS')
        self.assertTrue(all(when(x['available_at'])<=when(data[-1]['time']) for x in out['confirmed_swings']))
class CrossMarket(unittest.TestCase):
    def series(self):
        t=T-timedelta(hours=25)
        return {key:[{'time':ts(t+timedelta(hours=i)),'close':2600+i*0.4+((i*i)%7)*0.1 if key=='XAUUSD' else 100+i*0.02+((i*3)%5)*0.1} for i in range(26)] for key in ('XAUUSD','DXY')}
    def test_correlations(self):self.assertEqual(X.analyze(self.series(),T,min_pairs=10)['markets']['DXY']['status'],'PASS')
    def test_optional_missing(self):self.assertEqual(X.analyze({'XAUUSD':self.series()['XAUUSD']},T)['status'],'PENDING')
    def test_future_removed(self):
        s=self.series();s['DXY'][-1]['time']=ts(T+timedelta(hours=2));self.assertEqual(X.analyze(s,T)['markets']['DXY']['status'],'PASS')
    def test_stale(self):self.assertEqual(X.analyze(self.series(),T+timedelta(days=2))['status'],'PENDING')
    def test_no_base(self):self.assertEqual(X.analyze({},T)['status'],'PENDING')
class Surprise(unittest.TestCase):
    def event(self):return {'event_id':'CPI-1','type':'CPI','scheduled_at':ts(T),
       'schedule_first_seen_at':ts(T-timedelta(days=1)), 'forecast_recorded_at':ts(T-timedelta(hours=1)),
       'forecast':3.1,'actual':3.4,'actual_published_at':ts(T+timedelta(minutes=1))}
    def test_upcoming(self):self.assertEqual(S.analyze([self.event()],T-timedelta(minutes=2))['events'][0]['status'],'UPCOMING')
    def test_unreleased(self):self.assertFalse(S.analyze([self.event()],T)['events'][0]['actual_available'])
    def test_real(self):self.assertEqual(S.analyze([self.event()],T+timedelta(minutes=2),{'CPI':0.3})['events'][0]['status'],'NORMALIZED')
    def test_future_forecast(self):
        e=self.event();e['forecast_recorded_at']=ts(T+timedelta(minutes=1))
        self.assertEqual(S.analyze([e],T+timedelta(minutes=2))['events'][0]['status'],'UNVERIFIED')
    def test_duplicate(self):self.assertEqual(S.analyze([self.event(),self.event()],T)['status'],'PENDING')
    def test_no_schedule_before(self):
        e=self.event();e['schedule_first_seen_at']=ts(T+timedelta(minutes=1));self.assertFalse(S.analyze([e],T)['events'])
class Learning(unittest.TestCase):
    def p(self):return {'news_block_pre_minutes':30.,'max_cost_to_stop_ratio':0.2}
    def report(self):return {'status':'PASS','net_sample_size':100,'evaluated_at':ts(T)}
    def test_proposal(self):
        c=self.p();c['news_block_pre_minutes']=45.
        r=G.propose(self.p(),c,self.report(),as_of=T)
        self.assertEqual(r['status'],'REVIEW_REQUIRED');self.assertFalse(r['applied'])
    def test_never_auto_apply(self):
        c=self.p();c['news_block_pre_minutes']=45.
        self.assertTrue(G.propose(self.p(),c,self.report())['approval_required'])
    def test_bounds(self):
        c=self.p();c['news_block_pre_minutes']=999.
        self.assertEqual(G.propose(self.p(),c,self.report())['status'],'REJECTED')
    def test_unknown(self):
        c=self.p();c['shell_command']='hey'
        self.assertEqual(G.propose(self.p(),c,self.report())['status'],'REJECTED')
    def test_no_change(self):self.assertEqual(G.propose(self.p(),self.p(),self.report())['status'],'REJECTED')
    def test_small_n(self):
        c=self.p();c['news_block_pre_minutes']=45.
        self.assertEqual(G.propose(self.p(),c,{'status':'PASS','net_sample_size':3})['status'],'REJECTED')
    def test_dev_future(self):
        c=self.p();c['news_block_pre_minutes']=45.
        self.assertEqual(G.propose(self.p(),c,self.report(),as_of=T-timedelta(days=1))['status'],'REJECTED')
class Explain(unittest.TestCase):
    def test_missing_all(self):self.assertEqual(D.explain(T,{})['display_decision'],'NO_TRADE')
    def test_no_permission(self):self.assertEqual(D.explain(T,{'runtime':{'system_state':'RUNNING_DIAGNOSTIC'}},'LONG')['execution_permission'],'BLOCKED')
    def test_unsafe_authority(self):
        d={x:{'status':'PASS','execution_permission':'BLOCKED'} for x in ('regime','execution','oos','calibration','liquidity','cross_market','surprise','learning')}
        d['runtime']={'system_state':'RUNNING_DIAGNOSTIC','execution_permission':'ALLOWED'}
        self.assertIn('AUTHORITY_VIOLATION_RUNTIME',D.explain(T,d)['reason_codes'])
    def test_invalid_decision(self):self.assertEqual(D.explain(T,{},'PLACE_ORDER')['technical_decision_observed'],'NO_TRADE')
    def test_source_hash(self):self.assertEqual(len(D.explain(T,{})['source_hash']),64)
class FullPipeline(unittest.TestCase):
    def payload(self):
        return {'as_of':ts(T),'bars':{'H1':bars(start=T-timedelta(hours=74)),'M5':bars(start=T-timedelta(minutes=74*5),step=timedelta(minutes=5))},
            'quote':quote(),'economics':{'lots':0.01,'commission_per_lot_side':2.5,'money_per_price_unit_per_lot':100,'slippage_price':.05},
            'runtime':{'system_state':'RUNNING_DIAGNOSTIC'},'technical_decision':'WAIT',
            'orders_enabled':False,'telegram_enabled':False}
    def test_all_stages(self):
        r=run_all(self.payload())
        self.assertEqual(len(r['stages']),9);self.assertEqual(r['execution_permission'],'BLOCKED')
    def test_missing_research(self):
        r=run_all({'as_of':ts(T)})
        self.assertEqual(r['summary']['display_decision'],'NO_TRADE')
    def test_future_available_bar(self):
        d=self.payload();d['bars']['M5'][-1]['available_at']=ts(T+timedelta(minutes=5))
        with self.assertRaises(ValueError):run_all(d)
    def test_missing_available_bar(self):
        d=self.payload();del d['bars']['H1'][0]['available_at']
        with self.assertRaises(ValueError):run_all(d)
    def test_block_order(self):
        d=self.payload();d['orders_enabled']=True
        with self.assertRaises(ValueError):run_all(d)
    def test_block_telegram(self):
        d=self.payload();d['telegram_enabled']=True
        with self.assertRaises(ValueError):run_all(d)
    def test_roundtrip(self):
        with TemporaryDirectory() as tmp:
            i=Path(tmp)/'in.json';o=Path(tmp)/'out.json';i.write_text(json.dumps(self.payload()))
            run=subprocess.run([sys.executable,str(Path(__file__).resolve().parents[1]/'RUN_UPGRADES_READONLY.py'),'--input',str(i),'--output',str(o)],capture_output=True,text=True)
            self.assertEqual(run.returncode,0,run.stderr);self.assertEqual(json.loads(o.read_text())['execution_permission'],'BLOCKED')
    def test_schema_stable(self):self.assertEqual(run_all(self.payload())['schema_version'],'2.0.0')
if __name__=='__main__':unittest.main()
