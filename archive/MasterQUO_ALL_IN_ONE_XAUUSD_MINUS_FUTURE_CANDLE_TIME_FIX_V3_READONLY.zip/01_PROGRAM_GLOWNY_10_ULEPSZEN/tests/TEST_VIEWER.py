from datetime import datetime,timedelta,timezone
from pathlib import Path
import sys,unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from M00U10_VIEWER import view_status
T=datetime(2026,10,8,12,tzinfo=timezone.utc)
class Tests(unittest.TestCase):
 def test_missing(self):self.assertEqual(view_status({},T)['decision'],'NO_TRADE')
 def test_unsafe(self):self.assertEqual(view_status({'execution_permission':'ALLOWED'},T)['decision'],'NO_TRADE')
 def test_stale(self):
  d={'as_of':(T-timedelta(minutes=4)).isoformat(),'execution_permission':'BLOCKED','summary':{'execution_permission':'BLOCKED','display_decision':'WAIT'}}
  self.assertEqual(view_status(d,T)['decision'],'NO_TRADE')
 def test_fresh_diagnostic(self):
  d={'as_of':T.isoformat(),'execution_permission':'BLOCKED','summary':{'execution_permission':'BLOCKED','display_decision':'WAIT','reason_codes':['test']},'stages':{'oos':{'status':'NOT_RUN'}}}
  self.assertEqual(view_status(d,T)['decision'],'WAIT')
 def test_invalid_summary(self):
  d={'as_of':T.isoformat(),'execution_permission':'BLOCKED','summary':{'execution_permission':'ALLOWED','display_decision':'LONG'}}
  self.assertEqual(view_status(d,T)['decision'],'NO_TRADE')
