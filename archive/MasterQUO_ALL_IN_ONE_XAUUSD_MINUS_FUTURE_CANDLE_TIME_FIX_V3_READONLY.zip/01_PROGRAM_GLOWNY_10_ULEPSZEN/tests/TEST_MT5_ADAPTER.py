import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from M00U10_MT5_READONLY_ADAPTER import closed_bars,from_mt5
from unittest import mock
from datetime import datetime, timezone

class FakeMT5:
    TIMEFRAME_D1=1;TIMEFRAME_H4=2;TIMEFRAME_H1=3;TIMEFRAME_M15=4;TIMEFRAME_M5=5;TIMEFRAME_M1=6
    def symbol_select(self,name,v):return True
    def symbol_info_tick(self,name):return type('Tick',(),{'time':1780920000,'bid':2600,'ask':2600.15})()
    def copy_rates_from_pos(self,symbol,tf,pos,count):
        return [{'time':1780920000-(count-i)*60,'open':2600+i*0.1,'high':2601+i*0.1,
                 'low':2599+i*0.1,'close':2600+i*0.1,'tick_volume':50} for i in range(count)]
class Tests(unittest.TestCase):
    def test_count_excludes_forming(self):
        v=closed_bars(FakeMT5(),'XAUUSD','M1',40)
        self.assertEqual(len(v),40)
        self.assertLess(v[-1]['time'],v[-1]['available_at'])
        self.assertTrue(all(x['closed'] for x in v))
    def test_all_timeframes(self):
        a=from_mt5(FakeMT5(),count=60)
        self.assertEqual(len(a['bars']),6)
        self.assertEqual(a['economics'],{})
        self.assertEqual(a['orders_enabled'],False)
    def test_dxy(self):
        a=from_mt5(FakeMT5(),dxy_symbol='USDX',count=60)
        self.assertIn('DXY',a['cross_market'])
    def test_missing_data(self):
        obj=FakeMT5();obj.copy_rates_from_pos=lambda *a:None
        with self.assertRaises(ValueError):from_mt5(obj,count=60)
    def test_duplicate_time(self):
        obj=FakeMT5();obj.copy_rates_from_pos=lambda *a:[{'time':0}]*41
        with self.assertRaises(ValueError):closed_bars(obj,'XAUUSD','M1',40)
    def test_no_orders_calls(self):
        obj=FakeMT5();r=from_mt5(obj,count=60)
        self.assertNotIn('orders',r)
    def test_requires_runtime(self):
        r=from_mt5(FakeMT5(),count=60)
        self.assertEqual(r['runtime']['system_state'],'MISSING')
if __name__=='__main__':unittest.main()
