@echo off
cd /d "%~dp0"
py -3 M00U_RUNTIME.py stop
pause
