@echo off
cd /d "%~dp0"
py -3 -m unittest discover -p "INTEGRATION_TESTS.py" -v
pause
