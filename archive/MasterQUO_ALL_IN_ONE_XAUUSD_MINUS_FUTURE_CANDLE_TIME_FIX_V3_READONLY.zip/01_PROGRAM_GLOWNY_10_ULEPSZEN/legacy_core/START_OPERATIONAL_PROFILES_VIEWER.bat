@echo off
setlocal
cd /d "%~dp0"
py -3 M15_SIGNAL_VIEWER.py
pause
