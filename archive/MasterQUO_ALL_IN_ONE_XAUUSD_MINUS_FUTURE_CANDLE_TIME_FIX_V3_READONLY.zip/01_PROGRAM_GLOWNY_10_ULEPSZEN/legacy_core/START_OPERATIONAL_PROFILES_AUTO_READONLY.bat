@echo off
setlocal
cd /d "%~dp0"
py -3 RUN_MT5_OPERATIONAL_PROFILES_READONLY.py --mode AUTO --symbol XAUUSD %*
if errorlevel 1 echo ERROR: read README_OPERATIONAL_PROFILES.md
pause
