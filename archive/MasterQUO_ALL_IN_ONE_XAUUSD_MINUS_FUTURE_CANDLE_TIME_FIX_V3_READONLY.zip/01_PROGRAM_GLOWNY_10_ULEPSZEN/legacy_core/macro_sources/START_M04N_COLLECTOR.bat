@echo off
setlocal
cd /d "%~dp0"
echo MasterQUO M04N - NEWS/MACRO READ ONLY
py -3 M04N_ENGINE.py
if errorlevel 1 echo Problem: sprawdz Python, internet oraz README.md
pause
