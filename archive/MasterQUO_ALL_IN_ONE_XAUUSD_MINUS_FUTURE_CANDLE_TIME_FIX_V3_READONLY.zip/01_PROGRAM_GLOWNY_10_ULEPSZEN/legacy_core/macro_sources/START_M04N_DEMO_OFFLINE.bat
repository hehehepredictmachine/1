@echo off
setlocal
cd /d "%~dp0"
py -3 M04N_DEMO_OFFLINE.py
pause
