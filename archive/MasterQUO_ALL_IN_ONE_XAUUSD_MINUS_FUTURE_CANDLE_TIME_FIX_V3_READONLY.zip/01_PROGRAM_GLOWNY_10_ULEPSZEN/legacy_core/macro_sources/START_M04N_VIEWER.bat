@echo off
setlocal
cd /d "%~dp0"
py -3 M04N_VIEWER.py --watch 10
pause
