@echo off
setlocal
cd /d "%~dp0"
py -3 -m pip install tzdata
py -3 -m unittest -v M04N_TESTS M04N_M04_CONTRACT_TESTS M04N_FAIR_ECONOMY_TESTS
pause
