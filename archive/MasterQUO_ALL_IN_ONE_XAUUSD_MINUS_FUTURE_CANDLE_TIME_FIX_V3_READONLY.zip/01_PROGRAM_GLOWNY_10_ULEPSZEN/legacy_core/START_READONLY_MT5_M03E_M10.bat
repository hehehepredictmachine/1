@echo off
cd /d "%~dp0"
py -3 RUN_MT5_READONLY_SIGNAL_LIFECYCLE.py --symbol XAUUSD
pause
