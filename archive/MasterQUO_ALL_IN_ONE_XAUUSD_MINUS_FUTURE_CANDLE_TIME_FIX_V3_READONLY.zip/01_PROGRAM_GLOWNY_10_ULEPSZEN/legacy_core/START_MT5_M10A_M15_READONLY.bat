@echo off
cd /d "%~dp0"
py -3 RUN_MT5_M10A_M15_READONLY.py --symbol XAUUSD
pause
