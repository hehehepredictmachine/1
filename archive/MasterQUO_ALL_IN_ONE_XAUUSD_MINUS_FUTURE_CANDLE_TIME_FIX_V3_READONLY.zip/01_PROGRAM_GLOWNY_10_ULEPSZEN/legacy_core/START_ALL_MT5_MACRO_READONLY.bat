@echo off
cd /d "%~dp0"
if not exist runtime\M04N mkdir runtime\M04N
start "M04N Gold USD Collector" cmd /k "py -3 macro_sources\M04N_ENGINE.py --config macro_sources\M04N_CONFIG.json --runtime runtime\M04N"
start "MasterQUO MT5 Operational Profiles" cmd /k "py -3 RUN_MT5_OPERATIONAL_PROFILES_READONLY.py --mode AUTO --symbol XAUUSD"
start "MasterQUO Macro Guard" cmd /k "py -3 M04N_MACRO_GUARD.py"
start "MasterQUO Macro Viewer" cmd /k "py -3 M04N_MACRO_VIEWER.py"
echo Started 4 diagnostic windows. Telegram and orders are DISABLED.
