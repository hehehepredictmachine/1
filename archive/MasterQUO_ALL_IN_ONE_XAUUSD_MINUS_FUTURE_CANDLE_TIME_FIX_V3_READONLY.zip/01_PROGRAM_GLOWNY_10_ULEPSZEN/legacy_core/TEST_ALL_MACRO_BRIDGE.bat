@echo off
cd /d "%~dp0"
py -3 RUN_MACRO_GUARD_ALL_TESTS.py
if errorlevel 1 (echo TESTY FAILED) else (echo TESTY PASS)
pause
