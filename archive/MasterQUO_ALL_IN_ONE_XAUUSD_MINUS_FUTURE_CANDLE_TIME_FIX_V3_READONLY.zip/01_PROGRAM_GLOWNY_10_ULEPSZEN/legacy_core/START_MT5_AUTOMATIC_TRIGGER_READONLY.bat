@echo off
cd /d "%~dp0"
if not exist "runtime" mkdir "runtime"
py -3 RUN_MT5_AUTOMATIC_TRIGGER_READONLY.py --symbol XAUUSD %*
if errorlevel 1 echo [ERROR] Sprawdz uruchomienie MT5, pip i argumenty.
pause
