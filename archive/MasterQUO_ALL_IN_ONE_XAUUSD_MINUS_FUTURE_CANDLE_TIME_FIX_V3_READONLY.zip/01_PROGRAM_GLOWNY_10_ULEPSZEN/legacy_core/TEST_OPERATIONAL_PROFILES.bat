@echo off
setlocal
cd /d "%~dp0"
py -3 RUN_ALL_OPERATIONAL_PROFILE_TESTS.py
pause
