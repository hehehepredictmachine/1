@echo off
cd /d "%~dp0"
py -3 -m unittest M10_AUTO_TRIGGER_TESTS -q
pause
