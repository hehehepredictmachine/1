@echo off
cd /d "%~dp0"
py -3 M04N_MACRO_GUARD.py
pause
