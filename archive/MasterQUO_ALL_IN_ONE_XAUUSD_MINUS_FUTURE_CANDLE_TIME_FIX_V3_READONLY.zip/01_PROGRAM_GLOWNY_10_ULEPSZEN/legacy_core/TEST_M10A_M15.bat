@echo off
cd /d "%~dp0"
py -3 -m unittest M10A_M15_TESTS -v
pause
