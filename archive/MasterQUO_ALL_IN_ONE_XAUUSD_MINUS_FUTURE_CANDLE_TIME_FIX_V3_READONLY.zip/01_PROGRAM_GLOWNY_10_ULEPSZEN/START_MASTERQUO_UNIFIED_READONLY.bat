@echo off
cd /d "%~dp0"
py -3 M00U_RUNTIME.py doctor
if errorlevel 1 (echo Nieprawidlowa konfiguracja. & pause & exit /b 1)
py -3 M00U_RUNTIME.py run --with-viewer
pause
