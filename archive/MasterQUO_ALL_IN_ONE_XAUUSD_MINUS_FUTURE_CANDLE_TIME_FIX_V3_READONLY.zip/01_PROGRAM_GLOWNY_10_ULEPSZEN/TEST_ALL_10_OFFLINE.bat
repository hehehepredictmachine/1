@echo off
cd /d "%~dp0"
py -3 -m unittest M00U_TESTS -q
if errorlevel 1 exit /b 1
py -3 -m unittest discover -s tests -p "TEST_*.py" -q
if errorlevel 1 exit /b 1
echo ALL_OFFLINE_TESTS_PASSED
