#!/usr/bin/env python3
"""Read-only local monitor; does not request orders, screenshots or credentials."""
import argparse,json,time
from pathlib import Path
from datetime import datetime,timezone
from mq_upgrades.common import when

def view_status(document,now,max_age=60):
    try:
        if not isinstance(document,dict) or document.get('execution_permission')!='BLOCKED':
            return {'decision':'NO_TRADE','reason':'INVALID_OR_UNSAFE_REPORT'}
        stamp=when(document['as_of']);age=(now-stamp).total_seconds()
        if age<0 or age>max_age:
            return {'decision':'NO_TRADE','reason':'STALE_OR_FUTURE_REPORT'}
        summary=document.get('summary',{})
        if summary.get('execution_permission')!='BLOCKED':
            return {'decision':'NO_TRADE','reason':'INVALID_SUMMARY_PERMISSION'}
        return {'decision':summary.get('display_decision','NO_TRADE'),
                'reason':','.join(summary.get('reason_codes',[])),
                'stages':{k:v.get('status','UNKNOWN') for k,v in document.get('stages',{}).items()}}
    except (KeyError,TypeError,ValueError):
        return {'decision':'NO_TRADE','reason':'REPORT_UNAVAILABLE'}

def main(argv=None):
    parser=argparse.ArgumentParser()
    parser.add_argument('--file',default='runtime/M00U10_MT5_REPORT.json')
    parser.add_argument('--seconds',type=float,default=3.0)
    parser.add_argument('--once',action='store_true')
    args=parser.parse_args(argv)
    if not 0.5<=args.seconds<=300:parser.error('Invalid refresh')
    try:
        while True:
            try:report=json.loads(Path(args.file).read_text(encoding='utf-8'))
            except (OSError,ValueError):report={}
            status=view_status(report,datetime.now(timezone.utc))
            print('\nMASTERQUO 10 UPGRADES |',status['decision'],'|',status['reason'],flush=True)
            for key,value in status.get('stages',{}).items():print(' ',key.ljust(15),value)
            print('EXECUTION: BLOCKED | RESEARCH ONLY',flush=True)
            if args.once:return 0
            time.sleep(args.seconds)
    except KeyboardInterrupt:return 0
if __name__=='__main__':raise SystemExit(main())
