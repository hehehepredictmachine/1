"""Offline tests of first improvement; do not touch MT5/network."""
from __future__ import annotations
import copy
import datetime as dt
import importlib.util
import json
import os
import pathlib
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
import M00U_RUNTIME as m

BASE=m.load_config(m.ROOT/'M00U_CONFIG.json')
T=dt.datetime(2026,10,8,15,0,tzinfo=dt.timezone.utc)

def conf(**kwargs):
    return {**copy.deepcopy(BASE), **kwargs}

def report_time(delta=0):return m.timestamp(T+dt.timedelta(seconds=delta))

def write_sample(root,*,now=T,market_age=0,published_age=0,without=None):
    without=without or set()
    for part,paths in m.OUTPUTS.items():
        for path in paths:
            if path in without:continue
            record={'as_of':m.timestamp(now), 'execution_permission':'BLOCKED',
                    'research_only':True}
            if part=='news':record.update(module_id='M04N',status='PARTIAL',advisory={'execution_permission':'BLOCKED'})
            if part=='mt5':
                record.update(module_id='M15',m10a_connection_status='CONNECTED')
                record['as_of']=m.timestamp(now-dt.timedelta(seconds=market_age))
                record['m15_published_at']=m.timestamp(now-dt.timedelta(seconds=published_age))
            if part=='macro':
                record.update(module_id='M04N_MACRO_GUARD',integrity_status='VALID_PARTIAL',macro_gate='PENDING',m14_original_decision='LONG',
                              guarded_display_decision='WAIT')
            m.atomic_json(root/path,record)

class ConfigTests(unittest.TestCase):
    def test_valid(self):self.assertEqual(m.config_from(copy.deepcopy(BASE)),BASE)
    def test_not_dict(self):
        with self.assertRaises(ValueError):m.config_from(None)
    def test_unknown_key(self):
        with self.assertRaises(ValueError):m.config_from(conf(command='powershell'))
    def test_modes(self):
        for x in ('AUTO','MVP','SMC','SCALPING'):self.assertEqual(m.config_from(conf(mode=x))['mode'],x)
    def test_bad_mode(self):
        with self.assertRaises(ValueError):m.config_from(conf(mode='BROKER_ORDER'))
    def test_bad_symbol(self):
        for x in ('','X AU','XAU;rm', '../x',''*2,'a'*40,9):
            with self.subTest(x=x), self.assertRaises(ValueError):m.config_from(conf(symbol=x))
    def test_bad_dxy(self):
        for x in ('bad shell','USD;X',3):
            with self.subTest(x=x),self.assertRaises(ValueError):m.config_from(conf(dxy_symbol=x))
    def test_dxy_optional(self):self.assertIsNone(m.config_from(BASE)['dxy_symbol'])
    def test_orders_block(self):
        with self.assertRaises(ValueError):m.config_from(conf(enable_orders=True))
    def test_telegram_block(self):
        with self.assertRaises(ValueError):m.config_from(conf(telegram_enabled=True))
    def test_screen_block(self):
        with self.assertRaises(ValueError):m.config_from(conf(screen_capture_enabled=True))
    def test_research_mandatory(self):
        with self.assertRaises(ValueError):m.config_from(conf(research_only=False))
    def test_schema(self):
        with self.assertRaises(ValueError):m.config_from(conf(schema_version='3.0.0'))
    def test_prompt(self):
        with self.assertRaises(ValueError):m.config_from(conf(prompt_version='5.0.0'))
    def test_invalid_poll(self):
        for x in (-2,0,float('inf'),False,'2'):
            with self.subTest(x=x),self.assertRaises(ValueError):m.config_from(conf(poll_seconds=x))
    def test_restart_limit_int(self):
        for x in (3.0,-1,100,'5'):
            with self.subTest(x=x),self.assertRaises(ValueError):m.config_from(conf(restart_limit=x))
    def test_age_mapping(self):
        for x in ({},{'news':3}, {'news':900,'mt5':25,'macro':0}):
            with self.subTest(x=x),self.assertRaises(ValueError):m.config_from(conf(max_report_age_seconds=x))
    def test_viewer_not_bool(self):
        with self.assertRaises(ValueError):m.config_from(conf(show_viewer=1))
    def test_terminal_path_value(self):
        with self.assertRaises(ValueError):m.config_from(conf(terminal_path=''))

class CommandsTests(unittest.TestCase):
    def test_command_prefix(self):
        for name in m.PARTS:
            with self.subTest(name=name):
                cmd=m.command_for(name,BASE,m.CORE,'python')
                self.assertEqual(cmd[:2],['python','-u'])
                self.assertFalse(any(x in cmd for x in ('--telegram-send','--enable-orders')))
    def test_wrong_component(self):
        with self.assertRaises(ValueError):m.command_for('arbitrary',BASE)
    def test_mt5_mode(self):
        self.assertIn('SCALPING',m.command_for('mt5',conf(mode='SCALPING')))
    def test_optional_dxy_and_terminal(self):
        c=m.command_for('mt5',conf(dxy_symbol='USDX',terminal_path='C:\\Terminal\\terminal64.exe'))
        self.assertIn('USDX',c)
        self.assertIn('C:\\Terminal\\terminal64.exe',c)
    def test_macro_no_send(self):
        self.assertNotIn('--telegram-send',m.command_for('macro',BASE))
    def test_python_shell_injection_not_used(self):
        self.assertTrue(all(isinstance(x,str) for x in m.command_for('news',BASE)))
    def test_both_sources_preserved(self):
        text=(m.CORE/'macro_sources'/'M04N_CONFIG.json').read_text()
        self.assertIn('FF_CALENDAR',text);self.assertIn('MM_CALENDAR',text)

class AtomicTests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=pathlib.Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def test_write(self):
        p=self.root/'deep'/'data.json';m.atomic_json(p,{'x':2});self.assertEqual(m.read_json(p),{'x':2})
    def test_invalid_file(self):
        p=self.root/'bad';p.write_text('no');self.assertIsNone(m.read_json(p))
    def test_json_array_rejected(self):
        p=self.root/'bad';p.write_text('[]');self.assertIsNone(m.read_json(p))
    def test_nan_blocked(self):
        with self.assertRaises(ValueError):m.atomic_json(self.root/'f',{'x':float('nan')})
    def test_empty_not_found(self):self.assertIsNone(m.read_json(self.root/'missing'))
    def test_timestamp(self):self.assertEqual(m.parse_time(report_time()),T)
    def test_naive(self):
        with self.assertRaises(ValueError):m.parse_time('2026-01-01T00:00:00')
    def test_future(self):self.assertEqual(m.age_check({'as_of':report_time(4),'execution_permission':'BLOCKED'},T,10),'FUTURE_TIMESTAMP')
    def test_age_missing(self):self.assertEqual(m.age_check({},T,10),'BAD_TIMESTAMP')
    def test_age_stale(self):self.assertEqual(m.age_check({'as_of':report_time(-100),'execution_permission':'BLOCKED'},T,10),'STALE')
    def test_age_fresh(self):self.assertEqual(m.age_check({'as_of':report_time(),'execution_permission':'BLOCKED'},T,10),'FRESH')
    def test_age_bad_authority(self):self.assertEqual(m.age_check({'as_of':report_time(),'execution_permission':'ALLOW'},T,10),'UNSAFE_AUTHORIZATION')
    def test_age_publication(self):
        o={'as_of':report_time(-60),'m15_published_at':report_time(),'execution_permission':'BLOCKED'}
        self.assertEqual(m.age_check(o,T,20,time_field='m15_published_at'),'FRESH')
        self.assertEqual(m.age_check(o,T,20),'STALE')

class SafetyTests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=pathlib.Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def run_safe(self):return m.safe_status(self.root,T,BASE)
    def test_missing_all_fails(self):
        x=self.run_safe();self.assertEqual(x['decision'],'NO_TRADE');self.assertEqual(x['system_state'],'DEGRADED')
    def test_no_authority(self):
        x=self.run_safe();self.assertFalse(x['execution_eligible']);self.assertFalse(x['order_execution_enabled'])
        self.assertEqual(x['execution_permission'],'BLOCKED')
    def test_all_fresh_diagnostic(self):
        write_sample(self.root)
        x=self.run_safe();self.assertEqual(x['system_state'],'RUNNING_DIAGNOSTIC');self.assertEqual(x['diagnostic_m14_decision'],'LONG')
        self.assertEqual(x['decision'],'NO_TRADE')
    def test_future_news(self):
        write_sample(self.root)
        p=self.root/m.OUTPUTS['news'][0];record=m.read_json(p);record['as_of']=report_time(3);m.atomic_json(p,record)
        self.assertIn('NEWS_FUTURE_TIMESTAMP',self.run_safe()['reason_codes'])
    def test_missing_bridge(self):
        write_sample(self.root,without={m.OUTPUTS['news'][1]})
        self.assertIn('NEWS_MISSING_OR_INVALID',self.run_safe()['reason_codes'])
    def test_stale_macro(self):
        write_sample(self.root)
        p=self.root/m.OUTPUTS['macro'][0];rec=m.read_json(p);rec['as_of']=report_time(-25);m.atomic_json(p,rec)
        self.assertIn('MACRO_STALE',self.run_safe()['reason_codes'])
    def test_stale_market_even_fresh_heartbeat(self):
        write_sample(self.root,market_age=60,published_age=0)
        self.assertIn('MT5_MARKET_OBSERVATION_NOT_CURRENT',self.run_safe()['reason_codes'])
    def test_stale_heartbeat(self):
        write_sample(self.root,market_age=0,published_age=40)
        self.assertIn('MT5_STALE',self.run_safe()['reason_codes'])
    def test_corrupt_macro(self):
        write_sample(self.root);(self.root/m.OUTPUTS['macro'][0]).write_text('bad')
        self.assertIn('MACRO_MISSING_OR_INVALID',self.run_safe()['reason_codes'])
    def test_unsafe_news(self):
        write_sample(self.root)
        p=self.root/m.OUTPUTS['news'][0];r=m.read_json(p);r['execution_permission']='ALLOWED';m.atomic_json(p,r)
        self.assertIn('NEWS_UNSAFE_AUTHORIZATION',self.run_safe()['reason_codes'])
    def test_news_unavailable(self):
        write_sample(self.root)
        p=self.root/m.OUTPUTS['news'][0];r=m.read_json(p);r['status']='UNAVAILABLE';m.atomic_json(p,r)
        self.assertIn('NEWS_ALL_SOURCES_UNAVAILABLE',self.run_safe()['reason_codes'])
    def test_news_bridge_unauthorized(self):
        write_sample(self.root)
        p=self.root/m.OUTPUTS['news'][1];r=m.read_json(p);r['advisory']['execution_permission']='ALLOWED';m.atomic_json(p,r)
        self.assertIn('NEWS_BRIDGE_AUTHORITY_VIOLATION',self.run_safe()['reason_codes'])
    def test_wrong_mt5_provenance(self):
        write_sample(self.root)
        p=self.root/m.OUTPUTS['mt5'][0];r=m.read_json(p);r['module_id']='M01';m.atomic_json(p,r)
        self.assertIn('MT5_M15_PROVENANCE_INVALID',self.run_safe()['reason_codes'])
    def test_disconnect(self):
        write_sample(self.root)
        p=self.root/m.OUTPUTS['mt5'][0];r=m.read_json(p);r['m10a_connection_status']='DISCONNECTED';m.atomic_json(p,r)
        self.assertIn('MT5_NOT_CONNECTED',self.run_safe()['reason_codes'])
    def test_macro_fail_closed(self):
        write_sample(self.root)
        p=self.root/m.OUTPUTS['macro'][0];r=m.read_json(p);r['integrity_status']='FAIL_CLOSED';m.atomic_json(p,r)
        self.assertIn('MACRO_AUDIT_NOT_VALID',self.run_safe()['reason_codes'])
    def test_bad_gate(self):
        write_sample(self.root)
        p=self.root/m.OUTPUTS['macro'][0];r=m.read_json(p);r['macro_gate']='PASS';m.atomic_json(p,r)
        self.assertIn('MACRO_UNEXPECTED_GATE',self.run_safe()['reason_codes'])
    def test_bad_decision(self):
        write_sample(self.root)
        p=self.root/m.OUTPUTS['macro'][0];r=m.read_json(p);r['guarded_display_decision']='ORDER_SEND';m.atomic_json(p,r)
        self.assertIn('MACRO_INVALID_DISPLAY_DECISION',self.run_safe()['reason_codes'])
    def test_stopped_process(self):
        write_sample(self.root)
        x=m.safe_status(self.root,T,BASE,{'mt5':{'status':'EXITED'}})
        self.assertEqual(x['system_state'],'DEGRADED')
    def test_bad_record_timestamp(self):
        write_sample(self.root)
        p=self.root/m.OUTPUTS['macro'][0];r=m.read_json(p);r['as_of']='bad';m.atomic_json(p,r)
        self.assertIn('MACRO_BAD_TIMESTAMP',self.run_safe()['reason_codes'])
    def test_no_fake_no_risk(self):
        write_sample(self.root)
        x=self.run_safe();self.assertEqual(x['risk_gate'],'BLOCKED')
    def test_research_flag(self):
        write_sample(self.root)
        self.assertTrue(self.run_safe()['research_only'])
    def test_no_screenshot(self):
        write_sample(self.root)
        self.assertFalse(self.run_safe()['screen_capture_enabled'])
    def test_guarded_display_not_trade(self):
        write_sample(self.root)
        p=self.root/m.OUTPUTS['macro'][0];r=m.read_json(p);r['guarded_display_decision']='LONG';m.atomic_json(p,r)
        self.assertEqual(self.run_safe()['decision'],'NO_TRADE')

class JournalLockTests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=pathlib.Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def test_sqlite_events(self):
        p=self.root/'j.db';j=m.Journal(p);j.append('mt5','STOPPED','x');j.close()
        with sqlite3.connect(p) as c:
            self.assertEqual(c.execute('select component,state,detail from events').fetchone(),('mt5','STOPPED','x'))
    def test_sqlite_durable(self):
        p=self.root/'j.db';j=m.Journal(p);j.append('macro','STARTING');j.close();j=m.Journal(p);j.append('mt5','RUNNING');j.close()
        with sqlite3.connect(p) as c:self.assertEqual(c.execute('select count(*) from events').fetchone()[0],2)
    def test_lock_exclusive(self):
        p=self.root/'lock'
        with m.Singleton(p):
            with self.assertRaises(RuntimeError):
                with m.Singleton(p):pass
    def test_lock_reusable(self):
        p=self.root/'lock'
        with m.Singleton(p):pass
        with m.Singleton(p):pass
    def test_run_snapshot_no_mt5(self):
        p=self.root/'core';p.mkdir();r=m.Supervisor(BASE,core=p,runtime=self.root/'runtime',enforce_integrity=False)
        with mock.patch.object(r,'_spawn',return_value=False):
            x=r.tick()
        self.assertEqual(x['decision'],'NO_TRADE')
        self.assertTrue((self.root/'runtime'/'M00U_SAFE_MONITOR.json').exists())
    def test_no_browser_network(self):
        p=self.root/'core';p.mkdir()
        result=m.safe_status(p,T,BASE)
        self.assertEqual(result['system_state'],'DEGRADED')

class SupervisorTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=pathlib.Path(self.tmp.name)
        self.core=self.root/'core';self.core.mkdir()
        for p in (self.core/'macro_sources',):p.mkdir()
        for script in ('macro_sources/M04N_ENGINE.py','RUN_MT5_OPERATIONAL_PROFILES_READONLY.py','M04N_MACRO_GUARD.py'):
            (self.core/script).write_text('import time\nwhile True:time.sleep(.02)\n')
    def tearDown(self):self.tmp.cleanup()
    def test_all_started_and_shutdown(self):
        sv=m.Supervisor(BASE,core=self.core,runtime=self.root/'runtime',enforce_integrity=False)
        try:
            x=sv.tick()
            self.assertEqual(set(x['processes']),set(m.PARTS))
            self.assertEqual(x['decision'],'NO_TRADE')
            self.assertTrue(all(w.proc is not None for w in sv.workers.values()))
        finally:sv.shutdown()
        self.assertTrue(all(w.proc is None for w in sv.workers.values()))
        self.assertEqual(m.read_json(self.root/'runtime'/'M00U_SAFE_MONITOR.json')['system_state'],'STOPPED')
    def test_disabled_credentials_in_child(self):
        sv=m.Supervisor(BASE,core=self.core,runtime=self.root/'runtime',enforce_integrity=False)
        with mock.patch.dict(os.environ,{'TELEGRAM_BOT_TOKEN':'SECRET','TELEGRAM_CHAT_ID':'chat'}):
            # Wrapped launcher to check child environment passed to Popen, then return a genuine short-lived process.
            captured={}
            def fake_launcher(*args,**kwargs):
                captured.update(kwargs['env'])
                return subprocess.Popen([sys.executable,'-c','import time;time.sleep(1)'],
                                        stdout=kwargs['stdout'],stderr=kwargs['stderr'],stdin=kwargs['stdin'])
            sv.launcher=fake_launcher
            try:sv._spawn(sv.workers['news'])
            finally:sv.shutdown()
            self.assertNotIn('TELEGRAM_BOT_TOKEN',captured)
            self.assertNotIn('TELEGRAM_CHAT_ID',captured)
    def test_crash_restarts(self):
        sv=m.Supervisor(BASE,core=self.core,runtime=self.root/'runtime',enforce_integrity=False)
        try:
            sv.tick();w=sv.workers['news']
            w.proc.kill();w.proc.wait(timeout=2)
            sv.tick()
            self.assertEqual(w.status,'EXITED')
            self.assertGreaterEqual(w.restarts,1)
        finally:sv.shutdown()
    def test_circuit_breaker(self):
        sv=m.Supervisor(conf(restart_limit=1),core=self.core,runtime=self.root/'runtime',enforce_integrity=False)
        w=sv.workers['news'];n=sv.clock();w.starts.extend([n-1,n])
        self.assertFalse(sv._spawn(w));self.assertEqual(w.status,'QUARANTINED')
    def test_manifest_tamper_detection(self):
        manifest={}
        for name in ('M04N_MACRO_GUARD.py','RUN_MT5_OPERATIONAL_PROFILES_READONLY.py'):
            import hashlib
            manifest[name]=hashlib.sha256((self.core/name).read_bytes()).hexdigest()
        path=self.root/'manifest.json';path.write_text(json.dumps(manifest))
        self.assertEqual(m.core_manifest(self.core,path),[])
        (self.core/'M04N_MACRO_GUARD.py').write_text('tampered')
        self.assertTrue(any('HASH_MISMATCH' in x for x in m.core_manifest(self.core,path)))
    def test_integrity_blocks_workers(self):
        sv=m.Supervisor(BASE,core=self.core,runtime=self.root/'runtime',enforce_integrity=True)
        self.assertEqual(sv.tick()['system_state'],'INTEGRITY_BLOCKED')
        self.assertTrue(all(w.proc is None for w in sv.workers.values()))
        sv.shutdown()
    def test_missing_child_script(self):
        (self.core/'M04N_MACRO_GUARD.py').unlink()
        sv=m.Supervisor(BASE,core=self.core,runtime=self.root/'runtime',enforce_integrity=False)
        try:sv.tick();self.assertEqual(sv.workers['macro'].status,'MISSING_SCRIPT')
        finally:sv.shutdown()
    def test_report_fresh_process(self):
        write_sample(self.core,now=dt.datetime.now(dt.timezone.utc))
        sv=m.Supervisor(BASE,core=self.core,runtime=self.root/'runtime',enforce_integrity=False)
        try:
            sv.tick();sv.tick()
            self.assertEqual(sv.workers['mt5'].status,'RUNNING')
        finally:sv.shutdown()

if __name__=='__main__':unittest.main()
