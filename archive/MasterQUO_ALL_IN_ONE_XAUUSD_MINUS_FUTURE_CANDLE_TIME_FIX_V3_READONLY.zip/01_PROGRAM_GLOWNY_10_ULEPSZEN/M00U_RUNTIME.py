#!/usr/bin/env python3
"""MasterQUO M00U v1.0.0: fail-closed supervisor of preserved read-only modules.

Runtime status does NOT certify trading readiness or authorize orders.  No external
network access except through the preserved optional macro collector and MT5.
"""
from __future__ import annotations
import argparse
import collections
import datetime as dt
import hashlib
import importlib.util
import json
import os
import re
import signal
import sqlite3
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CORE = ROOT / 'legacy_core'
RUNTIME = ROOT / 'runtime'
FORMAT_VERSION = '1.0.0-CANDIDATE'
PARTS = ('news', 'mt5', 'macro')
DEFAULT_AGES = {'news': 900, 'mt5': 25, 'macro': 20}
OUTPUTS = {
    'news': ('runtime/M04N/M04N_INTELLIGENCE.json', 'runtime/M04N/M04N_M04_CONTEXT_BRIDGE.json'),
    'mt5': ('runtime/M15/M15_MONITOR_SNAPSHOT.json',),
    'macro': ('runtime/M04N_GUARDED_MONITOR.json',)
}
REPORT_PATH = RUNTIME / 'M00U_SAFE_MONITOR.json'
LOCK_PATH = RUNTIME / 'M00U_SINGLETON.lock'
JOURNAL_PATH = RUNTIME / 'M00U_JOURNAL.sqlite'
CONFIG_KEYS = {
    'module_version','schema_version','prompt_version','mode','symbol','dxy_symbol',
    'terminal_path','poll_seconds','show_viewer','restart_limit','restart_window_seconds',
    'start_grace_seconds','max_report_age_seconds','research_only','enable_orders',
    'telegram_enabled','screen_capture_enabled'
}


def utcnow():
    return dt.datetime.now(dt.timezone.utc)


def timestamp(d):
    return d.astimezone(dt.timezone.utc).isoformat().replace('+00:00', 'Z')


def parse_time(s):
    if not isinstance(s, str):
        raise ValueError('TIME_NOT_STRING')
    d = dt.datetime.fromisoformat(s.replace('Z', '+00:00'))
    if d.utcoffset() is None:
        raise ValueError('NAIVE_TIME')
    return d.astimezone(dt.timezone.utc)


def config_from(obj):
    if not isinstance(obj, dict):
        raise ValueError('CONFIG_NOT_OBJECT')
    if set(obj) - CONFIG_KEYS:
        raise ValueError('UNKNOWN_CONFIG_KEY')
    for flag, required in [('research_only', True), ('enable_orders', False),
                            ('telegram_enabled', False), ('screen_capture_enabled', False)]:
        if obj.get(flag) is not required:
            raise ValueError('DANGEROUS_CONFIG_'+flag)
    if (obj.get('schema_version') != '2.0.0' or obj.get('prompt_version') != '4.1.0'):
        raise ValueError('CONTRACT_VERSION_MISMATCH')
    if obj.get('mode') not in ('AUTO','MVP','SMC','SCALPING'):
        raise ValueError('UNKNOWN_MODE')
    if not isinstance(obj.get('symbol'), str) or not re.fullmatch(r'[A-Za-z0-9_.-]{2,32}',obj['symbol']):
        raise ValueError('INVALID_SYMBOL')
    if obj.get('dxy_symbol') is not None and (
        not isinstance(obj['dxy_symbol'], str) or
        not re.fullmatch(r'[A-Za-z0-9_.-]{2,32}', obj['dxy_symbol'])):
        raise ValueError('INVALID_DXY_SYMBOL')
    path = obj.get('terminal_path')
    if path is not None and (not isinstance(path, str) or not path.strip()):
        raise ValueError('INVALID_TERMINAL_PATH')
    if type(obj.get('show_viewer')) is not bool:
        raise ValueError('INVALID_VIEWER_FLAG')
    numbers = {'poll_seconds':(0.25,60),'restart_limit':(0,20),
               'restart_window_seconds':(30,86400),'start_grace_seconds':(1,3600)}
    for k,(lower,upper) in numbers.items():
        v=obj.get(k)
        if type(v) not in (int,float) or not lower<=v<=upper:
            raise ValueError('INVALID_'+k)
    if type(obj['restart_limit']) is not int:
        raise ValueError('INVALID_RESTART_LIMIT')
    ages=obj.get('max_report_age_seconds')
    if not isinstance(ages,dict) or set(ages)!=set(PARTS):
        raise ValueError('INVALID_REPORT_AGES')
    for k,v in ages.items():
        if type(v) not in (int,float) or not 2<=v<=3600:
            raise ValueError('INVALID_REPORT_AGE_'+k)
    return obj


def load_config(path):
    return config_from(json.loads(Path(path).read_text(encoding='utf-8')))


def atomic_json(path,obj):
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+'.'+str(os.getpid())+'.tmp')
    try:
        with tmp.open('w',encoding='utf-8') as f:
            json.dump(obj,f,indent=2,ensure_ascii=False,allow_nan=False)
            f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        try:tmp.unlink(missing_ok=True)
        except OSError:pass


def read_json(path):
    try:
        raw=Path(path).read_bytes()
        if len(raw)>15_000_000:
            return None
        result=json.loads(raw)
        return result if isinstance(result,dict) else None
    except (OSError,UnicodeError,ValueError):
        return None


def age_check(record,now,max_age,required_blocked=True,time_field="as_of"):
    if not isinstance(record,dict):
        return 'MISSING_OR_INVALID'
    try:
        age=(now-parse_time(record[time_field])).total_seconds()
    except (KeyError,ValueError,TypeError,OverflowError):
        return 'BAD_TIMESTAMP'
    if age < -2:
        return 'FUTURE_TIMESTAMP'
    if age > max_age:
        return 'STALE'
    if required_blocked and record.get('execution_permission') != 'BLOCKED':
        return 'UNSAFE_AUTHORIZATION'
    return 'FRESH'


def safe_status(core,now,config,processes=None):
    """Read-only snapshot; unavailable/uncertain dependency always NO_TRADE.

    Never upgrades a source safety gate to PASS; never conveys execution eligibility.
    """
    ages=config['max_report_age_seconds']
    reports={}
    problems=[]
    for part,paths in OUTPUTS.items():
        checked=[]
        for rel in paths:
            record=read_json(Path(core)/rel)
            code=age_check(record,now,ages[part],time_field='m15_published_at' if part=='mt5' else 'as_of')
            if code != 'FRESH':
                problems.append(part.upper()+'_'+code)
            checked.append({'path':rel,'status':code})
        reports[part]=checked
    technical_market=read_json(Path(core)/OUTPUTS['mt5'][0])
    if isinstance(technical_market,dict) and age_check(technical_market,now,ages['mt5']) != 'FRESH':
        problems.append('MT5_MARKET_OBSERVATION_NOT_CURRENT')
    feed=read_json(Path(core)/OUTPUTS['news'][0])
    bridge=read_json(Path(core)/OUTPUTS['news'][1])
    macro=read_json(Path(core)/OUTPUTS['macro'][0])
    tech=read_json(Path(core)/OUTPUTS['mt5'][0])
    if feed and feed.get('module_id')!='M04N':
        problems.append('NEWS_PROVENANCE_INVALID')
    if feed and feed.get('status')=='UNAVAILABLE':
        problems.append('NEWS_ALL_SOURCES_UNAVAILABLE')
    if bridge and bridge.get('module_id')!='M04N':
        problems.append('NEWS_BRIDGE_PROVENANCE_INVALID')
    if bridge and ((bridge.get('advisory') or {}).get('execution_permission')!='BLOCKED'):
        problems.append('NEWS_BRIDGE_AUTHORITY_VIOLATION')
    if macro and macro.get('module_id')!='M04N_MACRO_GUARD':
        problems.append('MACRO_PROVENANCE_INVALID')
    if macro and macro.get('integrity_status')!='VALID_PARTIAL':
        problems.append('MACRO_AUDIT_NOT_VALID')
    if tech and tech.get('module_id')!='M15':
        problems.append('MT5_M15_PROVENANCE_INVALID')
    if tech and tech.get('m10a_connection_status')!='CONNECTED':
        problems.append('MT5_NOT_CONNECTED')
    if macro and age_check(macro,now,ages['macro'])=='FRESH':
        if macro.get('guarded_display_decision') not in ('WAIT','NO_TRADE','LONG','SHORT'):
            problems.append('MACRO_INVALID_DISPLAY_DECISION')
        if macro.get('macro_gate') not in ('PENDING','BLOCKED'):
            problems.append('MACRO_UNEXPECTED_GATE')
    if tech and age_check(tech,now,ages['mt5'],time_field='m15_published_at')=='FRESH':
        if tech.get('execution_permission')!='BLOCKED':
            problems.append('TECHNICAL_AUTHORITY_VIOLATION')
    processes=processes or {}
    for part in PARTS:
        ps=processes.get(part)
        if ps and ps.get('status') not in ('RUNNING','STARTING'):
            problems.append(part.upper()+'_PROCESS_'+str(ps.get('status')))
    good = not problems
    return {
        'module_id':'M00U','module_version':FORMAT_VERSION,
        'schema_version':'2.0.0','prompt_version':'4.1.0',
        'as_of':timestamp(now),'mt5_symbol':config['symbol'],
        'data_source_policy':'MT5_PRIMARY_TV_SUPPLEMENTAL_NO_SCREENSHOTS',
        'processes':processes,'inputs':reports,
        'system_state': 'RUNNING_DIAGNOSTIC' if good else 'DEGRADED',
        'diagnostic_m14_decision': (macro.get('m14_original_decision') if macro and good else None),
        'diagnostic_macro_gate': (macro.get('macro_gate') if macro and good else 'BLOCKED'),
        'diagnostic_guarded_display': (macro.get('guarded_display_decision') if macro and good else None),
        'decision':'NO_TRADE',
        'reason_codes':sorted(set(problems)) or ['RESEARCH_ONLY_LIVE_VALIDATION_PENDING'],
        'research_only':True,'execution_permission':'BLOCKED',
        'execution_eligible':False,'order_execution_enabled':False,
        'telegram_send_enabled':False,'screen_capture_enabled':False,
        'risk_gate':'BLOCKED','live_certified':False,
        'notes':'M00U is a diagnostic supervisor, not a production execution firewall.'
    }


class Singleton:
    def __init__(self,path):
        self.path=Path(path);self.f=None
    def __enter__(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.f=self.path.open('a+b')
        self.f.seek(0,os.SEEK_END)
        if self.f.tell()==0:
            self.f.write(b'\0');self.f.flush()
        self.f.seek(0)
        try:
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(self.f.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(self.f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError:
            self.f.close();self.f=None
            raise RuntimeError('ALREADY_RUNNING')
        return self
    def __exit__(self,*exc):
        if self.f:
            try:
                self.f.seek(0)
                if os.name=='nt':
                    import msvcrt
                    msvcrt.locking(self.f.fileno(),msvcrt.LK_UNLCK,1)
                else:
                    import fcntl
                    fcntl.flock(self.f.fileno(),fcntl.LOCK_UN)
            finally:
                self.f.close()


class Journal:
    def __init__(self,path):
        path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
        self.db=sqlite3.connect(str(path),timeout=20)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT, at_utc TEXT NOT NULL, component TEXT NOT NULL, state TEXT NOT NULL, detail TEXT NOT NULL)')
        self.db.commit()
    def append(self,component,state,detail=''):
        self.db.execute('INSERT INTO events(at_utc,component,state,detail) VALUES(?,?,?,?)',
                        (timestamp(utcnow()),str(component),str(state),str(detail)[:1000]))
        self.db.commit()
    def close(self):self.db.close()


def core_manifest(core=CORE, manifest_path=ROOT/'CORE_MANIFEST_SHA256.json'):
    """Return source-file mismatches; fail before starting if binaries were modified.

    This is an integrity check, not a cryptographic signature. A user who can edit
    both the source and the manifest can bypass it; OS file permissions still matter.
    """
    core=Path(core)
    try:
        manifest=json.loads(Path(manifest_path).read_text(encoding='utf-8'))
        if not isinstance(manifest,dict) or not manifest:
            return ['MANIFEST_INVALID']
    except (OSError,ValueError,UnicodeError):
        return ['MANIFEST_MISSING']
    errors=[]
    for rel,expected in manifest.items():
        if not isinstance(rel,str) or not isinstance(expected,str) or not re.fullmatch(r'[a-f0-9]{64}',expected):
            errors.append('INVALID_MANIFEST_ENTRY');continue
        path=Path(rel)
        if path.is_absolute() or '..' in path.parts:
            errors.append('UNSAFE_MANIFEST_PATH');continue
        target=core/path
        try:
            if target.is_symlink():raise OSError('SOURCE_SYMLINK')
            got=hashlib.sha256(target.read_bytes()).hexdigest()
            if got!=expected:errors.append('HASH_MISMATCH:'+rel)
        except OSError:
            errors.append('SOURCE_MISSING:'+rel)
    return errors


def command_for(part,config,core=CORE,python=sys.executable):
    """No arbitrary shell commands, plugin execution, Telegram or order flags."""
    config_from(config)
    core=Path(core)
    if part=='news':
        return [python,'-u',str(core/'macro_sources'/'M04N_ENGINE.py'),
                '--config',str(core/'macro_sources'/'M04N_CONFIG.json'),
                '--runtime',str(core/'runtime'/'M04N')]
    if part=='mt5':
        cmd=[python,'-u',str(core/'RUN_MT5_OPERATIONAL_PROFILES_READONLY.py'),
             '--mode',config['mode'],'--symbol',config['symbol']]
        if config['dxy_symbol']:cmd.extend(['--dxy-symbol',config['dxy_symbol']])
        if config.get('terminal_path'):cmd.extend(['--terminal-path',config['terminal_path']])
        return cmd
    if part=='macro':
        return [python,'-u',str(core/'M04N_MACRO_GUARD.py')]
    raise ValueError('COMPONENT_NOT_ALLOWED')


@dataclass
class Worker:
    name:str
    proc:object=None
    started:float=0
    starts:collections.deque=field(default_factory=collections.deque)
    next_start:float=0
    status:str='STOPPED'
    restarts:int=0
    log:object=None


class Supervisor:
    def __init__(self,config,core=CORE,runtime=RUNTIME,clock=time.monotonic,now=utcnow,launcher=None,
                 enforce_integrity=True):
        self.config=config_from(config)
        self.core=Path(core);self.runtime=Path(runtime)
        self.clock=clock;self.now=now
        self.launcher=launcher or subprocess.Popen
        self.workers={n:Worker(n) for n in PARTS}
        self._last_fingerprint=None
        self._journal=None
        self.enforce_integrity=enforce_integrity
        self._integrity_last=0
        self._integrity_error=[]

    def attach_journal(self):
        self._journal=Journal(self.runtime/'M00U_JOURNAL.sqlite')

    def note(self,who,state,detail=''):
        if self._journal:self._journal.append(who,state,detail)

    def _spawn(self,worker):
        n=self.clock()
        window=self.config['restart_window_seconds']
        while worker.starts and n-worker.starts[0]>window:
            worker.starts.popleft()
        if len(worker.starts)>self.config['restart_limit']:
            worker.status='QUARANTINED'
            return False
        command=command_for(worker.name,self.config,self.core)
        script=Path(command[2])
        if not script.is_file():
            worker.status='MISSING_SCRIPT';self.note(worker.name,'MISSING_SCRIPT',str(script))
            return False
        self.runtime.mkdir(parents=True,exist_ok=True)
        logfile=self.runtime/('M00U_'+worker.name+'.log')
        if logfile.exists() and logfile.stat().st_size>2_000_000:
            old=logfile.with_suffix('.log.1')
            os.replace(logfile,old)
        worker.log=logfile.open('ab',buffering=0)
        env=os.environ.copy()
        env.pop('TELEGRAM_BOT_TOKEN',None);env.pop('TELEGRAM_CHAT_ID',None)
        env['MASTERQUO_EXECUTION_DISABLED']='1'
        env['PYTHONUNBUFFERED']='1'
        try:
            worker.proc=self.launcher(command,cwd=str(self.core),env=env,
                stdin=subprocess.DEVNULL,stdout=worker.log,stderr=subprocess.STDOUT)
        except (OSError,ValueError) as exc:
            worker.log.close();worker.log=None
            worker.status='LAUNCH_FAILED';worker.next_start=n+10
            self.note(worker.name,'LAUNCH_FAILED',type(exc).__name__)
            return False
        worker.started=n
        worker.starts.append(n)
        worker.status='STARTING';self.note(worker.name,'STARTING','pid '+str(worker.proc.pid))
        return True

    def _stop_one(self,worker):
        if worker.proc and worker.proc.poll() is None:
            try:
                worker.proc.terminate()
                worker.proc.wait(timeout=4)
            except (OSError,subprocess.TimeoutExpired):
                try:worker.proc.kill();worker.proc.wait(timeout=3)
                except (OSError,subprocess.TimeoutExpired):pass
        worker.proc=None
        if worker.log:
            worker.log.close();worker.log=None
        worker.status='STOPPED'

    def tick(self):
        n=self.clock();now=self.now()
        if self.enforce_integrity and (self._integrity_last==0 or n-self._integrity_last>=20):
            self._integrity_error=core_manifest(self.core)
            self._integrity_last=n
        if self._integrity_error:
            for worker in self.workers.values():
                if worker.proc is not None:self._stop_one(worker)
                worker.status='INTEGRITY_BLOCKED'
            safe=safe_status(self.core,now,self.config,
                {x:{'status':'INTEGRITY_BLOCKED','pid':None} for x in PARTS})
            safe['system_state']='INTEGRITY_BLOCKED'
            safe['reason_codes']=sorted(set(safe['reason_codes']+self._integrity_error))
            atomic_json(self.runtime/'M00U_SAFE_MONITOR.json',safe)
            return safe
        for name,worker in self.workers.items():
            if worker.status in ('QUARANTINED','MISSING_SCRIPT'):
                continue
            if worker.proc:
                exit_code=worker.proc.poll()
                if exit_code is not None:
                    worker.status='EXITED';worker.proc=None
                    if worker.log:worker.log.close();worker.log=None
                    worker.restarts+=1
                    worker.next_start=n+min(60,2**min(worker.restarts,6))
                    self.note(name,'EXITED','code '+str(exit_code))
                else:
                    output=OUTPUTS[name]
                    maxage=self.config['max_report_age_seconds'][name]
                    checks=[age_check(read_json(self.core / p),now,maxage,
                            time_field='m15_published_at' if name=='mt5' else 'as_of') for p in output]
                    fresh=all(c=='FRESH' for c in checks)
                    if fresh:
                        worker.status='RUNNING'
                    elif n-worker.started > self.config['start_grace_seconds']:
                        worker.status='OUTPUT_UNHEALTHY'
                        if n-worker.started>max(maxage*2,self.config['start_grace_seconds']*2):
                            self.note(name,'RESTART_UNHEALTHY',','.join(checks))
                            self._stop_one(worker)
                            worker.restarts+=1
                            worker.next_start=n+min(60,2**min(worker.restarts,6))
                    else:
                        worker.status='STARTING'
            if worker.proc is None and n>=worker.next_start and worker.status not in ('QUARANTINED','MISSING_SCRIPT'):
                self._spawn(worker)
        processes={name:{'status':w.status,'pid':w.proc.pid if w.proc else None,
                         'restart_count':w.restarts} for name,w in self.workers.items()}
        safe=safe_status(self.core,now,self.config,processes)
        atomic_json(self.runtime/'M00U_SAFE_MONITOR.json',safe)
        fingerprint=(safe['system_state'],tuple(safe['reason_codes']),tuple((n,w.status) for n,w in self.workers.items()))
        if fingerprint != self._last_fingerprint:
            self.note('M00U',safe['system_state'],','.join(safe['reason_codes']))
            self._last_fingerprint=fingerprint
        return safe

    def shutdown(self):
        for worker in reversed(list(self.workers.values())):
            self._stop_one(worker)
        safe=safe_status(self.core,self.now(),self.config,
                         {n:{'status':'STOPPED','pid':None} for n in PARTS})
        safe['reason_codes']=sorted(set(safe['reason_codes']+['SUPERVISOR_STOPPED']))
        safe['system_state']='STOPPED'
        atomic_json(self.runtime/'M00U_SAFE_MONITOR.json',safe)
        self.note('M00U','STOPPED','All child processes stopped')
        if self._journal:self._journal.close();self._journal=None

    def run(self,duration=None):
        self.attach_journal()
        start=self.clock()
        try:
            while duration is None or self.clock()-start<duration:
                if (self.runtime/'M00U_STOP.request').exists():
                    (self.runtime/'M00U_STOP.request').unlink(missing_ok=True)
                    break
                report=self.tick()
                print(timestamp(self.now()),report['system_state'],report['decision'],
                      'MT5:',self.workers['mt5'].status,'MACRO:',self.workers['macro'].status,flush=True)
                time.sleep(self.config['poll_seconds'])
        except KeyboardInterrupt:
            pass
        finally:
            self.shutdown()
        return 0


def doctor(config,core=CORE):
    config_from(config)
    details={'Python':sys.version.split()[0], 'Python_path':sys.executable,
             'MT5_symbol':config['symbol'],'mode':config['mode'],
             'internet_collector_needed':True,'orders_enabled':False,'telegram_enabled':False}
    for module in ('MetaTrader5','numpy','tzdata'):
        details[module+'_installed']=importlib.util.find_spec(module) is not None
    core=Path(core)
    for name in PARTS:
        cmd=command_for(name,config,core)
        details[name+'_script_exists']=Path(cmd[2]).is_file()
    details['core_manifest_errors']=core_manifest(core)
    details['Windows_MT5_connection_tested']=False
    details['ready_to_install_on_windows']=(all(details[n+'_script_exists'] for n in PARTS)
                                       and not details['core_manifest_errors'])
    details['ready_for_local_trial']=(sys.platform=='win32' and details['ready_to_install_on_windows']
                                      and details['MetaTrader5_installed'] and details['numpy_installed'])
    return details


def main(argv=None):
    parser=argparse.ArgumentParser(description='MasterQUO M00U fail-closed read-only process supervisor')
    parser.add_argument('action',choices=['doctor','run','snapshot','stop'],nargs='?',default='doctor')
    parser.add_argument('--config',default=str(ROOT/'M00U_CONFIG.json'))
    parser.add_argument('--duration-seconds',type=float)
    parser.add_argument('--with-viewer',action='store_true')
    args=parser.parse_args(argv)
    try:cfg=load_config(args.config)
    except (OSError,ValueError,json.JSONDecodeError) as exc:
        print('CONFIG_ERROR',str(exc),file=sys.stderr);return 2
    if args.action=='doctor':
        print(json.dumps(doctor(cfg),ensure_ascii=False,indent=2));return 0
    if args.action=='snapshot':
        report=safe_status(CORE,utcnow(),cfg)
        errors=core_manifest(CORE)
        if errors:
            report['system_state']='INTEGRITY_BLOCKED'
            report['reason_codes']=sorted(set(report['reason_codes']+errors))
        atomic_json(REPORT_PATH,report)
        print(json.dumps(report,ensure_ascii=False,indent=2));return 0
    if args.action=='stop':
        RUNTIME.mkdir(exist_ok=True,parents=True)
        (RUNTIME/'M00U_STOP.request').write_text(timestamp(utcnow()),encoding='utf-8')
        print('STOP_REQUESTED');return 0
    if args.duration_seconds is not None and not 0<=args.duration_seconds<=86400:
        parser.error('duration must be 0..86400 seconds')
    problems=core_manifest(CORE)
    if problems:
        print('SOURCE_INTEGRITY_FAILED',','.join(problems),file=sys.stderr)
        return 3
    with Singleton(LOCK_PATH):
        supervisor=Supervisor(cfg)
        viewer=None
        if args.with_viewer:
            # The viewer is a convenience UI, never a trade-execution interface.
            env=os.environ.copy();env.pop('TELEGRAM_BOT_TOKEN',None);env.pop('TELEGRAM_CHAT_ID',None)
            viewer=subprocess.Popen([sys.executable,str(ROOT/'M00U_VIEWER.py')],cwd=str(ROOT),env=env)
        try:
            return supervisor.run(args.duration_seconds)
        finally:
            if viewer is not None and viewer.poll() is None:
                viewer.terminate()
                try:viewer.wait(timeout=2)
                except subprocess.TimeoutExpired:viewer.kill()

if __name__=='__main__':
    raise SystemExit(main())
