"""Safe GUI: only M00U status, never a direct trading view."""
from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import json
import tkinter as tk
from tkinter import ttk
FILE=Path(__file__).resolve().parent/'runtime'/'M00U_SAFE_MONITOR.json'
class Monitor:
    def __init__(self):
        self.root=tk.Tk()
        self.root.title('MASTERQUO — Unified Runtime | READ ONLY')
        self.root.geometry('920x650')
        self.header=tk.StringVar(value='NO_TRADE / BLOCKED')
        ttk.Label(self.root,text='MASTERQUO — STAN MODUŁÓW I BEZPIECZEŃSTWO',font=('Segoe UI',15,'bold')).pack(pady=14)
        ttk.Label(self.root,textvariable=self.header,font=('Segoe UI',13)).pack(pady=8)
        self.detail=tk.Text(self.root,wrap='word',font=('Consolas',10))
        self.detail.pack(fill='both',expand=True,padx=12,pady=12)
        self.detail.config(state='disabled')
        self.root.after(200,self.tick)
    def tick(self):
        try:
            doc=json.loads(FILE.read_text(encoding='utf-8'))
            time=datetime.fromisoformat(doc['as_of'].replace('Z','+00:00'))
            delay=(datetime.now(timezone.utc)-time).total_seconds()
            if time.utcoffset() is None or not 0<=delay<=8:raise ValueError('STALE')
            if (doc.get('module_id')!='M00U' or doc.get('execution_permission')!='BLOCKED' or
                doc.get('decision')!='NO_TRADE' or doc.get('order_execution_enabled') is not False):
                raise ValueError('UNSAFE_REPORT')
            self.header.set(str(doc.get('system_state'))+' | NO_TRADE | BLOCKED')
            lines=['ZRODLO CEN: MT5 | TELEGRAM: WYŁĄCZONY | ZLECENIA: BLOKADA',
                   'TRYB: DIAGNOSTYCZNY / CANDIDATE',
                   '\nSTATUS PROCESÓW:']
            for name,data in sorted((doc.get('processes') or {}).items()):
                lines.append(f"  {name:8}  {(data or {}).get('status'):20}  PID={(data or {}).get('pid')}")
            lines+=['\nKONTROLA PLIKÓW:']
            for name,files in (doc.get('inputs') or {}).items():
                for f in files:lines.append(f"  {name:6}  {f.get('status'):22} {f.get('path')}")
            lines+=['\nPRZYCZYNY:']+['  '+str(x) for x in doc.get('reason_codes',[])[:20]]
            lines+=['\nKIERUNEK M14 (TYLKO DIAGNOSTYKA): '+str(doc.get('diagnostic_m14_decision')),
                    'RYZYKO MAKRO: '+str(doc.get('diagnostic_macro_gate'))]
            txt='\n'.join(lines)
        except (OSError,ValueError,KeyError,TypeError,UnicodeError):
            self.header.set('BRAK AKTUALNYCH DANYCH | NO_TRADE | BLOCKED')
            txt='Raport jest niedostępny, nieaktualny lub niespójny. Nie używaj starych sygnałów.'
        self.detail.config(state='normal');self.detail.delete('1.0','end');self.detail.insert('1.0',txt)
        self.detail.config(state='disabled');self.root.after(1000,self.tick)
    def run(self):self.root.mainloop()
if __name__=='__main__':Monitor().run()
