#!/usr/bin/env python3
"""Single-pass, read-only evaluation of 10 MasterQUO candidate improvements.

This CLI consumes explicit as-of evidence. It NEVER sends broker orders or Telegram.
Only stage 01 is a long-running runtime supervisor (M00U_RUNTIME.py).
Stages 02..10 are deterministic analytical consumers, not a market data feed.
"""
from __future__ import annotations
import argparse
import json
import pathlib
from datetime import datetime,timezone
from mq_upgrades.common import safe_json,when,fingerprint
from mq_upgrades import u02_regime,u03_execution,u04_oos,u05_calibration,u06_liquidity,u07_crossmarket,u08_surprise,u09_learning,u10_explain

ROOT=pathlib.Path(__file__).resolve().parent


def run_all(context):
    if not isinstance(context,dict):raise ValueError('CONTEXT_NOT_OBJECT')
    now=when(context['as_of'])
    if context.get('orders_enabled') is True or context.get('telegram_enabled') is True:
        raise ValueError('READ_ONLY_INPUT_REQUIRED')
    inputs={}
    runtime=context.get('runtime',{})
    inputs['runtime']={'status':'PASS' if runtime.get('system_state')=='RUNNING_DIAGNOSTIC' else 'PENDING',
                       'system_state':runtime.get('system_state','MISSING'),
                       'execution_permission':'BLOCKED'}
    bars=context.get('bars') or {}
    # Closed-candle proof is mandatory for user-supplied replay bars. A bar's open
    # timestamp alone does not show that its close was observable at 'as_of'.
    for timeframe, rows in bars.items():
        if not isinstance(rows,list):raise ValueError('INVALID_BAR_COLLECTION')
        for row in rows:
            if not isinstance(row,dict) or row.get('closed') is not True:
                raise ValueError('OPEN_OR_INVALID_BAR')
            if 'available_at' not in row:raise ValueError('MISSING_CANDLE_AVAILABILITY')
            if when(row['available_at'])>now:raise ValueError('FUTURE_CANDLE_AVAILABILITY')
            if when(row['time'])>when(row['available_at']):raise ValueError('CANDLE_TIME_AFTER_AVAILABILITY')
    inputs['regime']=u02_regime.analyze(bars.get('H1',[]))
    inputs['liquidity']=u06_liquidity.analyze(bars.get('M5',[]))
    quote=context.get('quote') or {}
    econ=context.get('economics') or {}
    inputs['execution']=u03_execution.estimate(quote,context.get('side','LONG'),
                     econ.get('lots'),econ.get('commission_per_lot_side'),
                     econ.get('money_per_price_unit_per_lot'),econ.get('slippage_price'),
                     econ.get('stop_distance'),econ.get('target_distance'),as_of=now)
    folds=context.get('folds') or {}
    inputs['oos']=u04_oos.validate(context.get('trades',[]),folds.get('dev_end','2000-01-01T00:00:00Z'),
                      folds.get('oos_start','2000-01-02T00:00:00Z'),
                      min_oos=folds.get('min_oos',50),embargo_seconds=folds.get('embargo_seconds',0))
    confidence=context.get('confidence') or {}
    inputs['calibration']=u05_calibration.evaluate(context.get('predictions',[]),
                  confidence.get('frozen_at','2000-01-01T00:00:00Z'),
                  confidence.get('oos_start','2000-01-02T00:00:00Z'),
                  min_oos=confidence.get('min_oos',50))
    inputs['cross_market']=u07_crossmarket.analyze(context.get('cross_market',{}),now)
    inputs['surprise']=u08_surprise.analyze(context.get('macro_events',[]),now,
                           context.get('surprise_std',{}))
    learning=context.get('learning') or {}
    inputs['learning']=u09_learning.propose(learning.get('current',{}),
                learning.get('candidate',{}), learning.get('dev_report',{}),
                learning.get('oos_report'),as_of=now)
    expl=u10_explain.explain(now,inputs,context.get('technical_decision','WAIT'),
                  notes=['No trade authorization','Partial evidence is not absence of risk'])
    return {'module_id':'M00U_10_CANDIDATES','schema_version':'2.0.0',
            'as_of':now.isoformat().replace('+00:00','Z'),
            'source_fingerprint':fingerprint(context),'stages':inputs,'summary':expl,
            'status':'CANDIDATE','execution_permission':'BLOCKED','research_only':True}


def main(argv=None):
    p=argparse.ArgumentParser(description='Research-only 10 upgrades; no orders or Telegram')
    p.add_argument('--input',required=True,help='Frozen as-of JSON input evidence; no live pricing assumed')
    p.add_argument('--output',default='runtime/M00U10_REPORT.json')
    args=p.parse_args(argv)
    try:
        src=pathlib.Path(args.input);context=json.loads(src.read_text(encoding='utf-8'))
        result=run_all(context)
        safe_json(args.output,result)
        print('Report:',args.output,'status:',result['summary']['system_status'],'execution=BLOCKED')
        return 0
    except (OSError,ValueError,KeyError,TypeError) as e:
        print('INPUT_REJECTED',type(e).__name__,str(e))
        return 2
if __name__=='__main__':raise SystemExit(main())
