# MasterQUO 10 stages — audit checklist

**Build**: 2026-10-08, `v1.0.0-CANDIDATE`, Python standard library for new analyzers; optional MetaTrader5 package on Windows.

- `M00U_TESTS.py`: **76 tests PASS**, unchanged M00U supervisor; minor Python resource warnings observed from legacy test fixtures, no failing assertions.
- `tests/TEST_UPGRADES.py`: sequential units for U02–U10, evidence and safety gates.
- `tests/TEST_MT5_ADAPTER.py`: FakeMT5 closed-bar assembly, optional DXY, no real broker connection.
- `tests/TEST_VIEWER.py`: missing/stale/untrusted report fail closed.
- Total unique newly authored tests: **86 PASS**; M00U regressions: **76 PASS**, combined **162 PASS**. Incremental stage tests derive from the above unit cases and are not independent extra coverage.
- Extra verification: SHA-256 of each ZIP payload, `zipfile.testzip()`, preserved 130-source manifest, extract-and-retest each stage, JSON smoke export with `NO_TRADE/BLOCKED`.

**NOT PERFORMED**: native Windows MT5 trading terminal interaction, broker-specific commission/contract-value reconciliation, live DXY availability, historical net PnL, real FF/MM news-signal predictive value, OOS validation of trading edge, forward DEMO, latency/long-soak reliability, live Telegram, actual trading.

**Critical limitations**: U04 requires unaltered dated closed trades; U05 requires timestamped predictions and labels; U08 requires an archived actual release and forecast-vintage records, not today's calendar. U09 never applies a strategy change. U03 estimates round-trip costs for *scenarios*, not execution, and needs explicit account economics. U10 is a research-display gate, not a replacement for M14.

**Release gate**: `CANDIDATE/PENDING APPROVAL`, no order execution, no auto-learning promotions, no live performance claims.
