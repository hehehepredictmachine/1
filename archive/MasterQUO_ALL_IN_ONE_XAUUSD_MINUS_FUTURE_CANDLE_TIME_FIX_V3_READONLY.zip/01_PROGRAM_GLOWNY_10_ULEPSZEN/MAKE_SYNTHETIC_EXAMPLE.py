#!/usr/bin/env python3
"""Small deterministic illustration. Never interpret as backtest alpha."""
import json
from pathlib import Path
from datetime import datetime,timedelta,timezone
from mq_upgrades.common import safe_json
ROOT=Path(__file__).resolve().parent
T=datetime(2026,10,8,12,tzinfo=timezone.utc)
def stamp(t):return t.isoformat().replace('+00:00','Z')
def candles(n,step):
    base=T-step*n
    r=[]
    for i in range(n):
        opening=base+i*step
        closing=opening+step
        p=2600+0.35*i + (i%5-2)*0.1
        r.append({'time':stamp(opening),'available_at':stamp(closing),
             'open':p,'high':p+0.8,'low':p-0.8,'close':p+0.2,
             'closed':True,'tick_volume':50+i%6})
    return r
bars={'H1':candles(75,timedelta(hours=1)),'M5':candles(75,timedelta(minutes=5))}
cross={key:[{'time':x['available_at'],'close':x['close'] if key=='XAUUSD' else 101-i*0.03+(i%4)*0.02}
          for i,x in enumerate(bars['H1'])] for key in ('XAUUSD','DXY')}
demo={'demo_only':True,'as_of':stamp(T),'runtime':{'system_state':'MISSING'},
   'technical_decision':'WAIT','bars':bars,'cross_market':cross,
   'quote':{'time':stamp(T),'bid':2700.15,'ask':2700.4},
   'economics':{'lots':.01,'commission_per_lot_side':2.5,
       'money_per_price_unit_per_lot':100.,'slippage_price':.04,
       'stop_distance':3.,'target_distance':6.},
   'macro_events':[{'event_id':'SYNTHETIC_CPI','type':'CPI',
       'scheduled_at':stamp(T-timedelta(hours=2)),
       'schedule_first_seen_at':stamp(T-timedelta(days=3)),
       'forecast_recorded_at':stamp(T-timedelta(days=1)),
       'actual_published_at':stamp(T-timedelta(hours=2)+timedelta(minutes=1)),
       'forecast':2.4,'actual':2.7}],
   'surprise_std':{'CPI':0.2},'orders_enabled':False,'telegram_enabled':False,
   'folds':{'dev_end':stamp(T-timedelta(days=100)), 'oos_start':stamp(T-timedelta(days=90))},
   'learning':{},'trades':[],'predictions':[]}
safe_json(ROOT/'examples'/'SYNTHETIC_CONTEXT.json',demo)
print('examples/SYNTHETIC_CONTEXT.json written (SYNTHETIC TEST ONLY)')
