@echo off
cd /d "%~dp0"
py -3 M00U10_VIEWER.py --file runtime\M00U10_MT5_REPORT.json
pause
