@echo off
setlocal
cd /d "%~dp001_PROGRAM_GLOWNY_10_ULEPSZEN"
"%~dp0.venv\Scripts\python.exe" M00U10_MT5_READONLY_ADAPTER.py --symbol XAUUSD- --every-seconds 15
if errorlevel 1 echo [MASTERQUO] Adapter MT5 zakonczyl sie z bledem.
pause
