﻿@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
set "BOTPY=%~dp0.venv\Scripts\python.exe"
echo ======================================================
echo MASTERQUO - BEZPIECZNA INSTALACJA PYTHON V2 - READONLY
echo Preferowany Python 3.13 x64 / fallback 3.12 lub zdrowy 3.14.
echo ======================================================
echo.
if exist "%BOTPY%" (
  "%BOTPY%" -c "import sys,struct;sys.exit(0 if sys.platform=='win32' and struct.calcsize('P')==8 else 1)" >nul 2>&1
  if not errorlevel 1 (
    "%BOTPY%" -m pip --version >nul 2>&1
    if not errorlevel 1 goto PACKAGES
  )
  echo [UWAGA] Wykryto niekompletne lub uszkodzone srodowisko .venv.
  call :ARCHIVE_OLD
  if errorlevel 1 goto STOP_ERROR
) else (
  if exist ".venv\" (
    echo [UWAGA] Wykryto niedokonczony folder .venv.
    call :ARCHIVE_OLD
    if errorlevel 1 goto STOP_ERROR
  )
)
where py >nul 2>&1
if errorlevel 1 goto NO_PYTHON
call :CREATE_WITH 3.13
if not errorlevel 1 goto PACKAGES
call :CREATE_WITH 3.12
if not errorlevel 1 goto PACKAGES
call :CREATE_WITH 3.14
if not errorlevel 1 goto PACKAGES
goto NO_HEALTHY_PYTHON
:PACKAGES
echo.
echo [2/3] Sprawdzam pip izolowanego Pythona ...
"%BOTPY%" -m pip --version >nul 2>&1
if errorlevel 1 (
  "%BOTPY%" -m ensurepip --upgrade
  if errorlevel 1 goto PIP_FAILED
)
"%BOTPY%" -m pip --version
if errorlevel 1 goto PIP_FAILED
echo [3/3] Instaluje MetaTrader5, numpy, tzdata ...
"%BOTPY%" -m pip install --disable-pip-version-check MetaTrader5 numpy tzdata
if errorlevel 1 goto PACKAGES_FAILED
"%BOTPY%" -c "import sys,struct,MetaTrader5,numpy,zoneinfo; print('IMPORT_OK:',sys.version.split()[0],'arch:',struct.calcsize('P')*8)"
if errorlevel 1 goto PACKAGES_FAILED
echo.
echo [OK] MASTERQUO ma dzialajace .venv. Uruchom 02_SPRAWDZ_SRODOWISKO.bat
pause
exit /b 0
:CREATE_WITH
echo [1/3] Sprawdzam Python %~1 x64 (venv, ensurepip, launcher EXE) ...
py -%~1 -c "import sys,struct,venv,ensurepip,pathlib; p=pathlib.Path(sys.base_prefix)/'Lib'/'venv'/'scripts'/'nt'; sys.exit(0 if sys.platform=='win32' and struct.calcsize('P')==8 and (p/'venvlauncher.exe').is_file() and (p/'venvwlauncher.exe').is_file() else 1)" >nul 2>&1
if errorlevel 1 (
  echo [POMINIETO] Python %~1 niedostepny, uszkodzony lub bez venvlauncher.exe.
  exit /b 1
)
echo [OK] Python %~1 ma kompletne moduly venv.
py -%~1 -m venv --copies "%~dp0.venv"
if errorlevel 1 (
  echo [BLAD] Python %~1 nie utworzyl srodowiska .venv.
  call :ARCHIVE_OLD
  exit /b 1
)
if not exist "%BOTPY%" (
  call :ARCHIVE_OLD
  exit /b 1
)
"%BOTPY%" -c "import sys,struct;sys.exit(0 if sys.platform=='win32' and struct.calcsize('P')==8 else 1)" >nul 2>&1
if errorlevel 1 (
  call :ARCHIVE_OLD
  exit /b 1
)
exit /b 0
:ARCHIVE_OLD
if not exist ".venv\" exit /b 0
set "BACKUP=.venv_niekompletne_%RANDOM%_%RANDOM%"
if exist "%BACKUP%\" exit /b 1
ren ".venv" "%BACKUP%"
if errorlevel 1 (
  echo [BLAD] Nie mozna przeniesc .venv. Zamknij programy i zmien nazwe tego folderu recznie.
  exit /b 1
)
echo [OK] Zachowano poprzedni folder jako %BACKUP%
exit /b 0
:NO_PYTHON
echo [BLAD] Nie znaleziono launchera py.
echo Pobierz Python 3.13 x64 z https://www.python.org/downloads/windows/
echo Po instalacji w nowym CMD wykonaj: py -3.13 --version
pause
exit /b 1
:NO_HEALTHY_PYTHON
echo.
echo [BLAD] Brak kompletnego Pythona umozliwiajacego utworzenie .venv.
echo Python 3.14 na Twoim komputerze ma brakujace venvlauncher.exe i zepsuty pip.
echo.
echo ROZWIAZANIE:
echo 1. Zainstaluj pelny Python 3.13 64-bit z python.org (venv i pip).
echo 2. Zamknij to okno, otworz nowy CMD i sprawdz: py -3.13 --version
 echo 3. Uruchom ten instalator ponownie. Pythona 3.14 nie trzeba usuwac.
echo Opcjonalnie (tylko dla Python install manager): py install 3.13
pause
exit /b 1
:PIP_FAILED
echo [BLAD] Pip wewnatrz .venv nie dziala. Napraw bazowa instalacje Python 3.13.
echo Folder .venv jest izolowany; nastepne uruchomienie automatycznie odlozy niesprawna kopie.
pause
exit /b 1
:PACKAGES_FAILED
echo [BLAD] Instalacja bibliotek nie powiodla sie. Sprawdz Internet/proxy i wynik pip.
echo Nie uruchamiaj botow, zanim pojawi sie IMPORT_OK.
pause
exit /b 1
:STOP_ERROR
echo [BLAD] Nie udalo sie przygotowac folderu .venv. Sprawdz uprawnienia lub uruchom w C:\MasterQUO_FIXED.
pause
exit /b 1
