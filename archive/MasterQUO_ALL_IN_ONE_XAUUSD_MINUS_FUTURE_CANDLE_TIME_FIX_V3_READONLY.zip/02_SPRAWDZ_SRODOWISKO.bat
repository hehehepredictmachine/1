@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
set "BOTPY=%~dp0.venv\Scripts\python.exe"
if not exist "%BOTPY%" goto INSTALL_FIRST
"%BOTPY%" VERIFY_PACKAGE.py
if errorlevel 1 goto HASH_FAIL
"%BOTPY%" -c "import MetaTrader5,numpy,zoneinfo; print('DEPENDENCIES_OK')"
if errorlevel 1 goto INSTALL_FIRST
cd /d "%~dp001_PROGRAM_GLOWNY_10_ULEPSZEN"
"%BOTPY%" M00U_RUNTIME.py doctor
if errorlevel 1 goto DOCTOR_FAILED
echo [OK] Test lokalny zakonczony. Polaczenie z Twoim MT5 DEMO wymaga osobnej kontroli.
pause
exit /b 0
:INSTALL_FIRST
echo [BLAD] Uruchom najpierw 01_INSTALUJ_ZALEZNOSCI.bat.
pause
exit /b 1
:HASH_FAIL
echo [BLAD] Niezgodnosc manifestu pakietu. Nie uruchamiaj programu.
pause
exit /b 1
:DOCTOR_FAILED
echo [BLAD] Diagnostyka M00U zglosila problem. Sprawdz komunikaty.
pause
exit /b 1
