# MasterQUO — korekta FUTURE_CANDLE_AVAILABILITY

## Co bylo nie tak

Poprzedni adapter uznawal `open` kolejnej swiecy za `available_at` bez sprawdzenia, czy ten czas juz uplynal. Wystarczala jedna para, dla ktorej `next_open > now_utc`, aby cala petla raportowala `BLOCKED FUTURE_CANDLE_AVAILABILITY`.

## Co zostalo poprawione

- Eksportuje tylko swiece posiadajace **zaobserwowane otwarcie nastepnej swiecy niepozniejsze od `as_of`**.
- Pobiera bufor dodatkowych barow, aby odzyskac wymagana liczbe potwierdzonych swiec.
- Nie przesuwa ani nie zgaduje czasu brokera; nie zmienia zabepieczenia lookahead w RUN_UPGRADES_READONLY.py.
- Dodaje pola diagnostyczne dla kazdego interwalu: ostatnie otwarcie, liczbe pominietych niepotwierdzonych swiec, ostatni poprawny `available_at`.
- Jesli broker zwraca przyszly timestamp ticka, stan pozostaje `BLOCKED` z kodem `BROKER_TICK_AHEAD_OF_UTC`.
- Niezalezny `06_DIAGNOZA_CZASU_MT5.bat` wyswietla surowe timestampy; nie wykonuje transakcji.

## Instalacja

1. Zatrzymaj poprzednie trzy okna monitora i rozpakuj NOWY ZIP do pustego folderu (nie nakladaj na poprzedni).
2. Uruchom `01_INSTALUJ_ZALEZNOSCI.bat`, potem `02_SPRAWDZ_SRODOWISKO.bat`.
3. Zaloguj sie do MetaTrader 5 DEMO i otworz XAUUSD- w Market Watch.
4. Uruchom `06_DIAGNOZA_CZASU_MT5.bat` **raz**.
5. Uruchom `03_START_MONITORY_READONLY.bat`.

Jesli nadal wyskoczy kod dotyczacy czasu, podeslij wynik z `06_DIAGNOZA_CZASU_MT5.bat`, przede wszystkim `utc_now`, `tick_delta_seconds` i `future_open_count`. Uwaga: brak swiezych danych nie daje uprawnien do tradingu.

## Granice poprawek

Nie przetestowano bezposrednio na Twoim MT5 Windows. Brak auto-order. Status CANDIDATE / READONLY.
