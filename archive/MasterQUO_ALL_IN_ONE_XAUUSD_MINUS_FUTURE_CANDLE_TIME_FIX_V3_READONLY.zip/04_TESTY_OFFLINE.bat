@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
set "BOTPY=%~dp0.venv\Scripts\python.exe"
if not exist "%BOTPY%" goto INSTALL_FIRST
"%BOTPY%" VERIFY_PACKAGE.py
if errorlevel 1 goto FAILED
cd /d "%~dp001_PROGRAM_GLOWNY_10_ULEPSZEN"
"%BOTPY%" -m unittest M00U_TESTS -q
if errorlevel 1 goto FAILED
"%BOTPY%" -m unittest discover -s tests -p "TEST_*.py" -q
if errorlevel 1 goto FAILED
echo [OK] Glowny pakiet 10 ulepszen przeszedl testy offline.
pause
exit /b 0
:INSTALL_FIRST
echo [BLAD] Najpierw uruchom 01_INSTALUJ_ZALEZNOSCI.bat.
pause
exit /b 1
:FAILED
echo [BLAD] Weryfikacja lub testy zakonczyly sie niepowodzeniem.
pause
exit /b 1
