#!/usr/bin/env python3
"""Read-only verification: SHA-256 for every file in the package payload."""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'PACKAGE_MANIFEST_SHA256.json').read_text('utf-8'))
missing=[];bad=[]
for rel,expected in manifest['files'].items():
  f=root/rel
  if not f.is_file(): missing.append(rel);continue
  h=hashlib.sha256(f.read_bytes()).hexdigest()
  if h!=expected: bad.append(rel)
print('MASTERQUO PACKAGE CHECK:',len(manifest['files']),'file hashes; missing=',len(missing),'incorrect=',len(bad))
for name in missing[:20]:print('MISSING:',name)
for name in bad[:20]:print('CHANGED:',name)
sys.exit(1 if missing or bad else 0)
