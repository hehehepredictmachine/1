@echo off
setlocal
cd /d "%~dp001_PROGRAM_GLOWNY_10_ULEPSZEN"
"%~dp0.venv\Scripts\python.exe" M00U_RUNTIME.py run
if errorlevel 1 echo [MASTERQUO] Supervisor zakonczyl sie z bledem.
pause
