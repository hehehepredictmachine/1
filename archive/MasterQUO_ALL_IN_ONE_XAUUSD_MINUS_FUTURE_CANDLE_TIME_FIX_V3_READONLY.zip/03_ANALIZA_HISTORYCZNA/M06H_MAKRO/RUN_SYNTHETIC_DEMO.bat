@echo off
cd /d "%~dp0"
py -3 M06H_MAKE_SYNTHETIC_DEMO.py
py -3 M06H_RESEARCH_ENGINE.py --bars examples\DEMO_BARS_SYNTHETIC_M1.csv --events examples\DEMO_EVENTS_SYNTHETIC.json --config examples\DEMO_CONFIG_SYNTHETIC.json --m06-packet examples\DEMO_M06_TICKS_SIGNALS_SYNTHETIC.json --output-dir examples\DEMO_OUTPUT
pause
