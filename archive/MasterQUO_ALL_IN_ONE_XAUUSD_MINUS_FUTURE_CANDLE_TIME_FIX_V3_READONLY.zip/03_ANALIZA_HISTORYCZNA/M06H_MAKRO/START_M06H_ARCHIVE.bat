@echo off
cd /d "%~dp0"
if "%~1"=="" (
  echo Uzycie: START_M06H_ARCHIVE.bat "C:\pelna\sciezka\M04N_INTELLIGENCE.json"
  pause
  exit /b 2
)
py -3 M06H_ARCHIVE_M04N.py --input "%~1" --archive "runtime_m06h\M04N_HISTORY.jsonl"
pause
