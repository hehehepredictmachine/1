@echo off
cd /d "%~dp0"
py -3 M06R_HISTORICAL_REPLAY.py --bars-dir data_mt5_six_tf --symbol XAUUSD --mode AUTO --max-steps 2000 --output-dir results_m06r %*
if errorlevel 1 echo Sprawdz README i komplet CSV z terminala.
pause
