@echo off
cd /d "%~dp0"
py -3 M06R_MAKE_SYNTHETIC_DEMO.py --output-dir examples\SYNTHETIC_SIX_TF --bars 260
if errorlevel 1 goto :bad
py -3 M06R_HISTORICAL_REPLAY.py --bars-dir examples\SYNTHETIC_SIX_TF --min-closed 230 --max-steps 3 --output-dir examples\SYNTHETIC_RESULT
if errorlevel 1 goto :bad
echo DEMO SYNTHETIC, nie wynik XAUUSD.
pause
exit /b 0
:bad
echo Zatrzymano: blad.
pause
exit /b 1
