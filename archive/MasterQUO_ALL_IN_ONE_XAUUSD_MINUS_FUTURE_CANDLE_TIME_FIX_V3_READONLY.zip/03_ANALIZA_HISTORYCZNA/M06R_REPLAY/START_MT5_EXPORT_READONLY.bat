@echo off
cd /d "%~dp0"
py -3 M06R_EXPORT_MT5_ALL_TIMEFRAMES.py %*
if errorlevel 1 echo Blad eksportu; sprawdz MT5, symbole, date i dokumentacje.
pause
