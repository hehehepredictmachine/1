@echo off
cd /d "%~dp0"
py -3 -m unittest -q M06R_TESTS M06R_INTEGRITY_MACRO_TESTS M06H_TESTS M07_M03E_PROFILE_TESTS
if errorlevel 1 echo TEST FAILED
pause
