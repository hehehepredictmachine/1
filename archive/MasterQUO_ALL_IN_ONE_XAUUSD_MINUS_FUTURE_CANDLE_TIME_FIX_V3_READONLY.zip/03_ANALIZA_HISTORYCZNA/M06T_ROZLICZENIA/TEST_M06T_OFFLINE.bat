@echo off
cd /d "%~dp0"
py -3 -m unittest M06T_TESTS -v
pause
