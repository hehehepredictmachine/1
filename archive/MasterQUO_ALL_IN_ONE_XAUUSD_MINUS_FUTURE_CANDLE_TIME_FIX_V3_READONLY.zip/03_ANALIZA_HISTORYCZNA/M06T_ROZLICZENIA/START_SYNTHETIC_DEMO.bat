@echo off
cd /d "%~dp0"
py -3 M06T_MAKE_SYNTHETIC_DEMO.py
if errorlevel 1 pause & exit /b 1
py -3 M06T_ENGINE.py --signals examples\SYNTHETIC_ONLY\SIGNALS_SYNTHETIC.jsonl --ledger examples\SYNTHETIC_ONLY\STAGES_SYNTHETIC.jsonl --ticks examples\SYNTHETIC_ONLY\TICKS_SYNTHETIC.csv --protocol examples\SYNTHETIC_ONLY\PROTOCOL_SYNTHETIC.json --events examples\SYNTHETIC_ONLY\MACRO_SYNTHETIC.json --replay-report examples\SYNTHETIC_ONLY\M06R_REPORT_SYNTHETIC.json --out-dir examples\SYNTHETIC_ONLY\RESULTS
pause
