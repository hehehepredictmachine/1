@echo off
setlocal
cd /d "%~dp001_PROGRAM_GLOWNY_10_ULEPSZEN"
"%~dp0.venv\Scripts\python.exe" M00U10_VIEWER.py --file runtime/M00U10_MT5_REPORT.json
if errorlevel 1 echo [MASTERQUO] Viewer zakonczyl sie z bledem.
pause
