# MasterQUO — poprawka instalacji Python / pip (2026-10-08)

## Co wykryto

Starszy `01_INSTALUJ_ZALEZNOSCI.bat` wykonywal `py -3 -m pip install MetaTrader5 numpy tzdata`, a na komputerze uzytkownika globalny `pip` Pythona 3.14 nie importuje `pip._vendor.rich._emoji_codes`. Nie jest to blad strategii MasterQUO ani dowod na brak obslugi Pythona 3.14 przez MetaTrader5.

## Co zmieniono

- `01_INSTALUJ_ZALEZNOSCI.bat`: tworzy osobne `.venv` z wlasnym pip i instaluje zaleznosci tylko do niego. Nie uzywa globalnego `pip`.
- `02_SPRAWDZ_SRODOWISKO.bat`, `03_START_MONITORY_READONLY.bat`, `04_TESTY_OFFLINE.bat`, `05_STOP_M00U.bat`: wywoluja interpreter `.venv\Scripts\python.exe`.
- `03A_RUN_M00U.bat`, `03B_RUN_MT5_ADAPTER.bat`, `03C_RUN_VIEWER.bat`: oddzielne, jawne uruchamianie procesow przez ten sam interpreter.
- Zachowane: oryginalne 42 ZIP, kod silnikow, tryb READONLY, `enable_orders=false`.

## Instrukcja

1. Rozpakuj NOWY zbiorczy ZIP do pustego katalogu Windows. Nie nadpisuj dzialajacego katalogu z runtime.
2. Uruchom `01_INSTALUJ_ZALEZNOSCI.bat`. Musi byc dostep do Internetu i zainstalowany pelny Python x64 (polecenie `py`).
3. Uruchom `02_SPRAWDZ_SRODOWISKO.bat`.
4. Uruchom MetaTrader 5 DEMO, zaloguj konto; kliknij `03_START_MONITORY_READONLY.bat`.
5. Symbol instrumentu np. `XAUUSDm` zmien w `03B_RUN_MT5_ADAPTER.bat` i w configu M00U, jesli u brokera nie ma `XAUUSD`.

## Gdy nowy `.venv` nadal nie dziala

Zamknij procesy MasterQUO. Usun TYLKO katalog `.venv` w folderze nowo rozpakowanej paczki, po czym uruchom instalator ponownie. Jezeli `py -3 -m venv` w ogole nie dziala, w Windows wybierz Napraw (Repair) instalacji Python i zadbaj o pelna wersje z `venv`/`ensurepip`.

## Nie objete potwierdzeniem

Zmiany plikow `.bat` zostaly sprawdzone statycznie na Linux, a oryginalne testy Python — offline. Nie wykonano instalacji na komputerze uzytkownika ani polaczenia z terminalem MT5 Windows. Pakiet nadal `CANDIDATE / READONLY / NO ORDERS`.
