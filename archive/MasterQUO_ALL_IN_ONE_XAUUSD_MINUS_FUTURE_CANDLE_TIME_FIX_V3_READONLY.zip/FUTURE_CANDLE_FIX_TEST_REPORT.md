# Raport poprawki — FUTURE_CANDLE_AVAILABILITY

- Przyczyna: `closed_bars()` uzywal przyszlego otwarcia kolejnej swiecy jako potwierdzenia zamkniecia i `available_at`, co powodowalo odrzucenie wszystkich danych przez `RUN_UPGRADES_READONLY.py`.
- Zakres: poprawiono tylko adapter MT5, dodano 8 testow regresyjnych i osobna diagnostyke zegara.
- Zachowano `RUN_UPGRADES_READONLY.py` i wszystkie 42 historyczne archiwa bez zmian.
- Brak domyslnego przesuwania UTC oraz brak skladania zlecen.
- Testy: `python -m unittest discover -s tests -p 'TEST_*.py' -q` (94/94); `python -m unittest M00U_TESTS -q` (76/76), wykonane offline.
- Zauwazono poprzednio istniejace ostrzezenie ResourceWarning SQLite w testach M00U, bez niepowodzenia testow.
- Nie wykonano testu na Windows / rzeczywistym MT5 użytkownika, nie potwierdzono poprawnosci zegara terminala.
