@echo off
setlocal
cd /d "%~dp001_PROGRAM_GLOWNY_10_ULEPSZEN"
if not exist "%~dp0.venv\Scripts\python.exe" (
  echo [BLAD] Brak .venv. Uruchom instalator zaleznosci.
  pause
  exit /b 1
)
"%~dp0.venv\Scripts\python.exe" M00U_RUNTIME.py stop
if errorlevel 1 echo [OSTRZEZENIE] Supervisor nie potwierdzil zatrzymania.
echo Adapter MT5 oraz viewer zatrzymaj osobno Ctrl+C w ich oknach.
pause
