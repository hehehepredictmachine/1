**HOTFIX v1.0.3 — SYMBOL BROKERA:** Ustawiono `XAUUSD-` (z myslnikiem na koncu) w `M00U_CONFIG.json`, `03B_RUN_MT5_ADAPTER.bat` i komunikacie startowym. Tryb READONLY; wszystkie 42 archiwa oryginalne bez zmian. Wariant dla brokera uzywajacego symbolu `XAUUSD-`.

**HOTFIX v1.0.2 — NAPRAWA WinError 2 / venvlauncher.exe:** glowny instalator preferuje sprawnego Python 3.13 x64 i sprawdza pliki `venvlauncher.exe`/`venvwlauncher.exe`. Jesli masz tylko uszkodzonego Python 3.14, doinstaluj 3.13. Zobacz `NAPRAWA_BLEDU_VENVLAUNCHER_PYTHON_V2.md`.

**AKTUALIZACJA v1.0.1 — NAPRAWA PIP/PYTHON 3.14:** Glowny instalator i glowne BAT uruchomieniowe korzystaja teraz z odizolowanego `.venv`. Zobacz `NAPRAWA_PIP_PYTHON_3_14_PL.md`. Nie uruchamiaj starszych BAT z podkatalogow.

# MasterQUO — WSZYSTKO W JEDNEJ PACZCE

**Data zebrania:** 8 października 2026 r.  
**Status:** CANDIDATE / RESEARCH ONLY / READ-ONLY. **BRAK AUTOMATYCZNYCH ZLECEŃ.**

To wydanie gromadzi wszystkie **42 archiwa ZIP** przygotowane w toku prac nad MasterQUO, w tym wszystkie 10 przyrostowych ulepszeń, źródła M01–M16, inteligencję wskaźników M02I, kolektor danych o złocie i dolarze M04N (Fed, BLS, Forex Factory, Metals Mine), wieloetapowe integracje i narzędzia historyczne M06H/M06R/M06T. Cały kod źródłowy każdej edycji pozostaje w jej własnym archiwum, bez nadpisywania poprzednich wersji.

## Foldery

- `01_PROGRAM_GLOWNY_10_ULEPSZEN/` — rozpakowane NAJNOWSZE środowisko badawcze MasterQUO. Zawiera M00U Runtime, 9 kolejnych kalkulatorów (łącznie 10 ulepszeń) i `legacy_core/`, dołączony monitor i pliki BAT.
- `02_ZRODLA_NEWS_M04N/` — rozpakowany kolektor M04N v1.1.0 (Forex Factory, Metals Mine, Fed, BLS, opcjonalnie FRED/GDELT).
- `03_ANALIZA_HISTORYCZNA/M06H_MAKRO/` — historyczne badanie publikacji makro i archiwizacja aktualizacji.
- `03_ANALIZA_HISTORYCZNA/M06R_REPLAY/` — replay strategii świeca po świecy.
- `03_ANALIZA_HISTORYCZNA/M06T_ROZLICZENIA/` — obliczanie kosztów i OOS na rzeczywistych tickach (o ile dostarczono dane).
- `04_ARCHIWUM_WSZYSTKICH_42_WERSJI/` — wszystkie 42 NIEZMIENIONE archiwa wcześniejszych etapów, posortowane kategoriami. Dzięki temu żadne poprawki ani wcześniejsze warianty nie przepadają.
- `DOKUMENTACJA/` — lista archiwów, manifest kontrolny i uwagi o integracji.

## Najprostszy start — Windows 10/11 i MT5 DEMO

1. Rozpakuj cały zbiorczy ZIP do NOWEGO folderu, np. `C:\MasterQUO_ALL_IN_ONE`. Nie nakładaj go na wcześniejszą instalację.
2. Uruchom MetaTrader 5 i zaloguj się na rachunek **DEMO**. Terminal musi pozwalać na pobieranie świec, a nazwa złota musi pasować do brokera (np. XAUUSD lub XAUUSDm).
3. Kliknij `01_INSTALUJ_ZALEZNOSCI.bat` (Python/py musi być zainstalowany); skrypt tworzy lokalne `.venv` i instaluje `MetaTrader5 numpy tzdata` za pomoca jego izolowanego `pip`. Nie uzywa globalnego `pip`; potrzebuje internetu.
4. Kliknij `02_SPRAWDZ_SRODOWISKO.bat`.
5. Kliknij `03_START_MONITORY_READONLY.bat` — uruchomi trzy okna diagnostyczne dla M00U, adaptera MT5 i podglądu. Do uruchamiania recznego wybieraj pliki `03A_RUN_M00U.bat`, `03B_RUN_MT5_ADAPTER.bat`, `03C_RUN_VIEWER.bat` w katalogu glownym. Stare BAT z podfolderu korzystaja z globalnego Pythona i nie sa zalecane.
6. Kliknij `04_TESTY_OFFLINE.bat`, żeby sprawdzić bieżące moduły bez MT5; niezalezna kontrola plikow: `.venv\Scripts\python.exe VERIFY_PACKAGE.py`.
7. Aby sprawdzić historyczne zachowanie strategii, przejdź do `03_ANALIZA_HISTORYCZNA/M06R_REPLAY/README.md`, a potem `M06T_ROZLICZENIA/README.md`.

## Istotne ograniczenia (uczciwe)

- To **kompletna paczka wszystkich dotychczasowych wersji**, a nie jeden w pełni zweryfikowany bot LIVE. Główny program integruje 10 ulepszeń w środowisku BADAWCZYM; starsze integracje i M06H/M06R/M06T są zachowane jako odrębne narzędzia. Ich pełna zgodność na Twoim terminalu i z danymi historycznymi NIE została potwierdzona.
- Usługa Telegram jest domyślnie wyłączona; żadna część pakietu nie uzyskuje uprawnień do składania zleceń.
- Odczyty dla 6 TF XAUUSD wymagają świec terminala MT5; DXY H1 jest opcjonalne, z poprawną nazwą symbolu brokera.
- Konto „Zero” nadal może mieć prowizję, zmienny spread, poślizg i swap. Nigdy nie traktuj zerowego spreadu jako pewnika.
- Wyniki syntetycznych testów nie wykazują zyskowności. Ocena skuteczności wymaga OOS, ticków Bid/Ask, rzeczywistych opłat i forward DEMO.
- Program nie może obiecać kompletnego zbioru informacji z całego świata; brak albo opóźnienie źródeł makro musi pozostać jawne.
- W `04_ARCHIWUM_WSZYSTKICH_42_WERSJI` są *alternatywne, historyczne edycje* — NIE należy uruchamiać wszystkich naraz. Do pierwszego uruchomienia użyj tylko `01_PROGRAM_GLOWNY_10_ULEPSZEN/`.

## Łańcuch wersji

`M01 (feed) → M02/M02I/M03 (reżim/indykatory/struktura) → M07/M03E (profile) → M10A (fazy) → M14 (decyzje) → M15 (monitor/Telegram)`; równolegle `M04N/M04/M11 (kalendarz/ryzyko)` i `M06H/M06R/M06T (badania)`. `M00U` nadzoruje kilka procesów, a dziewięć ostatnich ulepszeń to dodatkowe kalkulatory diagnostyczne.

W tym wydaniu **nie deklarujemy** ukończonej certyfikacji kompletnego schematu wszystkich węzłów ani automatycznej synchronizacji wszystkich historycznych modułów na poziomie produkcyjnym.

## Poprawka 08.10.2026 — FUTURE_CANDLE_AVAILABILITY

Wersja zawiera naprawiony adapter potwierdzania zamknietych swiec oraz osobna diagnostyke czasu MT5.
Po uruchomieniu terminala DEMO kliknij `06_DIAGNOZA_CZASU_MT5.bat`, a nastepnie `03_START_MONITORY_READONLY.bat`.
Wiecej informacji: `NAPRAWA_FUTURE_CANDLE_AVAILABILITY_PL.md`. Jesli tick brokera wyprzedza UTC, program dalej bezpiecznie blokuje analize i wypisuje `BROKER_TICK_AHEAD_OF_UTC`.
