# MasterQUO — Python 3.14, venvlauncher.exe: poprawka V2

## Odczyt błędu użytkownika

Komputer ma lokalnego Pythona `pythoncore-3.14-64`. Polecenie `py -3 -m venv` próbuje skopiować:

- `Lib\venv\scripts\nt\venvlauncher.exe`
- `Lib\venv\scripts\nt\venvwlauncher.exe`

Kończy się błędem `WinError 2` (brak pliku), zatem nowa `.venv` nie powstaje. Poprzedni zrzut wykazał też brak składnika globalnego pip. Nie jest to problem MT5. Samo ponowne uruchomienie starego instalatora go nie naprawi.

## Zalecana naprawa

1. Doinstaluj pełną, stabilną wersję **Python 3.13 x64** z `https://www.python.org/downloads/windows/`. Nie usuwaj dotychczasowego 3.14. Jeśli korzystasz z Python install manager, można użyć `py install 3.13`, jeśli jest dostępne.
2. Otwórz NOWE CMD i sprawdź `py -3.13 --version` i `py -3.13 -c "import venv,ensurepip; print('PYTHON_OK')"`.
3. Rozpakuj tę nową paczkę do pustego folderu (np. `C:\MasterQUO_V2`).
4. Uruchom **tylko główny** `01_INSTALUJ_ZALEZNOSCI.bat`. Instalator wykrywa Python 3.13 / 3.12 / sprawny 3.14, sprawdza pliki venvlauncher.exe i venvwlauncher.exe, zakłada `.venv`, instaluje `MetaTrader5 numpy tzdata` i wymaga napisu `IMPORT_OK`.
5. Następnie `02_SPRAWDZ_SRODOWISKO.bat`, a po zalogowaniu na MT5 DEMO `03_START_MONITORY_READONLY.bat`.

Jeżeli wcześniejszy, niedokończony folder `.venv` już istnieje, nowy instalator zachowa go pod inną nazwą i utworzy nowy. Niczego nie usuwa z systemowego Pythona. Nie używaj starych BAT z podkatalogów.

## Co zostało faktycznie zmienione

- Główny instalator BAT: świadomy wybór wersji Pythona (priorytet 3.13) i diagnostyka brakujących launcherów.
- Dodano ten plik z rozwiązaniem błędu i instrukcją Windows.
- Zaktualizowano manifest SHA-256.
- Wszystkie 42 archiwa oryginalnego projektu oraz niezmodyfikowany kod strategii zachowano bajtowo.

## Ograniczenia

Brak wykonywania plików `.bat` w środowisku Windows w ramach tego audytu. Testy i CRC archiwów oraz regresja Pythona są sprawdzane offline na Linux. Cały projekt wciąż `CANDIDATE / READONLY / NO ORDERS`. Nowy instalator nie naprawia automatycznie uszkodzonej instalacji Pythona; wybiera już sprawną.
