@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
if not exist "%~dp0.venv\Scripts\python.exe" (echo [BLAD] Najpierw 01_INSTALUJ_ZALEZNOSCI.bat & pause & exit /b 1)
"%~dp0.venv\Scripts\python.exe" "01_PROGRAM_GLOWNY_10_ULEPSZEN\M00U10_MT5_READONLY_ADAPTER.py" --symbol XAUUSD- --diagnose-clock
echo.
echo [INFO] Porownaj tick_delta_seconds i future_open_count. Nie zmieniaj samodzielnie godzin swiec.
pause
