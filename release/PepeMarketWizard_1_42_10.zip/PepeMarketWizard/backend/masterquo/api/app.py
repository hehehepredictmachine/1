"""HTTP + WebSocket API (contract /api/v1, version in version.API_CONTRACT_VERSION).

The built web monitor (frontend/dist) is served from the same origin. No CORS is enabled.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import sys
import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Body, FastAPI, HTTPException, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response
from pydantic import BaseModel, Field
from starlette.middleware.base import BaseHTTPMiddleware

from .. import desktop, paths, presets, stats, sysres
from ..execution.modes import ModeError
from ..media.gifinfo import gif_info
from ..timeutil import TIMEFRAMES, iso, utcnow
from ..version import API_CONTRACT_VERSION, APP_NAME, APP_VERSION
from .security import SESSION_COOKIE, LocalSecurity

log = logging.getLogger("masterquo.api")


class AssetConfirmReq(BaseModel):
    asset: str
    broker_symbol: str


class AssetActiveReq(BaseModel):
    asset: str


class DesktopPrefsReq(BaseModel):
    close_action: str
    autostart: bool = False
    start_minimized: bool = False


class ModeReq(BaseModel):
    mode: str
    confirm: str = ""


class PrimaryPathReq(BaseModel):
    instrument: str
    path: str


class MarketZonesReq(BaseModel):
    instrument: str = Field(max_length=16)
    timeframes: list[str] | None = Field(default=None, max_length=4)


class MarketZonesLiveReq(MarketZonesReq):
    enabled: bool


class TrainJobReq(BaseModel):
    kind: str = Field(max_length=16)
    instrument: str = Field(max_length=16)
    params: dict = Field(default_factory=dict)


class TrainVersionReq(BaseModel):
    instrument: str = Field(max_length=16)
    model_key: str = Field(max_length=64)
    version: str | None = Field(default=None, max_length=64)


class OnReq(BaseModel):
    on: bool
    reason: str = "user"


class ExecReq(BaseModel):
    decision_id: str


class CloseReq(BaseModel):
    scope: str = "BOT"
    ticket: int | None = None
    confirm: str


SYMBOL_RX = r"^[A-Za-z0-9._#&$!+\-]{1,40}$"


class AskReq(BaseModel):
    question: str = Field(min_length=2, max_length=2000)


class KeyReq(BaseModel):
    api_key: str = Field(min_length=10, max_length=300)


class SecretReq(BaseModel):
    name: str
    value: str | None = None


class MLModeReq(BaseModel):
    mode: str = Field(pattern="^(OFF|SHADOW|ASSIST)$")


class MLTrainReq(BaseModel):
    include_approx: bool | None = None          # per job only (training installer); config ml.use_backfill_approx stays untouched


class MLBackfillReq(BaseModel):
    days: int = Field(30, ge=5, le=180)


class MLFlagReq(BaseModel):
    on: bool


class StrategyModeReq(BaseModel):
    strategy_mode: str = Field(pattern="^(AUTO|MANUAL)$")
    manual_strategy_id: str | None = Field(default=None, max_length=4)


class TelegramTemplateReq(BaseModel):
    template: str | None = Field(default=None, max_length=1500)


class PresetReq(BaseModel):
    name: str = Field(min_length=1, max_length=40)


class StrategyToggleReq(BaseModel):
    strategy_id: str = Field(pattern="^S[0-9]{2}$")          # checked against the registry in the endpoint (S11, S12 included)
    scan: bool | None = None
    trade: bool | None = None


class ProfileReq(BaseModel):
    profile: str = Field(pattern="^(ACTIVE|ORIGINAL)$")


MEDIA_SLOTS = {"background": ("background-matrix.gif", "background-matrix-static.webp"), "frog": ("frog-dance.gif", "frog-dance-static.png")}
MAX_GIF_BYTES = 15 * 1024 * 1024


class SetupViewReq(BaseModel):
    mode: str = Field(pattern="^(AUTO|SELECTED|ALL)$")
    strategy_id: str | None = Field(default=None, max_length=4)
    focus_setup_id: str | None = Field(default=None, max_length=120)


class LeverageReq(BaseModel):
    mode: str = Field(pattern="^(AUTO|MANUAL)$")
    limit: int | None = Field(default=None, ge=1, le=1000)


class MemoryReq(BaseModel):
    status: str


def create_app(rt, port: int) -> FastAPI:
    sec = LocalSecurity(port)
    rt.security = sec

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        rt.attach_loop(asyncio.get_running_loop())
        yield

    app = FastAPI(title=APP_NAME, version=APP_VERSION, docs_url=None, redoc_url=None, openapi_url=None, lifespan=lifespan)

    class Guard(BaseHTTPMiddleware):
        async def dispatch(self, request: Request, call_next):
            if not sec.host_ok(request.headers.get("host")):
                return JSONResponse({"error": "HOST_NOT_ALLOWED"}, status_code=421)
            path = request.url.path
            if request.method not in ("GET", "HEAD", "OPTIONS"):
                if path == "/api/v1/admin/shutdown" and request.headers.get("x-mq-shutdown") == sec.shutdown_token:
                    return await call_next(request)
                if not sec.origin_ok(request.headers.get("origin")):
                    return JSONResponse({"error": "ORIGIN_NOT_ALLOWED"}, status_code=403)
                if not sec.csrf_ok(request.cookies.get(SESSION_COOKIE), request.headers.get("x-mq-csrf")):
                    return JSONResponse({"error": "CSRF_OR_SESSION_INVALID"}, status_code=403)
            elif path.startswith("/api/v1/") and path not in ("/api/v1/health",) and not sec.csrf_for(request.cookies.get(SESSION_COOKIE)):
                return JSONResponse({"error": "SESSION_REQUIRED_OPEN_MONITOR_PAGE"}, status_code=401)
            resp: Response = await call_next(request)
            resp.headers["X-Content-Type-Options"] = "nosniff"
            resp.headers["Referrer-Policy"] = "no-referrer"
            resp.headers["X-Frame-Options"] = "DENY"
            resp.headers["Cache-Control"] = "no-store" if path.startswith("/api/") else resp.headers.get("Cache-Control", "no-cache")
            return resp

    app.add_middleware(Guard)

    # ------------------------------------------------------------ page + session
    def _index() -> Response:
        idx = paths.FRONTEND_DIST / "index.html"
        if not idx.exists():
            resp: Response = HTMLResponse("<h1>MasterQUO AI</h1><p>Brak zbudowanego frontendu (frontend/dist). "
                                          "Paczka zawiera gotowy build – sprawdź, czy rozpakowano cały ZIP.</p>", status_code=503)
        else:
            resp = FileResponse(idx, headers={"Cache-Control": "no-cache"})
        sid, _ = sec.new_session()
        resp.set_cookie(SESSION_COOKIE, sid, httponly=True, samesite="strict", secure=False, path="/")
        resp.headers["Content-Security-Policy"] = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
                                                   "img-src 'self' data: blob:; connect-src 'self' ws://127.0.0.1:%d ws://localhost:%d; "
                                                   "frame-ancestors 'none'; base-uri 'none'" % (port, port))
        return resp

    @app.get("/")
    def index():
        return _index()

    @app.get("/assets/{name:path}")
    def assets(name: str):
        base = (paths.FRONTEND_DIST / "assets").resolve()
        f = (base / name).resolve()
        if base not in f.parents or not f.is_file():
            raise HTTPException(404)
        return FileResponse(f, headers={"Cache-Control": "public, max-age=31536000, immutable"})

    @app.get("/static/{name:path}")
    def static(name: str):
        base = paths.FRONTEND_DIST.resolve()
        f = (base / name).resolve()
        if base not in f.parents or not f.is_file() or f.suffix not in (".png", ".webp", ".svg", ".ico", ".jpg", ".gif"):
            raise HTTPException(404)
        return FileResponse(f)

    @app.get("/api/v1/health")
    def health():
        return {"ok": True, "app": APP_NAME, "version": APP_VERSION, "contract": API_CONTRACT_VERSION, "boot_id": rt.bus.boot_id,
                "synthetic": rt.demo, "mt5_state": rt.bridge.state, "time": iso(utcnow()),
                "start_failures": [f["part"] for f in getattr(rt, "start_failures", [])]}

    @app.get("/api/v1/session")
    def session(request: Request):
        sid = request.cookies.get(SESSION_COOKIE)
        return {"csrf": sec.csrf_for(sid), "contract": API_CONTRACT_VERSION, "boot_id": rt.bus.boot_id, "port": port}

    # ------------------------------------------------------------ state
    def full_state() -> dict:
        b = rt.bridge
        cfg = rt.cfg.get()
        acct = b.account_status()
        mode = rt.modes.status()
        return {"contract": API_CONTRACT_VERSION, "app_version": APP_VERSION, "seq": rt.bus.seq, "boot_id": rt.bus.boot_id,
                "synthetic": rt.demo or b.synthetic, "server_time": iso(utcnow()),
                "connection": b.connection_status(), "account": acct, "symbol": b.symbol_status_dict(), "quote": b.quote_status(),
                "tf_meta": b.tf_meta(), "analysis": rt.engine.analysis_summary(), "decision": rt.engine.current_decision(),
                "prefs": {**rt.prefs.all(), "exposure": rt.prefs.exposure_limit()},
                "engine": {"last_error": rt.engine.last_error, "cycle_ms": rt.engine.cycle_ms, "full_cycles": rt.engine.full_count},
                "agent": rt.agent.status(), "agent_last": rt.agent.public_result(rt.agent.last_result), "mode": mode,
                "risk_config": cfg.risk.model_dump(), "costs_config": cfg.costs.model_dump(), "strategy_config": cfg.strategy.model_dump(),
                "news": rt.news.summary(), "positions": {"positions": b.positions, "orders": b.orders},
                "managed": rt.db.query("SELECT * FROM managed_positions WHERE state='OPEN'"),
                "attempts": rt.gateway.recent_attempts(15), "paper": rt.paper.account() if mode["mode"] == "PAPER" else None,
                "logs": logs_list(60), "pc_clock": rt.pcclock.snapshot(), "manager": {"reconciled_epoch": rt.manager.reconciled_epoch,
                                                                                     "last_error": rt.manager.last_error},
                "first_run_completed": cfg.first_run_completed,
                "auto": rt.engine.active.status(compact=True), "active_config": cfg.active.model_dump(mode="json"),
                "ml": rt.ml.status(compact=True), "markets": rt.scanner.summary(),
                "bot_signals": {**rt.signals.status(), **rt.signals.list(limit=40)},
                "assets": rt.assets.state(), "lab": rt.lab.summary(cfg.assets.active),
                "lab_neural": _nss_compact(cfg.assets.active)}

    def logs_list(limit: int) -> list[dict]:
        return rt.db.query("SELECT id, ts, level, category, code, message FROM app_events ORDER BY id DESC LIMIT ?", (limit,))

    @app.get("/api/v1/state")
    def state():
        return full_state()

    @app.get("/api/v1/candles")
    def candles(tf: str = Query(...)):
        if tf not in TIMEFRAMES:
            raise HTTPException(400, "INVALID_TIMEFRAME")
        return rt.engine.chart(tf)

    @app.get("/api/v1/volatility")
    def volatility():
        return rt.engine.volatility()

    # ------------------------------------------------------------ 1.10: walls for strategies, IV import, structure (S/R, range, patterns)
    @app.get("/api/v1/timeframes")
    def timeframes():
        """TF registry (role per TF) + which TFs each strategy needs - the chart pages are built from this, never from a
        hard-coded list. Data status per TF from the engine's data-quality gate."""
        from ..strategies import registry as _reg
        from ..timeutil import TF_REGISTRY
        dq = (rt.engine.dq or {}).get("timeframes") or {}
        strat = {d["strategy_id"]: {"setup_tfs": d["setup_tfs"], "required_tfs": d["required_tfs"], "context_tf": d["context_tf"], "name": d["name"]}
                 for d in _reg.describe()}
        return {"timeframes": [{"tf": tf, "seconds": v["seconds"], "role": v["role"], "core": v["core"],
                                "data": (dq.get(tf) or {}).get("status"), "closed_bars": (dq.get(tf) or {}).get("closed_bars"),
                                "required": (dq.get(tf) or {}).get("required"), "used_by": sorted(sid for sid, x in strat.items()
                                                                                                     if tf in x["setup_tfs"] or tf in x["required_tfs"] or tf == x["context_tf"])}
                               for tf, v in TF_REGISTRY.items()], "strategies": strat}

    @app.get("/api/v1/forecast")
    def forecast_get():
        """SHADOW candle analytics + price forecasts 5/15/30 + Double Retest v2 research state. Never an order permission."""
        return {**rt.forecast.public(), "registry": rt.forecast.registry(), "training": rt.forecast.training_status(),
                "config": rt.cfg.get().forecast.model_dump(), "shadow_summary": rt.forecast.shadow_summary()}

    # ------------------------------------------------------------ 1.13 analytics + pattern library (observational)
    # ------------------------------------------------------------ 1.14 lab (XAUUSD / BTC)
    def _nss_compact(asset: str) -> dict | None:
        snap = (rt.nss.last or {}) if getattr(rt, "nss", None) is not None and rt.nss.inst == asset else {}
        return {k: snap.get(k) for k in ("inference_id", "seq", "asset", "setup_id", "side", "technical_status", "mode", "model_hash", "computed_at",
                                         "expires_at")} if snap else None

    def _asset(asset: str | None) -> str:
        a = asset or rt.cfg.get().assets.active
        if a not in ("XAUUSD", "BTC"):
            raise HTTPException(403, f"ASSET_NOT_ALLOWED:{a}")
        return a

    @app.get("/api/v1/lab")
    def lab_state(asset: str | None = None):
        return rt.lab.public(_asset(asset))

    @app.get("/api/v1/lab/traceability")
    def lab_trace():
        from ..lab import traceability
        return {"rows": traceability.ROWS, "summary": traceability.summary()}

    @app.get("/api/v1/lab/memory")
    def lab_memory(tf: str = Query(...), t: str = Query(...)):
        from ..lab.sessions import memory_sequence
        if tf not in TIMEFRAMES:
            raise HTTPException(400, "INVALID_TIMEFRAME")
        by = {x: [b for b in rt.bridge.bars(x, 500, include_forming=False) if b.get("open_utc")] for x in ("M1", "M5", "M15", "M30", "H1", "H4", "D1")}
        return {"asset": rt.cfg.get().assets.active, **memory_sequence(by, tf, t)}

    @app.post("/api/v1/lab/train")
    def lab_train(body: dict = Body(default={})):
        from ..lab.protocol import default_protocol, FAMILIES, EXPERIMENTS
        a = _asset(body.get("asset"))
        if body.get("task_id") == "SCALP_SETUP_MARKET_V1":           # PMW-UPD-04 NSS: same jobs view, own child process, activate=none
            return _nss_job(["train", "--asset", a, "--activate", "none"])
        if a != rt.cfg.get().assets.active:
            raise HTTPException(409, "TRAIN_ONLY_ACTIVE_ASSET")
        sym = rt.assets.check_asset(a, "TRAINING")
        if rt.bridge.state != "CONNECTED":
            raise HTTPException(409, "MT5_NOT_CONNECTED")
        fams = [f for f in (body.get("families") or FAMILIES) if f in FAMILIES]
        exps = [e for e in (body.get("experiments") if body.get("experiments") is not None else EXPERIMENTS) if e in EXPERIMENTS]
        bars = [b for b in rt.bridge.symbol_bars(sym, "M5", int(min(max(body.get("bars") or 20000, 2000), 100000))) if b.get("closed") and b.get("open_utc")]
        prot = default_protocol(a, families=fams, experiments=exps, min_events=int(body.get("min_events") or 600))
        meta = rt.bridge.symbol_meta(sym) or {}
        src = "SYNTHETIC" if (rt.demo or rt.bridge.synthetic or rt.cfg.get().synthetic_demo) else "MT5"
        return rt.lab.trainer.start(a, bars, point=float(meta.get("point") or 0.01), data_source=src,
                                    instrument_id=rt.assets.instrument(a)["instrument_id"], protocol=prot,
                                    artifact_family=body.get("artifact_family") if (body.get("artifact_family") in fams or body.get("artifact_family") == "ALL") else "auto")

    @app.get("/api/v1/lab/jobs")
    def lab_jobs():
        return {"jobs": rt.lab.trainer.public()}

    @app.post("/api/v1/lab/jobs/{jid}/cancel")
    def lab_cancel(jid: str):
        return rt.lab.trainer.cancel(jid)

    # ------------------------------------------------------------ PMW-UPD-02: IQ Gold Gann / IQ Star Lines / PAL02M / SAR
    @app.get("/api/v1/indicator-context")
    def indicator_context_status():
        from ..extind import trainer as ict
        inst = rt.cfg.get().assets.active
        reg_p = ict.root(inst) / "registry.json"
        reg = json.loads(reg_p.read_text(encoding="utf-8")) if reg_p.exists() else {"active": None, "runs": {}}
        runs = {k: v for k, v in sorted(reg.get("runs", {}).items())[-10:]}
        return {"instrument": inst, "sources": rt.extind.status(inst), "sar": {"profile": "MQ_SAR_WILDER_PROFILE_V1", "live_params": {"step": 0.02, "max": 0.2},
                "implementation_status": "VERIFIED_REFERENCE_TESTS", "weights_training": "NOT_APPLICABLE", "calibration": "GRID_ON_TRAIN_FOLD (indicator-context calibrate-sar)",
                "mt5_parity": "MT5_PARITY_NOT_RUN"}, "model": {"active": reg.get("active"), "runs": runs,
                "task_id": "SCALP_TP1_FIRST_WITHIN_FROZEN_POLICY_V1", "schema": "SCALP_INDICATOR_CONTEXT_V1"}}

    @app.get("/api/v1/indicator-context/chart")
    def indicator_context_chart(tf: str = Query("M5")):
        from ..scalp.indicators import SAR_PROFILE, sar_points
        from ..timeutil import utcnow as _now
        b = [x for x in rt.bridge.bars(tf, 600, include_forming=False) if x.get("open_utc")]
        sar = None
        if len(b) >= 2:
            pts = sar_points([x["h"] for x in b], [x["l"] for x in b], 0.02, 0.2)
            sar = {"profile": SAR_PROFILE, "params": {"step": 0.02, "max": 0.2},
                   "points": [{"t": b[i]["open_utc"], "sar": p["sar"], "trend": p["trend"], "flip": p["flip"]} for i, p in enumerate(pts) if p]}
        inst = rt.cfg.get().assets.active
        lv = []
        for a, short in (("IQ_GOLD_GANN", "IQ Gann"), ("IQ_STAR_LINES", "IQ Star")):
            snap = rt.extind.as_of(a, inst, _now())
            for x in (snap or {}).get("levels") or []:
                if x.get("kind") == "LEVEL" and x.get("price") is not None:
                    lv.append({"price": x["price"], "title": f"{short}: {x.get('role')}", "adapter": a, "snapshot_id": snap["snapshot_id"],
                               "known_at": snap["available_at"]})
        return {"tf": tf, "instrument": inst, "sar": sar, "ext_levels": lv}

    @app.get("/api/v1/indicator-context/inventory")
    def indicator_context_inventory(adapter: str = Query(...)):
        if adapter not in ("IQ_GOLD_GANN", "IQ_STAR_LINES", "PAL02M"):
            raise HTTPException(400, "UNKNOWN_ADAPTER")
        from ..extind import mapping as emp
        return {"adapter": adapter, "heartbeat": rt.extind.heartbeat.get(adapter), "mapping": emp.mapping(adapter), "manifest": emp.manifest(adapter)}

    @app.put("/api/v1/indicator-context/mapping")
    def indicator_context_mapping(body: dict):
        from ..extind import mapping as emp
        a = body.get("adapter")
        if a not in ("IQ_GOLD_GANN", "IQ_STAR_LINES"):
            raise HTTPException(400, "MAPPING_ONLY_FOR_IDENTIFIED_IQ")
        try:
            return emp.save_mapping(a, body)
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc

    @app.post("/api/v1/indicator-context/train")
    def indicator_context_train(body: dict):
        """Separate process (never in the bot); POST returns at once, the result is in the registry/report."""
        import subprocess
        inst = body.get("asset") or rt.cfg.get().assets.active
        if inst not in ("XAUUSD", "BTC"):
            raise HTTPException(400, "UNKNOWN_INSTRUMENT")
        from ..training import core as tc
        log = open(tc.training_dir() / "indicator_context_train.log", "a", encoding="utf-8")
        kw = {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)} if os.name == "nt" else {"start_new_session": True}
        cmd = [sys.executable, "-m", "masterquo", "indicator-context", "train", "--asset", inst]
        if body.get("commission") is not None:
            cmd += ["--commission", str(float(body["commission"]))]
        subprocess.Popen(cmd, cwd=str(paths.ROOT_DIR / "backend"), stdout=log, stderr=subprocess.STDOUT, **kw)
        return {"started": True, "instrument": inst}

    @app.post("/api/v1/indicator-context/activate")
    def indicator_context_activate(body: dict):
        from ..extind import trainer as ict
        try:
            return {"ok": True, "active": ict.activate(body.get("asset") or rt.cfg.get().assets.active, str(body.get("run_id")), str(body.get("variant")))}
        except (ValueError, OSError, KeyError) as exc:
            return {"ok": False, "reason": str(exc)}

    @app.post("/api/v1/indicator-context/rollback")
    def indicator_context_rollback(body: dict):
        from ..extind import trainer as ict
        try:
            return {"ok": True, "active": ict.rollback(body.get("asset") or rt.cfg.get().assets.active)}
        except (ValueError, OSError) as exc:
            return {"ok": False, "reason": str(exc)}

    @app.get("/api/v1/lab/models")
    def lab_models(asset: str | None = None):
        a = _asset(asset)
        return {"asset": a, "models": rt.lab.trainer.models(a)}

    @app.get("/api/v1/lab/studies/{jid}")
    def lab_study(jid: str):
        if not _re.fullmatch(r"LJOB-[0-9TZ]+-[0-9a-f]{4}", jid):
            raise HTTPException(400, "INVALID_JOB_ID")
        f = rt.lab.trainer.root / "studies" / f"{jid}.json"
        if not f.exists():
            raise HTTPException(404, "NO_STUDY")
        return json.loads(f.read_text(encoding="utf-8"))

    @app.get("/api/v1/lab/trials")
    def lab_trials(asset: str | None = None):
        a = _asset(asset)
        return {"asset": a, "trials": rt.db.query("SELECT trial_id, created_at, horizon, model_family, protocol_id, data_hash, status, metrics, note "
                                                  "FROM lab_trials WHERE asset=? ORDER BY created_at DESC LIMIT 200", (a,)),
                "holdout_access": rt.db.query("SELECT * FROM lab_holdout_access WHERE asset=? ORDER BY at DESC LIMIT 50", (a,))}

    @app.post("/api/v1/lab/zones")
    def lab_zone_add(body: dict = Body(...)):
        a = body.get("asset") or rt.cfg.get().assets.active
        rt.assets.check_asset(a, "ZONES")
        try:
            return rt.lab.zones.add_manual(a, str(body["tf"]), str(body["kind"]), float(body["top"]), float(body["bottom"]), str(body["origin_time"]))
        except (KeyError, ValueError) as exc:
            raise HTTPException(400, f"INVALID_ZONE: {exc}") from exc

    @app.patch("/api/v1/lab/zones/{zone_id}")
    def lab_zone_patch(zone_id: str, body: dict = Body(...)):
        try:
            return rt.lab.zones.patch(zone_id, int(body["expected_revision"]), top=body.get("top"), bottom=body.get("bottom"), state=body.get("state"),
                                      blacklist=body.get("blacklist"), reason=str(body.get("reason") or ""))
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc

    @app.delete("/api/v1/lab/zones/{zone_id}")
    def lab_zone_delete(zone_id: str, expected_revision: int):
        try:
            return rt.lab.zones.delete(zone_id, expected_revision)
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc

    @app.get("/api/v1/lab/zones/diagnostics")
    def lab_zone_diag(asset: str | None = None):
        a = asset or rt.cfg.get().assets.active
        return rt.lab.zones.diagnostics(a)

    @app.get("/api/v1/lab/zones")
    def lab_zones(asset: str | None = None):
        a = _asset(asset)
        return {"asset": a, "zones": rt.lab.zones.list_asof(a)[-100:], "events": rt.lab.zones.events[-10:], "snapshot": rt.lab.zones.snapshot_status.get(a)}

    @app.get("/api/v1/lab/repaint")
    def lab_repaint():
        return {"report": rt.lab.repaint.report(),
                "recent": rt.db.query("SELECT asset, module, tf, bar_open, observed_at, change FROM lab_repaint ORDER BY id DESC LIMIT 50")}

    @app.post("/api/v1/lab/tradepad")
    def lab_tradepad(body: dict = Body(...)):
        from ..lab.edge import trade_pad_plan
        a = rt.cfg.get().assets.active
        sym = rt.assets.check_asset(a, "TRADEPAD")
        meta = rt.bridge.symbol_meta(sym)
        if not meta:
            raise HTTPException(409, "NO_SYMBOL_METADATA")
        meta = {**meta, **{k: (rt.bridge.symbol_info or {}).get(k) for k in ("volume_min", "volume_step")}}
        try:
            plan = trade_pad_plan(side=str(body.get("side")), entry=float(body["entry"]), sl=float(body["sl"]), tp=float(body["tp"]),
                                  lots=float(body.get("lots") or 0.01), meta=meta, quote=rt.bridge.quote_status(),
                                  commission_per_lot_side=float(rt.cfg.get().scalp.commission_per_lot_side or 0))
        except (KeyError, ValueError) as exc:
            raise HTTPException(400, f"INVALID_PLAN: {exc}") from exc
        return {"asset": a, "broker_symbol": sym, **plan}

    @app.post("/api/v1/lab/tradepad/execute")
    def lab_tradepad_execute(body: dict = Body(default={})):
        """Compatibility adapter: explicit routing to the Manual Pad gates (intent required)."""
        iid = body.get("intent_id")
        if not iid:
            raise HTTPException(400, "INTENT_REQUIRED: POST /api/v1/manual/plan → /api/v1/manual/intents → /execute")
        return manual_execute(str(iid), {"action_revision": body.get("action_revision", 1)})

    # ------------------------------------------------------------ PMW-UPD-07 R12 Manual Trade Pad (explicit user actions only)
    @app.post("/api/v1/manual/plan")
    def manual_plan(body: dict = Body(...)):
        from ..execution.manual import PlanError
        try:
            return rt.manual.plan(body)
        except PlanError as exc:
            raise HTTPException(400, str(exc)) from exc

    @app.post("/api/v1/manual/intents")
    def manual_intent(body: dict = Body(...)):
        from ..execution.manual import PlanError
        try:
            return rt.manual.create_intent(str(body.get("plan_id")))
        except PlanError as exc:
            raise HTTPException(409, str(exc)) from exc

    @app.get("/api/v1/manual/intents")
    def manual_intents():
        return {"items": rt.manual.intents(30)}

    @app.get("/api/v1/manual/intents/{iid}")
    def manual_intent_get(iid: str):
        r = rt.manual.intent(iid)
        if not r:
            raise HTTPException(404, "INTENT_NOT_FOUND")
        return r

    @app.post("/api/v1/manual/intents/{iid}/execute")
    def manual_execute(iid: str, body: dict = Body(default={})):
        from ..execution.manual import PlanError
        try:
            return rt.manual.execute(iid, int(body.get("action_revision") or 1))
        except PlanError as exc:
            raise HTTPException(409, str(exc)) from exc

    @app.post("/api/v1/manual/intents/{iid}/manage")
    def manual_manage(iid: str, body: dict = Body(...)):
        from ..execution.manual import PlanError
        try:
            return rt.manual.manage(iid, str(body.get("action")), int(body.get("action_revision") or 1), offset_points=float(body.get("offset_points") or 0),
                                    volume=None if body.get("volume") is None else float(body["volume"]))
        except PlanError as exc:
            raise HTTPException(409, str(exc)) from exc

    @app.post("/api/v1/manual/reconcile")
    def manual_reconcile():
        return rt.manual.reconcile()

    # ------------------------------------------------------------ PMW-UPD-07 structure intelligence (GET never trains)
    def _si_inst(asset):
        a = asset or rt.cfg.get().assets.active
        rt.assets.check_asset(a, "STRUCTURE_INTELLIGENCE")
        return a

    @app.get("/api/v1/structure-intelligence")
    def si_latest():
        snap = rt.si.last
        return {"snapshot": snap, "status": "OK" if snap else "NO_SNAPSHOT_YET",
                "jobs": [rt.si.job(j) for j in list(rt.si.jobs)[-5:]]}

    @app.get("/api/v1/structure-intelligence/snapshots/{sid}")
    def si_snapshot(sid: str):
        r = rt.db.one("SELECT payload FROM si_snapshots WHERE snapshot_id=?", (sid,))
        if not r:
            raise HTTPException(404, "SNAPSHOT_NOT_FOUND")
        return json.loads(r["payload"])

    @app.get("/api/v1/structure-intelligence/forecasts")
    def si_forecasts(asset: str | None = None, limit: int = Query(50, ge=1, le=500)):
        return {"items": rt.si.forecasts(_si_inst(asset), limit)}

    @app.get("/api/v1/structure-intelligence/models")
    def si_models(asset: str | None = None):
        from ..lab import structure_task as T
        a = _si_inst(asset)
        reg = T._reg(a)
        return {"instrument": a, "shadow": reg.get("shadow"), "runs": reg.get("runs"), "holdout_access": list((reg.get("holdout_access") or {}).keys()),
                "indicator_profile": T.indicator_profile(a), "families": list(T.FAMILIES_ALL), "execution": "NEVER_AUTOMATIC"}

    @app.post("/api/v1/structure-intelligence/models/select")
    def si_select(body: dict = Body(...)):
        from ..lab import structure_task as T
        try:
            return T.select_shadow(_si_inst(body.get("asset")), str(body.get("candidate_id")))
        except (ValueError, OSError) as exc:
            raise HTTPException(409, str(exc)) from exc

    @app.post("/api/v1/structure-intelligence/models/rollback")
    def si_rollback(body: dict = Body(...)):
        from ..lab import structure_task as T
        try:
            return T.rollback(_si_inst(body.get("asset")), str(body.get("task") or T.TASK_MOVE))
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc

    @app.get("/api/v1/structure-intelligence/neutralization")
    def si_neutral(asset: str | None = None, limit: int = Query(120, ge=1, le=2000)):
        return rt.si.neutralization(_si_inst(asset), limit)

    @app.get("/api/v1/structure-intelligence/quotes")
    def si_quotes():
        return rt.si.quotes_public()

    @app.get("/api/v1/structure-intelligence/quote-forecasts")
    def si_quote_fc(limit: int = Query(100, ge=1, le=1000)):
        return {"items": rt.si.quote_forecasts(limit)}

    @app.get("/api/v1/structure-intelligence/quote-quality")
    def si_quote_q():
        return rt.si.quote_quality()

    # ------------------------------------------------------------ PMW-UPD-09 R21-R25 sections (read-only; GET never trains)
    def _mkey(asset, tf):
        a = _si_inst(asset)
        if tf not in ("M1", "M5", "M15", "H1"):
            raise HTTPException(400, "TF_INVALID")
        k = rt.si.market.keys.get((a, tf))
        if k is None:
            raise HTTPException(404, "NO_MARKET_STATE_YET (sekcja powstaje przy pierwszym snapshocie Structure Intelligence)")
        return k

    @app.get("/api/v1/structure-intelligence/regimes")
    def si_regimes(asset: str | None = None, tf: str = "M1", limit: int = Query(300, ge=1, le=600)):
        return rt.si.market.regimes(_mkey(asset, tf), limit)

    @app.get("/api/v1/structure-intelligence/swings")
    def si_swings(asset: str | None = None, tf: str = "M1", as_of: float | None = None, limit: int = Query(120, ge=1, le=600)):
        return rt.si.market.swings(_mkey(asset, tf), as_of, limit)

    @app.get("/api/v1/structure-intelligence/swings/{sid}")
    def si_swing(sid: str, asset: str | None = None, as_of: float | None = None):
        r = rt.si.market.swing(_si_inst(asset), sid, as_of)
        if r is None:
            raise HTTPException(404, "SWING_NOT_FOUND (kontekst usunięty albo spoza okna)")
        return r

    @app.get("/api/v1/structure-intelligence/smma")
    def si_smma(asset: str | None = None, tf: str = "M1", limit: int = Query(200, ge=1, le=600)):
        return rt.si.market.smma(_mkey(asset, tf), limit)

    @app.get("/api/v1/structure-intelligence/zscore")
    def si_zscore(asset: str | None = None, tf: str = "M1", mode: str = "INCLUSIVE_N", n: int = Query(20, ge=2, le=500)):
        if mode not in ("INCLUSIVE_N", "PREVIOUS_N"):
            raise HTTPException(400, "ZSCORE_MODE_INVALID")
        return rt.si.market.zscore(_mkey(asset, tf), mode, n)

    @app.get("/api/v1/structure-intelligence/native-status")
    def si_native(asset: str | None = None):
        return rt.si.native_status(_si_inst(asset))

    @app.get("/api/v1/structure-intelligence/model-diagnostics")
    def si_model_diag(asset: str | None = None, run: str | None = None):
        from ..lab import structure_task as T
        a = _si_inst(asset)
        reg = T._reg(a)
        rid = run or (sorted(reg["runs"])[-1] if reg["runs"] else None)
        if not rid or rid not in reg["runs"]:
            return {"status": "NO_RUNS"}
        rp = Path(reg["runs"][rid]["run_dir"]) / "report.json"
        rep = json.loads(rp.read_text(encoding="utf-8")) if rp.exists() else {}
        diag = {}
        for f in rep.get("folds", []):
            for fam, res in (f.get("families") or {}).items():
                for r in res:
                    if r.get("diagnostics"):
                        diag.setdefault(fam, []).append({"fold": f["fold"], "seed": r.get("seed"), "status": r.get("status"), **r["diagnostics"]})
        return {"run_id": rid, "role": rep.get("role"), "spike_profile": rep.get("spike_profile"), "transform": rep.get("transform"),
                "diagnostics": diag, "status": rep.get("status")}

    # ------------------------------------------------------------ PMW-UPD-11 flow context (read-only; GET never trains)
    def _fkey(asset, tf):
        a = _si_inst(asset)
        if tf not in ("M1", "M5", "M15", "H1"):
            raise HTTPException(400, "TF_INVALID")
        k = rt.si.flow.keys.get((a, tf))
        if k is None:
            raise HTTPException(404, "NO_FLOW_STATE_YET (powstaje przy pierwszym snapshocie)")
        return k

    @app.get("/api/v1/flow-context")
    def fc_summary(asset: str | None = None):
        a = _si_inst(asset)
        return {"instrument": a, "tfs": {tf: rt.si.flow.summary(k) for (i, tf), k in rt.si.flow.keys.items() if i == a},
                "profile": __import__("masterquo.lab.flow_context.task", fromlist=["profile"]).profile(a)}

    @app.get("/api/v1/flow-context/series")
    def fc_series(asset: str | None = None, tf: str = "M15", limit: int = Query(300, ge=1, le=800)):
        return rt.si.flow.series(_fkey(asset, tf), limit)

    @app.get("/api/v1/flow-context/channels")
    def fc_channels(asset: str | None = None, tf: str = "M15", as_of: str | None = None, mode: str = "CURRENT_MAP_FULL_WIDTH"):
        if mode not in ("CURRENT_MAP_FULL_WIDTH", "HISTORY_AS_KNOWN"):
            raise HTTPException(400, "MODE_INVALID")
        return rt.si.flow.channels(_fkey(asset, tf), as_of, mode)

    @app.get("/api/v1/flow-context/markov")
    def fc_markov(asset: str | None = None):
        return rt.si.flow.markov(_fkey(asset, "M1"))

    @app.get("/api/v1/flow-context/stopdistance")
    def fc_stop(asset: str | None = None, tf: str = "M15", entry: float | None = None, side: str | None = None, strategy_sl_points: float | None = None):
        return rt.si.flow.stopdistance(_fkey(asset, tf), entry, side, strategy_sl_points)

    @app.get("/api/v1/flow-context/native")
    def fc_native(asset: str | None = None):
        a = _si_inst(asset)
        return rt.si.flow.native(a, rt.cfg.get().mt5.symbol)

    @app.get("/api/v1/flow-context/models")
    def fc_models(asset: str | None = None):
        from ..lab.flow_context import task as FT
        a = _si_inst(asset)
        reg = FT._reg(a)
        return {"instrument": a, "runs": reg["runs"], "shadow": reg["shadow"], "families": list(FT.FAMILIES), "task": FT.TASK, "schema": FT.SCHEMA,
                "execution": "NEVER_AUTOMATIC"}

    # ------------------------------------------------------------ PMW-UPD-14 VAMD / FD / SMC / Buffer Inspector (GET never trains)
    def _ckey(asset, tf):
        a = _si_inst(asset)
        if tf not in ("M1", "M5", "M15", "H1"):
            raise HTTPException(400, "TF_INVALID")
        k = rt.si.ctx.keys.get((a, tf))
        if k is None:
            raise HTTPException(404, "NO_CONTEXT_STATE_YET (powstaje przy pierwszym snapshocie)")
        return k

    @app.get("/api/v1/lab/context")
    def ctx_summary(asset: str | None = None):
        from ..lab.context_ind import task as CT
        a = _si_inst(asset)
        return {"instrument": a, "tfs": {tf: rt.si.ctx.summary(k) for (i, tf), k in rt.si.ctx.keys.items() if i == a}, "profile": CT.profile(a)}

    @app.get("/api/v1/lab/vamd")
    def ctx_vamd(asset: str | None = None, tf: str = "M5", limit: int = Query(300, ge=1, le=600)):
        return rt.si.ctx.vamd(_ckey(asset, tf), limit)

    @app.get("/api/v1/lab/fractal-regime")
    def ctx_fd(asset: str | None = None, tf: str = "M5", limit: int = Query(300, ge=1, le=600)):
        return rt.si.ctx.fractal(_ckey(asset, tf), limit)

    @app.get("/api/v1/lab/smc")
    def ctx_smc(asset: str | None = None, tf: str = "M5", as_of: float | None = None, limit: int = Query(300, ge=1, le=800)):
        return rt.si.ctx.smc(_ckey(asset, tf), as_of, limit)

    @app.get("/api/v1/lab/buffers/reports")
    def buf_reports():
        from ..lab.context_ind import buffers as BF
        return {"reports": BF.list_reports(), "note": "raporty importowane z PWM_BufferInspector (MT5); panel nie skanuje terminala zdalnie"}

    @app.get("/api/v1/lab/buffers/reports/{rid}")
    def buf_report(rid: str):
        from ..lab.context_ind import buffers as BF
        r = BF.get_report(rid)
        if r is None:
            raise HTTPException(404, "REPORT_NOT_FOUND")
        return r

    @app.post("/api/v1/lab/buffers/reports/import")
    def buf_import(body: dict = Body(...)):
        from ..extind.contract import EnvelopeError
        from ..lab.context_ind import buffers as BF
        files = os.environ.get("MQ_MT5_FILES_DIR")
        name = str(body.get("file") or "PWM_BUFFER_REPORT.json")
        if not files or not name.replace("_", "").replace("-", "").replace(".", "").isalnum() or not name.endswith(".json"):
            raise HTTPException(400, "FILE_NOT_WHITELISTED_OR_NO_FILES_DIR")
        p = Path(files) / "PMW" / name
        if not p.exists():
            raise HTTPException(404, "REPORT_FILE_MISSING (uruchom PWM_BufferInspector w MT5)")
        try:
            d = BF.import_report(p.read_bytes())
        except EnvelopeError as exc:
            raise HTTPException(422, str(exc)) from exc
        return {"report_id": d["report_id"], "coverage": d["coverage"], "instances": len(d.get("instances") or [])}

    @app.get("/api/v1/lab/buffers/mappings")
    def buf_mappings():
        from ..lab.context_ind import buffers as BF
        return {"mappings": BF.mappings(), "required": list(BF.MAPPING_REQUIRED)}

    @app.post("/api/v1/lab/buffers/mappings/validate")
    def buf_validate(body: dict = Body(...)):
        from ..lab.context_ind import buffers as BF
        return BF.validate_mapping(body)

    @app.post("/api/v1/lab/buffers/mappings")
    def buf_save(body: dict = Body(...)):
        from ..lab.context_ind import buffers as BF
        return BF.save_mapping({k: body.get(k) for k in BF.MAPPING_REQUIRED + ("chart_window", "instance", "notes")})

    @app.post("/api/v1/lab/buffers/mappings/{mid}/rollback")
    def buf_rollback(mid: str):
        from ..lab.context_ind import buffers as BF
        try:
            return BF.rollback_mapping(mid)
        except ValueError as exc:
            raise HTTPException(404, str(exc)) from exc

    @app.get("/api/v1/lab/buffers/source")
    def buf_source(tf: str = "M5"):
        return rt.si.ctx.external(rt.cfg.get().mt5.symbol, tf)

    @app.post("/api/v1/lab/context/calibrate")
    def ctx_calibrate(body: dict = Body(default={})):
        kind = {"calibrate": "context_calibrate", "dataset": "context_dataset", "train": "context_train"}.get(str(body.get("step") or "calibrate"))
        if kind is None:
            raise HTTPException(400, "STEP_INVALID")
        try:
            return rt.si.start_job(kind, {k: body.get(k) for k in ("asset", "families", "profile")})
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc

    @app.get("/api/v1/structure-intelligence/quality")
    def si_quality(asset: str | None = None):
        return rt.si.quality(_si_inst(asset))

    @app.post("/api/v1/structure-intelligence/jobs")
    def si_job_start(body: dict = Body(...)):
        try:
            return rt.si.start_job(str(body.get("kind")), {k: body.get(k) for k in ("asset", "task", "families", "profile", "experiment", "sew_operators", "days",
                                                                                  "encoder", "attention", "transform")})
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc

    @app.get("/api/v1/structure-intelligence/jobs/{jid}")
    def si_job(jid: str):
        j = rt.si.job(jid)
        if not j:
            raise HTTPException(404, "JOB_NOT_FOUND")
        return j

    @app.post("/api/v1/structure-intelligence/jobs/{jid}/cancel")
    def si_job_cancel(jid: str):
        return {"ok": rt.si.cancel(jid)}

    # ------------------------------------------------------------ PMW-UPD-07 R05 Black-76 (pure maths; HV is never shown as IV)
    @app.post("/api/v1/black76/price")
    def b76_price(body: dict = Body(...)):
        from ..analytics import black76 as B
        try:
            d = B.discount(body.get("rate"), float(body["t_years"]), body.get("discount"))
            return B.price(float(body["forward"]), float(body["strike"]), float(body["sigma"]), float(body["t_years"]), d)
        except (KeyError, TypeError, ValueError) as exc:
            raise HTTPException(400, f"INVALID_INPUT: {exc}") from exc

    @app.post("/api/v1/black76/iv")
    def b76_iv(body: dict = Body(...)):
        from ..analytics import black76 as B
        try:
            d = B.discount(body.get("rate"), float(body["t_years"]), body.get("discount"))
            return dict(B.implied_vol(float(body["premium"]), float(body["forward"]), float(body["strike"]), float(body["t_years"]), d,
                                      str(body.get("kind") or "call")), source="IV_FROM_PREMIUM", version=B.VERSION)
        except (KeyError, TypeError, ValueError) as exc:
            raise HTTPException(400, f"INVALID_INPUT: {exc}") from exc

    @app.post("/api/v1/black76/forward")
    def b76_forward(body: dict = Body(...)):
        from ..analytics import black76 as B
        try:
            return B.forward_from_parity(list(body.get("pairs") or []), float(body.get("discount") or 1.0), exercise_style=str(body.get("exercise_style") or "UNKNOWN"))
        except (TypeError, ValueError) as exc:
            raise HTTPException(400, f"INVALID_INPUT: {exc}") from exc

    @app.get("/api/v1/analytics")
    def analytics_get():
        return {**rt.analytics.summary(), "config": rt.cfg.get().analytics.model_dump()}

    @app.get("/api/v1/analytics/tf/{tf}")
    def analytics_tf(tf: str):
        if tf not in rt.cfg.get().analytics.timeframes:
            raise HTTPException(404, "TF_NOT_CONFIGURED")
        return rt.analytics.tf_state(tf, full=True)

    @app.get("/api/v1/analytics/history")
    def analytics_history(module: str | None = None, tf: str | None = None, limit: int = Query(100, ge=1, le=1000)):
        return {"items": rt.analytics.history(module, tf, limit)}

    @app.get("/api/v1/analytics/diagnostics")
    def analytics_diag():
        return rt.analytics.diagnostics()

    @app.get("/api/v1/patterns/samples")
    def pat_list(symbol: str | None = None, tf: str | None = None, status: str | None = None, rules_version: str | None = None):
        return {"items": rt.analytics.library.list(symbol, tf, status, rules_version), "jobs": rt.analytics.library.jobs(10)}

    @app.post("/api/v1/patterns/samples")
    def pat_add(body: dict = Body(...)):
        """Sample from the chart selection: {tf, start_utc, end_utc, note} - closed bars of the bot's feed (raw OHLCV kept)."""
        tf = str(body.get("tf") or "")
        bars = [b for b in rt.bridge.bars(tf, None, include_forming=False) if b.get("open_utc")] if tf in ("M1", "M5", "M15", "M30", "H1", "H4", "D1") else []
        sel = [{k: b[k] for k in ("open_utc", "o", "h", "l", "c", "tv")} for b in bars if str(body.get("start_utc")) <= b["open_utc"] <= str(body.get("end_utc"))]
        if not sel:
            raise HTTPException(400, "NO_CLOSED_BARS_IN_RANGE")
        r = rt.analytics.library.add_sample(rt.cfg.get().mt5.symbol, tf, sel, "CHART_SELECTION" if not rt.bridge._synthetic else "CHART_SELECTION_SYNTHETIC",
                                            body.get("note"))
        if not r["ok"]:
            raise HTTPException(400, r["error"])
        return r

    @app.get("/api/v1/patterns/samples/{sid}")
    def pat_get(sid: int):
        s = rt.analytics.library.get(sid)
        if not s:
            raise HTTPException(404, "SAMPLE_NOT_FOUND")
        return s

    @app.delete("/api/v1/patterns/samples/{sid}")
    def pat_del(sid: int):
        return {"ok": rt.analytics.library.delete(sid)}

    @app.post("/api/v1/patterns/samples/{sid}/validate")
    def pat_validate_one(sid: int):
        r = rt.analytics.library.validate_one(sid)
        if not r["ok"]:
            raise HTTPException(404, r["error"])
        return r

    @app.post("/api/v1/patterns/validate")
    def pat_validate(body: dict = Body(...)):
        ids = body.get("ids")
        if ids is not None and (not isinstance(ids, list) or not all(isinstance(i, int) for i in ids)):
            raise HTTPException(400, "IDS_MUST_BE_INT_LIST_OR_NULL")
        return rt.analytics.library.start_job(ids)

    @app.get("/api/v1/patterns/jobs/{job_id}")
    def pat_job(job_id: str):
        j = rt.analytics.library.job(job_id)
        if not j:
            raise HTTPException(404, "JOB_NOT_FOUND")
        return j

    @app.post("/api/v1/patterns/jobs/{job_id}/cancel")
    def pat_cancel(job_id: str):
        return {"ok": rt.analytics.library.cancel(job_id)}

    @app.post("/api/v1/patterns/jobs/{job_id}/resume")
    def pat_resume(job_id: str):
        r = rt.analytics.library.resume(job_id)
        if not r["ok"]:
            raise HTTPException(409, r["error"])
        return r

    @app.post("/api/v1/patterns/jobs/{job_id}/export")
    def pat_export_job(job_id: str):
        """Re-export the report from STORED results (no validation)."""
        return rt.analytics.library.export(job_id)

    @app.get("/api/v1/patterns/jobs/{job_id}/results")
    def pat_job_results(job_id: str):
        return {"job_id": job_id, "items": rt.analytics.library.results(job_id)}

    @app.get("/api/v1/patterns/results/{result_id}")
    def pat_result(result_id: str):
        """Saved immutable result for SHOW ON CHART - never re-analyses (REVALIDATE is the explicit POST validate)."""
        r = rt.analytics.library.result(result_id)
        if not r:
            raise HTTPException(404, "RESULT_NOT_FOUND")
        return r

    @app.get("/api/v1/patterns/samples/{sid}/result")
    def pat_sample_result(sid: int):
        r = rt.analytics.library.latest_result(sid)
        if not r:
            raise HTTPException(404, "NO_SAVED_RESULT – najpierw waliduj (VALIDATE / REVALIDATE)")
        return r

    @app.get("/api/v1/patterns/reports/{report_id}")
    def pat_report(report_id: str):
        r = rt.analytics.library.report(report_id)
        if not r:
            raise HTTPException(404, "REPORT_NOT_FOUND")
        return r

    @app.get("/api/v1/patterns/export")
    def pat_export():
        return rt.analytics.library.export_samples()

    @app.post("/api/v1/patterns/import")
    def pat_import(body: dict = Body(...)):
        return rt.analytics.library.import_samples(body)

    @app.get("/api/v1/patterns/live")
    def pat_live():
        a = rt.cfg.get().analytics
        return {"timeframes": {tf: (rt.analytics.state.get(tf) or {}).get("double_bottom") for tf in a.db_timeframes},
                "events": rt.analytics.events(50), "profile": a.db_profile}

    @app.get("/api/v1/scalp")
    def scalp_get():
        """Scalp profile (M5 Range -> M1 Sweep/Reclaim -> Retest) + hedge controller in SHADOW: MTF, setup, indicators, adapters,
        forecasts, hedge/risk, training and the separate validity statuses. Never an order permission."""
        return {**rt.scalp.public(), "config": rt.cfg.get().scalp.model_dump(), "profile": rt.scalp.prof, "registry": rt.scalp.registry()}

    # ------------------------------------------------------------------ PMW-SH-1 SCALPING / HEDGING
    _telemetry_cache: dict = {"t": 0.0, "models": None}

    @app.get("/api/v1/telemetry")
    def telemetry():
        """Compact, read-only view for the main menu's model-flow maps: real publishing activity per event topic (count, last time),
        the model registry with each module's status (cached 15 s - probing is not free), the SCALPING / HEDGING service state and
        the engine's decision nodes. No values are invented: a missing part is null."""
        from ..sh import models as SHM
        inst = rt.sh.instrument()
        now = time.time()
        if _telemetry_cache["models"] is None or now - _telemetry_cache["t"] > 15 or _telemetry_cache.get("inst") != inst:
            try:
                mx = SHM.matrix(rt, inst)
                _telemetry_cache.update(t=now, inst=inst, models={"mode": mx.get("mode"), "rows": [
                    {k: r.get(k) for k in ("id", "name", "kind", "output", "group", "train", "status", "reason")} |
                    {"roles": {st: (r.get(st) or {}) for st in ("SCALPING", "HEDGING")}} for r in mx["rows"]]})
            except Exception as exc:  # noqa: BLE001 - the menu shows the error instead of a fake registry
                _telemetry_cache.update(t=now, inst=inst, models={"mode": None, "rows": [], "error": f"{type(exc).__name__}: {exc}"[:200]})
        sh = rt.sh.public()
        ev = {k: {"status": v.get("status"), "status_reason": v.get("status_reason"), "side": v.get("side"),
                  "score": (v.get("score") or {}).get("value") if isinstance(v.get("score"), dict) else v.get("score")}
              for k, v in (sh.get("last_eval") or {}).items()}
        d = getattr(rt.engine, "decision", None) or {}
        return {"server_time": time.time(), "boot_id": rt.bus.boot_id, "seq": rt.bus.seq, "instrument": inst, "topics": rt.bus.activity(),
                "models": _telemetry_cache["models"],
                "sh": {"status": sh.get("status"), "reason": sh.get("reason"), "mode": sh.get("mode"), "last_eval": ev},
                "engine": {"decision": d.get("decision"), "signal_stage": d.get("signal_stage"), "data_quality": d.get("data_quality"),
                           "tree": [{"node": n.get("node"), "status": n.get("status")} for n in (d.get("decision_tree") or [])]} if d else None}

    @app.get("/api/v1/sh")
    def sh_get():
        """Strategy panel: service state, last evaluation per strategy (checklist, levels, models, risk, coordination), open plans
        with position / basket state, single config source with hash, model matrix and the event-model status."""
        from ..sh import config as SHC, models as SHM, tpmodel as SHT
        inst = rt.sh.instrument()
        st = rt.sh.public()
        return {**{k: v for k, v in st.items() if k != "snapshot"}, "config": SHC.load(), "config_errors": SHC.validate(SHC.load()),
                "models": SHM.matrix(rt, inst), "tp_model": SHT.status(inst), "snapshot": rt.sh.snapshot, "server_time": time.time()}

    @app.get("/api/v1/sh/scenario")
    def sh_scenario(strategy: str = Query("SCALPING"), volume: float | None = Query(None, gt=0, le=1000)):
        """Price-move scenario 2.5-10 USD on top of the strategy's setup: per level the move, leg volume, account result from the tick
        value, spread / commission / slippage separately, Monte Carlo P(TP before SL) (model or calibrated) and the models each
        with its own event. Analysis only - orders stay with the SCALPING cycle."""
        if strategy not in ("SCALPING", "HEDGING"):
            raise HTTPException(400, "BAD_STRATEGY")
        from ..sh import scenario as SHS
        return SHS.build(rt, strategy, volume)

    _SH_TFS = ("M1", "M3", "M5", "M15", "H1")

    def _sh_vid(v):
        from ..sh.pack import catalog as _CAT
        if v is None:
            return None
        if v not in _CAT.IDS and v not in ("LEGACY_SCALPING", "LEGACY_HEDGING"):
            raise HTTPException(400, "STRATEGY_ID_UNKNOWN")
        return v

    def _sh_tf(v):
        if v is None:
            return None
        if v not in _SH_TFS:
            raise HTTPException(400, "INVALID_TIMEFRAME")
        return v

    @app.get("/api/v1/sh/signals")
    def sh_signals(strategy: str | None = None, strategy_id: str | None = None, tf: str | None = None, symbol: str | None = None,
                   limit: int = Query(100, ge=1, le=1000)):
        """SH signal history; 1.38 filters: strategy (family), strategy_id (PMW_.. or LEGACY_SCALPING / LEGACY_HEDGING), tf, symbol."""
        if strategy is not None and strategy not in ("SCALPING", "HEDGING"):
            raise HTTPException(400, "BAD_STRATEGY")
        rows = rt.sh.store.recent_signals(strategy, 0.0, limit, strategy_id=_sh_vid(strategy_id), tf=_sh_tf(tf), symbol=symbol)
        return {"items": rt.sh.store.signals_with_levels(rows)}

    @app.get("/api/v1/sh/strategies")
    def sh_strategies():
        """Catalog of the 20 variants (one owner of names / TFs / parameters / readiness / validation) + the live evaluation state."""
        from ..sh.pack import catalog as _CAT
        pk = getattr(rt.sh, "pack", None)
        out = {**_CAT.public(), "live": pk.public() if pk is not None else None}
        try:                                              # 1.39: VOL_GARCH state for HG09 (volatility_method VOL_GARCH) - read only
            out["garch"] = rt.sh.garch_artifact(rt.sh.instrument() or "XAUUSD")
        except Exception as exc:  # noqa: BLE001 - the catalog stays available
            out["garch"] = {"status": "ERROR", "error": type(exc).__name__}
        return out

    @app.post("/api/v1/sh/strategies/config")
    def sh_strategies_config(body: dict = Body(...)):
        """Variant parameter override (validated, versioned). New candidates only - open plans keep their frozen variant."""
        from ..sh.pack import catalog as _CAT
        try:
            cfg = _CAT.save_override(body, who="panel")
        except (ValueError, KeyError) as exc:
            raise HTTPException(400, str(exc)[:400])
        rt.log.info("SH", "PACK_CONFIG", f"Zmiana konfiguracji pakietu 20 wariantów – hash {cfg['hash']}")
        return _CAT.public(cfg)

    @app.get("/api/v1/sh/pack/stats")
    def sh_pack_stats(strategy_id: str | None = None):
        """Closed plans of the variants grouped by variant / TF / execution mode (PAPER is never mixed with AUTO_DEMO / AUTO_LIVE).
        Whole-cycle results (one plan = one result, partials are not separate wins); R from the plan's own initial risk."""
        vid = _sh_vid(strategy_id)
        rows = rt.db.query("SELECT strategy_id, signal_tf, exec_mode, result FROM sh_plans WHERE strategy_id IS NOT NULL AND result IS NOT NULL"
                           + (" AND strategy_id=?" if vid else ""), (vid,) if vid else ())
        out: dict = {}
        for r in rows:
            res = json.loads(r["result"]) if r.get("result") else {}
            k = f"{r['strategy_id']}|{r['signal_tf']}|{r['exec_mode']}"
            g = out.setdefault(k, {"strategy_id": r["strategy_id"], "signal_tf": r["signal_tf"], "exec_mode": r["exec_mode"], "n": 0, "wins": 0,
                                   "sum_r": 0.0, "n_r": 0, "net_money": 0.0, "hedge_activations": 0})
            g["n"] += 1
            if res.get("r_multiple") is not None:
                g["n_r"] += 1
                g["sum_r"] += float(res["r_multiple"])
                g["wins"] += 1 if float(res["r_multiple"]) > 0 else 0
            g["net_money"] += float(res.get("net_money") or 0.0)
            g["hedge_activations"] += int(res.get("hedge_activations") or 0)
        for g in out.values():
            g["expectancy_r"] = round(g["sum_r"] / g["n_r"], 4) if g["n_r"] else None
            g["net_money"] = round(g["net_money"], 2)
        return {"items": sorted(out.values(), key=lambda x: (x["strategy_id"], x["signal_tf"] or "", x["exec_mode"])),
                "note": "wynik całego cyklu planu; PAPER oddzielnie od rachunku – nie jest walidacją OOS (patrz replay pakietu)"}

    @app.get("/api/v1/sh/pack/evaluations")
    def sh_pack_evaluations(strategy_id: str | None = None, tf: str | None = None):
        """Current evaluation of every variant x signal TF (READY / WAIT / NO_TRADE / INVALIDATED / EXPIRED with reason codes). Read-only:
        a GET never runs a scan, a training or an order."""
        pk = getattr(rt.sh, "pack", None)
        if pk is None:
            return {"items": []}
        vid, f = _sh_vid(strategy_id), _sh_tf(tf)
        items = []
        for (k, stf), su in sorted(pk.last.items()):
            if (vid and k != vid) or (f and stf != f):
                continue
            items.append({k2: su.get(k2) for k2 in ("strategy_id", "strategy", "signal_id", "side", "status", "status_reason", "entry_ref", "sl",
                                                  "tps", "valid_until", "checklist", "risk", "coordination", "created_at")} | {"pack": su.get("pack")})
        return {"items": items, "timing": pk.timing()}

    @app.get("/api/v1/sh/signals/{sid}")
    def sh_signal(sid: str):
        r = rt.sh.store.signal(sid)
        if not r:
            raise HTTPException(404)
        return r

    @app.get("/api/v1/plans/chart")
    def plans_chart(layer: str = Query("SCALP"), history: int = Query(10, ge=0, le=100), strategy_id: str | None = None, tf: str | None = None,
                    plan_id: str | None = None, symbol: str | None = None, family: str | None = None):
        """PMW-PLAN-1 chart layers: Pepe Scalp Plan (SCALPING) / Pepe Hedge Plan (HEDGING) - levels from the strategy plan and fills.
        1.38: layer=PACK (or any strategy_id / tf / plan_id filter) -> PMW-PLAN-2 views of the 20 variants (family from layer SCALP/HEDGE)."""
        from ..plans import service as _PS
        if layer.upper() == "PACK" or strategy_id or tf or plan_id:
            fam = {"SCALP": "SCALPING", "HEDGE": "HEDGING", "SCALPING": "SCALPING", "HEDGING": "HEDGING"}.get((family or layer).upper())
            if plan_id is not None and not re.match(r"^PL-[0-9a-f]{14}$", plan_id):
                raise HTTPException(400, "PLAN_ID_INVALID")
            return _PS.collect_pack(rt.sh, strategy_id=_sh_vid(strategy_id), family=fam, tf=_sh_tf(tf), plan_id=plan_id, history=history, symbol=symbol)
        strat = {"SCALP": "SCALPING", "HEDGE": "HEDGING", "SCALPING": "SCALPING", "HEDGING": "HEDGING"}.get(layer.upper())
        if strat is None:
            raise HTTPException(400, "LAYER_INVALID")
        return _PS.collect(rt.sh, strat, history=history)

    @app.get("/api/v1/sh/plans")
    def sh_plans(open_only: bool = False, limit: int = Query(50, ge=1, le=500)):
        q = rt.sh.quote(time.time())
        if open_only:
            return {"items": [rt.sh.plan_view(p, q) for p in rt.sh.store.open_plans()]}
        rows = rt.db.query("SELECT plan_id FROM sh_plans ORDER BY created_at DESC LIMIT ?", (limit,))
        return {"items": [rt.sh.plan_view(rt.sh.store.plan(r["plan_id"]), q) for r in rows]}

    @app.get("/api/v1/sh/plans/{pid}")
    def sh_plan(pid: str):
        r = rt.sh.store.plan(pid)
        if not r:
            raise HTTPException(404)
        v = rt.sh.plan_view(r, rt.sh.quote(time.time()))
        v.update(result=r.get("result"), actions=rt.sh.store.actions(pid), events=rt.sh.store.events(pid))
        return v

    @app.post("/api/v1/sh/plans/{pid}/close")
    def sh_plan_close(pid: str):
        """Explicit, user-confirmed close of one SH plan (primary + hedge) through its state machine (no Execution Lock since 1.24; the plan account must match)."""
        r = rt.sh.close_plan(pid, "MANUAL_CLOSE")
        rt.log.warn("SH", "MANUAL_CLOSE", f"Zamknięcie planu {pid} na żądanie: {r}")
        return r

    @app.get("/api/v1/sh/validation")
    def sh_validation(instrument: str = Query("XAUUSD")):
        """Validation reports of the SH strategies on REAL exported data (written by `sh train`); absent = not run yet."""
        if instrument not in ("XAUUSD", "BTC"):
            raise HTTPException(400, "UNKNOWN_INSTRUMENT")
        out = {}
        for strat in ("SCALPING", "HEDGING"):
            p = paths.data_dir() / "sh" / "validation" / f"{instrument}_{strat}.json"
            try:
                out[strat] = {"status": "VERIFIED_REPLAY", "report": json.loads(p.read_text(encoding="utf-8"))} if p.exists() else \
                    {"status": "NOT_RUN", "reason": "brak raportu walidacji na danych z terminala – uruchom zadanie sh_models (30_SH_WALIDACJA.bat)"}
            except (OSError, ValueError) as exc:
                out[strat] = {"status": "ERROR", "reason": str(exc)[:200]}
        return {"instrument": instrument, "strategies": out}

    @app.get("/api/v1/sh/config")
    def sh_config_get():
        from ..sh import config as SHC
        return SHC.load()

    @app.post("/api/v1/sh/config")
    def sh_config_set(body: dict = Body(...)):
        """Panel change of the single SH config source (validated, versioned). Open plans keep their frozen parameters."""
        from ..sh import config as SHC
        try:
            cfg = SHC.save_override(body, who="panel")
        except ValueError as exc:
            raise HTTPException(400, str(exc))
        rt.log.info("SH", "CONFIG", f"Zmiana konfiguracji SH – wersja {cfg['_override_version']}, hash {cfg['_hash']}")
        return cfg

    @app.post("/api/v1/sh/config/rollback")
    def sh_config_rollback():
        from ..sh import config as SHC
        try:
            return SHC.rollback_override()
        except ValueError as exc:
            raise HTTPException(409, str(exc))

    @app.get("/api/v1/sh/chart")
    def sh_chart(tf: str = Query("M1"), limit: int = Query(240, ge=20, le=1000)):
        if tf not in ("M1", "M3", "M5", "M15"):
            raise HTTPException(400, "INVALID_TIMEFRAME")
        bars = [b for b in rt.bridge.bars(tf, limit, include_forming=True) if b.get("open_utc")]
        return {"tf": tf, "bars": bars, "quote": rt.sh.quote(time.time()), "last_eval": rt.sh.last_eval,
                "open_plans": [rt.sh.plan_view(p, rt.sh.quote(time.time())) for p in rt.sh.store.open_plans()]}

    @app.get("/api/v1/scalp/shadow")
    def scalp_shadow(limit: int = Query(100, ge=1, le=1000)):
        return {"items": rt.scalp.recent(limit), "summary": rt.scalp.summary()}

    @app.get("/api/v1/forecast/shadow")
    def forecast_shadow(limit: int = Query(100, ge=1, le=1000)):
        return {"items": rt.forecast.recent(limit)}

    @app.post("/api/v1/forecast/reload")
    def forecast_reload():
        rt.forecast.reload()
        rt.log.info("FORECAST", "RELOAD", "Przeładowanie modelu prognoz – nowa wersja od następnej zamkniętej świecy M5.")
        return {"ok": True}

    @app.get("/api/v1/walls")
    def walls_get():
        snap = {k: v for k, v in (rt.walls.last or {}).items() if not k.startswith("_")}
        return {"status": rt.walls.status(), "snapshot": snap,
                "note": "HV_PROXY = zmienność historyczna brokera jako przybliżenie – nie zmienność implikowana. Walls to pasma konwencji log-zwrotu, nie prognoza."}

    @app.post("/api/v1/walls/iv-import")
    def walls_iv_import(body: dict = Body(...)):
        from ..analysis import iv_import
        text = str(body.get("text") or "")
        if not text or len(text) > 1_000_000:
            raise HTTPException(400, "IV_IMPORT_EMPTY_OR_TOO_LARGE")
        try:
            rows = iv_import.parse_text(text, body.get("format"))
        except Exception as exc:
            raise HTTPException(400, f"IV_IMPORT_PARSE_ERROR: {type(exc).__name__}") from exc
        rep = iv_import.store(rt.db, rows, imported_by="MONITOR")
        rt.log.info("WALLS", "IV_IMPORT", f"Import IV: przyjęto {rep['accepted']}, odrzucono {len(rep['rejected'])}, już zapisane {rep['already_stored']} "
                    "(użycie od available_at; dotyczy przyszłych snapshotów).")
        rt.engine.mark_dirty()
        return rep

    @app.get("/api/v1/structure")
    def structure(tf: str = Query("M5")):
        if tf not in TIMEFRAMES:
            raise HTTPException(400, "INVALID_TIMEFRAME")
        return rt.engine.structure(tf)

    # ------------------------------------------------------------ markets (scanner) and AI signals
    import re as _re

    def _sym(symbol: str) -> str:
        if not _re.fullmatch(SYMBOL_RX, symbol or ""):
            raise HTTPException(400, "INVALID_SYMBOL")
        return symbol

    # ------------------------------------------------------------ 1.14 assets (XAUUSD / BTC) and Execution Lock
    @app.get("/api/v1/assets")
    def assets_state(refresh: bool = False):
        if refresh:
            rt.assets.refresh()
        return rt.assets.state()

    @app.get("/api/v1/assets/{asset}/candidates")
    def assets_candidates(asset: str):
        try:
            return {"asset": asset, "candidates": rt.assets.candidates(asset),
                    "note": "Kandydaci wg metadanych terminala (currency_base/profit). Nic nie jest wybierane automatycznie."}
        except PermissionError as exc:
            raise HTTPException(403, str(exc)) from exc
        except Exception as exc:
            raise HTTPException(409, f"{type(exc).__name__}: {exc}") from exc

    @app.post("/api/v1/assets/confirm")
    def assets_confirm(req: AssetConfirmReq):
        if not _re.fullmatch(SYMBOL_RX, req.broker_symbol or ""):
            raise HTTPException(400, "INVALID_SYMBOL")
        try:
            st = rt.assets.confirm(req.asset, req.broker_symbol)
        except PermissionError as exc:
            raise HTTPException(403, str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc
        rt.db.execute("INSERT INTO settings_audit(ts, change_json) VALUES (?,?)", (iso(utcnow()), json.dumps({"asset_confirm": req.model_dump()})))
        return st

    @app.post("/api/v1/assets/active")
    def assets_active(req: AssetActiveReq):
        old = rt.cfg.get().mt5.symbol
        try:
            st = rt.assets.switch(req.asset)
        except PermissionError as exc:
            raise HTTPException(409, str(exc)) from exc
        rt.db.execute("INSERT INTO settings_audit(ts, change_json) VALUES (?,?)", (iso(utcnow()), json.dumps({"active_asset": req.asset})))
        if rt.cfg.get().mt5.symbol != old:
            rt.modes.reset("ACTIVE_ASSET_CHANGED")
            rt.bridge.state = "RECONNECTING"
            rt.bridge.next_retry = 0
        rt.engine.mark_dirty()
        rt.bus.publish("assets", st)
        return st

    LOCK_NOTE = ("Execution Lock został wycofany (1.24, decyzja użytkownika). O wysyłce zleceń decydują: tryb wykonania, potwierdzony "
                 "rachunek (DEMO / REAL), STOP nowych wejść, limity ryzyka użytkownika, aktualne dane i warunki brokera.")

    @app.get("/api/v1/execution/lock")
    def exec_lock():
        """Compatibility read for older monitors: the lock no longer exists and blocks nothing."""
        return {"lock": "WITHDRAWN", "note": LOCK_NOTE}

    @app.post("/api/v1/execution/lock")
    def exec_lock_set():
        raise HTTPException(410, "EXECUTION_LOCK_WITHDRAWN")

    @app.get("/api/v1/markets")
    def markets():
        return rt.scanner.summary()

    @app.post("/api/v1/markets/scan")
    def markets_scan():
        if rt.bridge.state != "CONNECTED":
            raise HTTPException(503, "MT5_NOT_CONNECTED")
        rt.scanner.scan_now()
        return {"queued": True}

    @app.get("/api/v1/markets/symbols")
    def markets_symbols(all: bool = False):
        try:
            return {"symbols": rt.bridge.list_symbols(visible_only=not all)}
        except Exception as exc:
            raise HTTPException(503, f"SYMBOLS_UNAVAILABLE: {exc}") from exc

    @app.get("/api/v1/markets/detail")
    def markets_detail(symbol: str = Query(...), fresh: bool = False):
        _sym(symbol)
        r = None if fresh else rt.scanner.get(symbol)
        if r is None:
            try:
                r = rt.scanner.analyze_symbol(symbol)
            except Exception as exc:
                raise HTTPException(404, f"SYMBOL_UNAVAILABLE: {exc}") from exc
        return r

    @app.get("/api/v1/markets/chart")
    def markets_chart(symbol: str = Query(...), tf: str = Query("H1"), bars: int = Query(300, ge=50, le=1500)):
        _sym(symbol)
        if tf not in TIMEFRAMES:
            raise HTTPException(400, "INVALID_TIMEFRAME")
        try:
            meta = rt.bridge.symbol_meta(symbol, select=rt.cfg.get().markets.source != "MARKET_WATCH")
            if meta is None:
                raise ValueError("SYMBOL_NOT_FOUND")
            data = rt.bridge.symbol_bars(symbol, tf, bars)
            from ..engine import volzones
            vol = volzones.compute(rt.bridge.symbol_bars(symbol, "D1", 420), rt.cfg.get().volatility, digits=int(meta.get("digits") or 5),
                                   quote=rt.bridge.symbol_quote(symbol, meta.get("point")))
        except Exception as exc:
            raise HTTPException(404, f"SYMBOL_UNAVAILABLE: {exc}") from exc
        sig = rt.signals.list(symbol=symbol, limit=10)["items"]
        return {"symbol": symbol, "tf": tf, "meta": meta, "bars": data, "volatility": vol,
                "bot_signals": [x for x in sig if x["status"] == "OPEN"][:3], "synthetic": rt.bridge.synthetic}

    @app.get("/api/v1/signal-history")
    def signal_history(strategy: str | None = None, status: str | None = None, tf: str | None = None, limit: int = Query(100, ge=1, le=1000)):
        where, args = ["synthetic=?"], [int(bool(rt.bridge.synthetic))]
        for col, val in (("strategy_id", strategy), ("status", status), ("entry_tf", tf)):
            if val:
                where.append(f"{col}=?")
                args.append(val)
        rows = rt.db.query(f"SELECT record_json FROM signal_history WHERE {' AND '.join(where)} ORDER BY updated_at DESC LIMIT ?", (*args, limit))
        return {"items": [json.loads(r["record_json"]) for r in rows]}

    @app.get("/api/v1/context-tf")
    def context_tf_view():
        d = rt.engine.current_decision() or {}
        return {"context": d.get("context_tf"), "signal": d.get("signal")}

    @app.get("/api/v1/bot-signals")
    def bot_signals(symbol: str | None = None, limit: int = Query(50, ge=1, le=500), rejected: bool = True):
        if symbol:
            _sym(symbol)
        return {**rt.signals.list(symbol=symbol, limit=limit, include_rejected=rejected), **rt.signals.status()}

    @app.get("/api/v1/bot-signals/{signal_id}")
    def bot_signal_get(signal_id: str):
        r = rt.signals.get(signal_id)
        if not r:
            raise HTTPException(404, "NOT_FOUND")
        return r

    @app.get("/api/v1/signals")
    def signals(limit: int = 30):
        from ..engine.lifecycle import public_setup
        legacy = [public_setup(r) for r in rt.engine.lifecycle.recent(min(limit, 100))]
        active = [{"setup_id": r["setup_id"], "created_at": r["first_seen_at"], "strategy_id": r["record"]["strategy_id"],
                   "profile": f"ACTIVE {r['record']['timeframe']}", "direction": r["record"]["direction"],
                   "state": r["stage"] if r["status"] == "ACTIVE" else r["status"], "invalidation_level": r["record"].get("invalidation_level"),
                   "terminal_reason": r.get("terminal_reason"), "synthetic": bool(r["record"].get("synthetic"))}
                  for r in rt.engine.active.tracker.recent(min(limit, 100))]
        setups = sorted(active + legacy, key=lambda x: x["created_at"] or "", reverse=True)[:limit]
        decs = rt.db.query("SELECT decision_id, created_at, setup_id, analysis_direction, signal_stage, decision, execution_permission FROM decisions "
                           "WHERE decision IN ('BUY','SELL') OR signal_stage IN ('CONFIRMED','INVALIDATED','EXPIRED') ORDER BY created_at DESC LIMIT 50")
        trades = rt.db.query("SELECT * FROM trades ORDER BY closed_at DESC LIMIT 50")
        return {"setups": setups, "decisions": decs, "attempts": rt.gateway.recent_attempts(30), "trades": trades}

    @app.get("/api/v1/decision")
    def decision():
        return rt.engine.current_decision()

    @app.get("/api/v1/stats")
    def get_stats(mode: str = "PAPER"):
        if mode not in ("PAPER", "AUTO_DEMO", "AUTO_LIVE"):
            raise HTTPException(400, "INVALID_MODE")
        b = rt.bridge
        with b._lock:
            deals = list(b.deals)
        ds = b.server_day_start_utc()
        ds_raw = ds.timestamp() + b.clock.offset if ds and b.clock.offset is not None else None
        return {"bot": stats.bot_stats(rt.db, mode, b.account_key), "engines": stats.engine_stats(rt.db, mode, b.account_key),
                "equity": stats.equity_curve(rt.db, "PAPER" if mode == "PAPER" else "ACCOUNT", b.account_key),
                "account": stats.account_stats(deals, rt.cfg.get().mt5.symbol, ds_raw) if b.account_key else None,
                "account_roi": stats.account_roi(rt.db, b.account_key, deals, b.clock.offset)}

    @app.get("/api/v1/news")
    def news():
        return rt.news.summary()

    @app.get("/api/v1/logs")
    def logs(limit: int = 200):
        return logs_list(min(max(limit, 1), 2000))

    @app.get("/api/v1/config")
    def get_config():
        c = rt.cfg.get().model_dump(mode="json")
        return {"config": c, "secrets": {n: {"source": rt.secrets.source(n), "masked": rt.secrets.mask(n)}
                                         for n in ("ANTHROPIC_API_KEY", "TELEGRAM_BOT_TOKEN", "FRED_API_KEY", "MT5_PASSWORD")},
                "editable_note": "Klucze API są przechowywane lokalnie (Windows DPAPI) i nigdy nie są zwracane przez API."}

    @app.put("/api/v1/config")
    def put_config(patch: dict = Body(...)):
        patch.pop("server", None)
        # 1.14: asset mapping / active asset / Execution Lock change only through their dedicated, checked endpoints
        patch.pop("assets", None)
        m5 = patch.get("mt5") or {}
        m5.pop("analytical_alias", None)
        if m5.get("symbol"):                       # symbol typed in Ustawienia -> becomes the active asset's broker symbol
            patch.setdefault("assets", {})["mappings"] = {rt.cfg.get().assets.active: {"broker_symbol": m5["symbol"], "status": "USER_SPECIFIED"}}
        ex_patch = patch.get("execution")
        if isinstance(ex_patch, dict):
            # the execution mode and its account binding change only through POST /api/v1/mode (account confirmation) -
            # never through a generic config write, so automatic orders cannot be switched on silently. Values equal to the
            # current ones (a settings form sending the section back unchanged) are dropped; a different value is refused.
            cur_ex = rt.cfg.get().execution
            for k in ("mode", "bound_account", "mode_note"):
                if k in ex_patch:
                    if ex_patch[k] != getattr(cur_ex, k, None):
                        raise HTTPException(400, "USE_MODE_ENDPOINT")
                    ex_patch.pop(k)
        try:
            old = rt.cfg.get()
            new = rt.cfg.update(patch)
        except Exception as exc:
            raise HTTPException(400, f"INVALID_CONFIG: {exc}") from exc
        rt.db.execute("INSERT INTO settings_audit(ts, change_json) VALUES (?,?)", (iso(utcnow()), json.dumps({"config_patch": patch}, default=str)))
        rt.log.info("CONFIG", "UPDATED", "Zmieniono konfigurację: " + ", ".join(sorted(patch.keys())))
        if (old.mt5.symbol, old.mt5.terminal_path, old.mt5.dxy_symbol) != (new.mt5.symbol, new.mt5.terminal_path, new.mt5.dxy_symbol):
            rt.modes.reset("MT5_CONFIG_CHANGED")
            rt.bridge.state = "RECONNECTING"
            rt.bridge.next_retry = 0
        if old.risk != new.risk:
            rt.log.info("CONFIG", "RISK_LIMITS_CHANGED", "Zmieniono limity ryzyka – obowiązują od następnej decyzji.")
        rt.engine.mark_dirty()
        return get_config()

    @app.post("/api/v1/secrets/anthropic")
    def set_key(req: KeyReq):
        rt.secrets.set("ANTHROPIC_API_KEY", req.api_key)
        rt.log.info("AGENT", "KEY_SET", "Zapisano lokalnie klucz Anthropic (wartość nie jest logowana).")
        return {"ok": True, "masked": rt.secrets.mask("ANTHROPIC_API_KEY")}

    @app.post("/api/v1/secrets")
    def set_secret(req: SecretReq):
        if req.name not in ("TELEGRAM_BOT_TOKEN", "FRED_API_KEY", "ANTHROPIC_API_KEY", "MT5_PASSWORD"):
            raise HTTPException(400, "UNKNOWN_SECRET")
        rt.secrets.set(req.name, req.value)
        if req.name == "MT5_PASSWORD":                 # new password: try to connect again (value never logged)
            rt.log.info("MT5", "PASSWORD_SET", "Zapisano lokalnie hasło MT5 (wartość nie jest logowana).")
            if rt.bridge.state != "CONNECTED":
                rt.bridge.next_retry = 0
        return {"ok": True, "source": rt.secrets.source(req.name)}

    # ------------------------------------------------------------ agent
    @app.get("/api/v1/agent")
    def agent_status():
        runs = rt.db.query("SELECT run_id, started_at, finished_at, trigger, snapshot_id, setup_id, model_id, prompt_version, status, error_code, "
                           "latency_ms, input_tokens, output_tokens, est_cost_usd, tool_calls, question FROM agent_runs ORDER BY started_at DESC LIMIT 30")
        return {"status": rt.agent.status(), "last": rt.agent.public_result(rt.agent.last_result), "runs": runs}

    @app.get("/api/v1/agent/models")
    async def agent_models():
        return await rt.agent.list_models()

    @app.post("/api/v1/agent/test")
    async def agent_test():
        return await rt.agent.test_connection()

    @app.post("/api/v1/agent/ask")
    def agent_ask(req: AskReq):
        d = rt.engine.current_decision() or {}
        s = d.get("setup") or {}
        rid = rt.agent.request("USER_QUESTION", snapshot_id=d.get("snapshot_id"), setup_id=s.get("setup_id") if s.get("state") in
                               ("EARLY_SETUP", "QUALIFIED", "ARMED", "TRIGGERED", "CONFIRMED") else None, setup_state=s.get("state"), question=req.question)
        return {"queued": bool(rid), "request_id": rid}

    @app.post("/api/v1/agent/analyze")
    def agent_analyze():
        d = rt.engine.current_decision() or {}
        s = d.get("setup") or {}
        active = s.get("state") in ("EARLY_SETUP", "QUALIFIED", "ARMED", "TRIGGERED", "CONFIRMED")
        trig = "SETUP_CONFIRMED" if s.get("state") == "CONFIRMED" else "MANUAL"
        rid = rt.agent.request(trig, snapshot_id=d.get("snapshot_id"), setup_id=s.get("setup_id") if active else None, setup_state=s.get("state"))
        return {"queued": bool(rid), "request_id": rid}

    @app.get("/api/v1/agent/memory")
    def agent_memory():
        return rt.db.query("SELECT * FROM agent_memory ORDER BY id DESC LIMIT 100")

    @app.post("/api/v1/agent/memory/{mid}")
    def agent_memory_set(mid: int, req: MemoryReq):
        if req.status not in ("ACCEPTED_FOR_OOS_TEST", "REJECTED", "PROPOSED"):
            raise HTTPException(400, "INVALID_STATUS")
        rt.db.execute("UPDATE agent_memory SET status=? WHERE id=?", (req.status, mid))
        rt.log.info("AGENT", "MEMORY_STATUS", f"Propozycja {mid}: {req.status} (nie zmienia strategii LIVE)")
        return {"ok": True}

    # ------------------------------------------------------------ modes & execution
    @app.post("/api/v1/mode")
    def set_mode(req: ModeReq):
        try:
            return rt.modes.set_mode(req.mode, confirm=req.confirm, account=rt.bridge.account_status(), account_key=rt.bridge.account_key,
                                     synthetic=rt.bridge.synthetic)
        except ModeError as exc:
            raise HTTPException(400, str(exc)) from exc
        finally:
            rt.engine.mark_dirty()

    @app.post("/api/v1/mode/primary-path")
    def set_primary_path(req: PrimaryPathReq):
        try:
            return rt.modes.set_primary_path(req.instrument, req.path)
        except ModeError as exc:
            raise HTTPException(400, str(exc)) from exc
        finally:
            rt.engine.mark_dirty()

    # ------------------------------------------------------------ AUTO strategy selection (separate from order execution)
    def media_dir():
        d = paths.data_dir() / "assets" / "masterquo"
        d.mkdir(parents=True, exist_ok=True)
        return d

    @app.get("/api/v1/strategy/auto")
    def strategy_auto():
        return rt.engine.active.status()

    @app.post("/api/v1/strategy/mode")
    def strategy_mode(req: StrategyModeReq):
        if req.strategy_mode == "MANUAL" and not req.manual_strategy_id:
            raise HTTPException(400, "MANUAL_REQUIRES_STRATEGY_ID")
        try:
            rt.cfg.update({"active": {"strategy_mode": req.strategy_mode,
                                      "manual_strategy_id": req.manual_strategy_id if req.strategy_mode == "MANUAL" else None}})
        except Exception as exc:
            raise HTTPException(400, f"INVALID: {exc}") from exc
        # legacy switch -> the same per-account setup view the engine uses (one source)
        rt.prefs.set("setup_view", {"mode": "SELECTED" if req.strategy_mode == "MANUAL" else "AUTO", "strategy_id": req.manual_strategy_id})
        rt.engine.active.selector.reset("STRATEGY_MODE_CHANGED")
        rt.log.info("AUTO", "STRATEGY_MODE", f"Wybór strategii: {req.strategy_mode}" + (f" ({req.manual_strategy_id})" if req.strategy_mode == "MANUAL" else "")
                    + ". Tryb wykonywania zleceń bez zmian.")
        rt.engine.mark_dirty()
        return rt.engine.active.status(compact=True)

    # ------------------------------------------------------------ setup view + leverage (per account) and scenario details
    @app.get("/api/v1/prefs")
    def prefs_get():
        from ..prefs import LEVERAGE_CHOICES
        return {**rt.prefs.all(), "exposure": rt.prefs.exposure_limit(), "leverage_choices": list(LEVERAGE_CHOICES)}

    @app.post("/api/v1/prefs/setup-view")
    def prefs_setup_view(req: SetupViewReq):
        from ..prefs import PrefsError
        try:
            v = rt.prefs.set("setup_view", req.model_dump())
        except PrefsError as exc:
            raise HTTPException(400, str(exc)) from exc
        if v["mode"] != "ALL":
            rt.engine.active.selector.reset("SETUP_VIEW_CHANGED")
        rt.log.info("AUTO", "SETUP_VIEW", f"Wybór setupu: {v['mode']}" + (f" {v['strategy_id']}" if v["mode"] == "SELECTED" else "")
                    + " (nie wymusza sygnału ani zlecenia; wszystkie filtry obowiązują).")
        return prefs_get()

    @app.post("/api/v1/prefs/leverage")
    def prefs_leverage(req: LeverageReq):
        from ..prefs import PrefsError
        try:
            v = rt.prefs.set("leverage", req.model_dump())
        except PrefsError as exc:
            raise HTTPException(400, str(exc)) from exc
        rt.log.info("RISK", "LEVERAGE_LIMIT", ("Limit ekspozycji: AUTO (dźwignia rachunku z MT5)" if v["mode"] == "AUTO" else f"Limit ekspozycji ustawiony w bocie: 1:{v['limit']}")
                    + " – nie zmienia dźwigni u brokera; dotyczy przyszłych decyzji, istniejące pozycje bez zmian.")
        return prefs_get()

    @app.get("/api/v1/setups")
    def setups_list(include_terminal: bool = True):
        from ..engine import setup_details
        return setup_details.scenarios(rt.engine, include_terminal=include_terminal)

    @app.get("/api/v1/setups/{setup_id}/details")
    def setup_detail(setup_id: str):
        from ..engine import setup_details
        if len(setup_id) > 120:
            raise HTTPException(400, "SETUP_ID_INVALID")
        out = setup_details.details(rt.engine, setup_id)
        if out is None:
            raise HTTPException(404, "SETUP_NOT_FOUND")
        return out

    # ------------------------------------------------------------ ML (Decision Tree + XGBoost)
    @app.get("/api/v1/ml/status")
    def ml_status():
        return rt.ml.status()

    @app.post("/api/v1/ml/mode")
    def ml_mode(req: MLModeReq):
        try:
            return rt.ml.set_mode(req.mode)
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc

    @app.post("/api/v1/ml/collect")
    def ml_collect(req: MLFlagReq):
        return rt.ml.set_collect(req.on)

    @app.post("/api/v1/ml/pause")
    def ml_pause(req: MLFlagReq):
        return rt.ml.set_paused(req.on)

    @app.post("/api/v1/ml/train")
    def ml_train(req: MLTrainReq | None = None):
        """'Trenuj teraz': skips the waiting time/new-label threshold but never the data minimums of the validation blocks."""
        if rt.cfg.get().ml.training_paused:
            raise HTTPException(409, "TRAINING_PAUSED")
        res = rt.ml.start_training("USER", force=True, include_approx=req.include_approx if req else None)
        rt.bus.publish("ml", rt.ml.status(compact=True))
        return res

    # ------------------------------------------------------------ training installer (same backend as the BAT launchers)
    @app.get("/api/v1/training")
    def training_state():
        from ..training import core as tc
        from ..training import panel as tp
        rid = tc.Run.latest()
        st = tp.run_detail(rid) if rid else None
        from ..training.runner import TASKS
        return {"run": st, "profiles": {k: v["label"] for k, v in tc.profiles().items()}, "tasks": [{"kind": k, "title": t} for k, t in TASKS],
                "lock": tp.lock_holder()}

    # ---------------------------------------------------------------- PMW-SH-1 training panel (registry, readiness, history, export)
    @app.get("/api/v1/training/models")
    def training_models(instrument: str = Query(...)):
        from ..training import panel as tp
        if instrument not in ("XAUUSD", "BTC"):
            raise HTTPException(400, "UNKNOWN_INSTRUMENT")
        return tp.models(rt, instrument)

    # ---------------------------------------------------------------- PMW-MM master models (inventory, SHADOW live view, ledger, rollback)
    def _mm_inst(instrument: str) -> str:
        if instrument not in ("XAUUSD", "BTC"):
            raise HTTPException(400, "UNKNOWN_INSTRUMENT")
        return instrument

    @app.get("/api/v1/mm/status")
    def mm_status(instrument: str = Query("XAUUSD")):
        return rt.mm.status(_mm_inst(instrument))

    @app.get("/api/v1/zones/map")
    def zones_map(tf: str = Query("ALL"), as_of: str | None = Query(None), full: bool = Query(False)):
        if tf not in ("ALL", "M5", "M15"):
            raise HTTPException(400, "INVALID_TF")
        from ..zones.series import ts as _ts
        if as_of:
            try:
                t = _ts(as_of)
            except ValueError as exc:
                raise HTTPException(400, "INVALID_AS_OF") from exc
            zm = rt.zones.at(t)
        else:
            zm = rt.zones.current_or_refresh()
        if zm is None:
            return {"status": "NO_MAP", "reason": rt.zones.state.get("last_error")}
        return zm if full else rt.zones.chart_view(zm, tf)

    # ---------------------------------------------------------------- 1.28 "Strefy rynkowe" (M1/M5/M15/M30, analytical only)
    def _mz_tfs(tfs):
        from ..zones.market import TFS as _MZTFS
        bad = [t for t in (tfs or []) if t not in _MZTFS]
        if bad:
            raise HTTPException(400, f"INVALID_TF:{','.join(bad)}")
        return tfs

    @app.get("/api/v1/market-zones")
    def market_zones(instrument: str = Query("XAUUSD"), all: bool = Query(False)):
        try:
            return rt.market_zones.view(instrument, all_zones=all)
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc

    @app.post("/api/v1/market-zones/compute")
    def market_zones_compute(req: MarketZonesReq):
        try:
            return rt.market_zones.request(req.instrument, _mz_tfs(req.timeframes), reason="manual")
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc

    @app.post("/api/v1/market-zones/live")
    def market_zones_live(req: MarketZonesLiveReq):
        try:
            return rt.market_zones.set_live(req.instrument, req.enabled, _mz_tfs(req.timeframes))
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc

    @app.post("/api/v1/market-zones/stop")
    def market_zones_stop(req: MarketZonesReq):
        return rt.market_zones.stop(req.instrument)

    @app.get("/api/v1/market-zones/job/{job_id}")
    def market_zones_job(job_id: str):
        j = rt.market_zones.job(job_id)
        if j is None:
            raise HTTPException(404, "JOB_NOT_FOUND")
        return j

    @app.get("/api/v1/market-zones/zone/{zone_id}")
    def market_zones_zone(zone_id: str, instrument: str = Query("XAUUSD")):
        d = rt.market_zones.zone(instrument, zone_id)
        if d is None:
            raise HTTPException(404, "ZONE_NOT_FOUND")
        return d

    @app.get("/api/v1/market-zones/events")
    def market_zones_events(instrument: str = Query("XAUUSD"), limit: int = Query(200, ge=1, le=2000)):
        return {"items": rt.market_zones.events(instrument, limit)}

    @app.get("/api/v1/market-zones/bars")
    def market_zones_bars(instrument: str = Query("XAUUSD"), tf: str = Query("M5"), count: int = Query(300, ge=30, le=1500)):
        _mz_tfs([tf])
        sym = rt.market_zones.symbol_for(instrument.upper())
        if not sym:
            return {"status": "NO_SYMBOL", "bars": [], "reason": f"brak symbolu brokera dla {instrument}"}
        try:
            rows = rt.bridge.symbol_bars(sym, tf, count)
        except Exception as exc:  # noqa: BLE001 - disconnected terminal: the panel keeps the last drawing marked stale
            return {"status": "ERROR", "bars": [], "reason": f"{type(exc).__name__}: {exc}"[:200]}
        return {"status": "OK", "symbol": sym, "tf": tf, "bars": [{k: b.get(k) for k in ("open_utc", "o", "h", "l", "c", "tv", "spread", "closed")}
                                                                   for b in rows if b.get("open_utc")]}

    @app.get("/api/v1/market-zones/as-of")
    def market_zones_as_of(as_of: str, instrument: str = Query("XAUUSD"), tf: str | None = Query(None)):
        from ..zones.series import ts as _ts
        try:
            t = _ts(as_of)
        except ValueError as exc:
            raise HTTPException(400, "INVALID_AS_OF") from exc
        try:
            return rt.market_zones.at(instrument, t, _mz_tfs([tf]) if tf else None)
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(503, f"{type(exc).__name__}: {exc}"[:200]) from exc

    # ---------------------------------------------------------------- 1.28 Centrum treningu + rejestr modeli (wspólny kontrakt)
    def _th_inst(x: str) -> str:
        x = (x or "").upper()
        if x not in ("XAUUSD", "BTC"):
            raise HTTPException(400, "INSTRUMENT_NOT_ALLOWED")
        return x

    _SAFE = re.compile(r"^[A-Za-z0-9_\-]{1,64}$")

    # ---- 1.41 Training Center components (dispatch by component kind): TH_SDFORMERFLOW (weights), ETC_LOG_CHANNEL (transform config)
    def _comp():
        return _research().components

    @app.get("/api/v1/trainhub/components")
    def th_components():
        return _comp().status()

    @app.post("/api/v1/trainhub/components/{cid}/jobs")
    def th_component_job(cid: str, body: dict = Body(default={})):
        try:
            r = _comp().start_job(cid, str(body.get("kind") or "").upper(), body)
        except ValueError as exc:
            raise HTTPException(400, str(exc))
        if not r.get("ok", True):
            raise HTTPException(409, r.get("reason") or r.get("state"))
        return r

    @app.post("/api/v1/trainhub/components/{cid}/cancel")
    def th_component_cancel(cid: str):
        return _comp().cancel(cid)

    @app.post("/api/v1/trainhub/components/{cid}/activate")
    def th_component_activate(cid: str, body: dict = Body(...)):
        c = _comp()
        r = c.activate_sdf(str(body.get("version"))) if cid == "TH_SDFORMERFLOW" else c.etc_activate(str(body.get("version")))
        if not r.get("ok"):
            raise HTTPException(409, r.get("reason") or "aktywacja nieudana")
        return r

    @app.post("/api/v1/trainhub/components/{cid}/rollback")
    def th_component_rollback(cid: str):
        c = _comp()
        r = c.rollback_sdf() if cid == "TH_SDFORMERFLOW" else c.etc_rollback()
        if not r.get("ok"):
            raise HTTPException(409, r.get("reason"))
        return r

    @app.get("/api/v1/trainhub/components/{cid}/export.zip")
    def th_component_export(cid: str, version: str):
        try:
            data = _comp().export_zip(cid, version)
        except FileNotFoundError:
            raise HTTPException(404, "brak wersji")
        return Response(data, media_type="application/zip", headers={"Content-Disposition": f'attachment; filename="{cid}_{version}.zip"'})

    @app.post("/api/v1/trainhub/components/{cid}/import")
    async def th_component_import(cid: str, request: Request):
        data = await request.body()
        if not data or len(data) > 200 * 1024 * 1024:
            raise HTTPException(400, "puste lub zbyt duże archiwum")
        try:
            return _comp().import_zip(cid, data)
        except (ValueError, KeyError, __import__("zipfile").BadZipFile) as exc:
            raise HTTPException(400, f"import odrzucony: {exc}")

    @app.get("/api/v1/trainhub/status")
    def trainhub_status():
        from ..marketdata.store import Store
        from ..trainhub import learn as _L
        from ..trainhub import pipeline as _P
        st = Store()
        data = {}
        for i in ("XAUUSD", "BTC"):
            man = st.manifest(i)
            data[i] = {"symbol": man.get("symbol") or rt.market_zones.symbol_for(i), "data_kind": man.get("data_kind"),
                       "timeframes": man.get("timeframes") or {}, "last_export": man.get("last_export"), "costs": man.get("costs"),
                       "time_model": man.get("time_model"), "updated_at": man.get("updated_at"), "parquet": man.get("parquet")}
        return {"jobs": rt.trainhub.list(30), "queue": rt.trainhub.status(), "data": data, "models": {k: {"name": v["name"], "available": _L.available()[k]}
                                                                                                         for k, v in _L.MODELS.items()},
                "defaults": _P.DEFAULTS, "note": "trening nie aktywuje modeli; aktywacja ręczna po teście zgodności i predykcji"}

    @app.post("/api/v1/trainhub/jobs")
    def trainhub_submit(req: TrainJobReq):
        try:
            return rt.trainhub.submit(req.kind, _th_inst(req.instrument), req.params)
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc

    @app.get("/api/v1/trainhub/jobs")
    def trainhub_jobs(limit: int = Query(50, ge=1, le=500)):
        return {"items": rt.trainhub.list(limit)}

    @app.get("/api/v1/trainhub/jobs/{jid}")
    def trainhub_job(jid: str):
        j = rt.trainhub.get(jid)
        if j is None:
            raise HTTPException(404, "JOB_NOT_FOUND")
        return {**j, "log_tail": rt.trainhub.log_tail(jid, 120)}

    @app.post("/api/v1/trainhub/jobs/{jid}/cancel")
    def trainhub_cancel(jid: str):
        try:
            return rt.trainhub.cancel(jid)
        except KeyError as exc:
            raise HTTPException(404, "JOB_NOT_FOUND") from exc

    @app.get("/api/v1/trainhub/data")
    def trainhub_data(instrument: str = Query("XAUUSD")):
        from ..marketdata.store import Store, read_json
        st = Store()
        i = _th_inst(instrument)
        return {"manifest": st.manifest(i), "quality": read_json(st.inst_dir(i) / "quality_report.json", None), "verify": st.verify(i)}

    @app.get("/api/v1/trainhub/registry")
    def trainhub_registry(instrument: str = Query("XAUUSD")):
        from ..trainhub import registry as _R
        return _R.summary(_th_inst(instrument))

    @app.get("/api/v1/trainhub/version")
    def trainhub_version(instrument: str, model_key: str, version: str):
        from ..marketdata.store import read_json
        from ..trainhub import registry as _R
        i = _th_inst(instrument)
        if not (_SAFE.match(model_key) and _SAFE.match(version)):
            raise HTTPException(400, "INVALID_ID")
        d = _R.package_dir(i, model_key, version)
        if not d.exists():
            raise HTTPException(404, "VERSION_NOT_FOUND")
        return {"config": read_json(d / "config.json", {}), "metrics": read_json(d / "metrics.json", {}), "deps": read_json(d / "deps.json", {}),
                "data_manifest": read_json(d / "data_manifest.json", {}), "compatibility": _R.compatibility(i, model_key, version),
                "evaluations": read_json(d.parent / f"{version}.evaluations.json", [])}

    @app.post("/api/v1/trainhub/activate")
    def trainhub_activate(req: TrainVersionReq):
        from ..trainhub import registry as _R
        i = _th_inst(req.instrument)
        if not req.version:
            raise HTTPException(400, "VERSION_REQUIRED")
        out = _R.activate(i, req.model_key, req.version, reason="panel – Centrum treningu")
        rt.trainhub_inference.invalidate(i)
        return out

    @app.post("/api/v1/trainhub/rollback")
    def trainhub_rollback(req: TrainVersionReq):
        from ..trainhub import registry as _R
        i = _th_inst(req.instrument)
        out = _R.rollback(i, req.model_key)
        rt.trainhub_inference.invalidate(i)
        return out

    @app.post("/api/v1/trainhub/deactivate")
    def trainhub_deactivate(req: TrainVersionReq):
        from ..trainhub import registry as _R
        i = _th_inst(req.instrument)
        out = _R.deactivate(i, req.model_key)
        rt.trainhub_inference.invalidate(i)
        return out

    @app.get("/api/v1/trainhub/package.zip")
    def trainhub_package_zip(instrument: str, model_key: str, version: str):
        from ..trainhub import registry as _R
        i = _th_inst(instrument)
        if not (_SAFE.match(model_key) and _SAFE.match(version)):
            raise HTTPException(400, "INVALID_ID")
        out = _R.root() / "exports" / f"{i}_{model_key}_{version}.zip"
        try:
            _R.export_zip(i, model_key, version, out)
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(409, f"{type(exc).__name__}: {exc}"[:200]) from exc
        return FileResponse(out, media_type="application/zip", filename=out.name)

    @app.get("/api/v1/trainhub/dataset.zip")
    def trainhub_dataset_zip(instrument: str, base_tf: str = "M5", horizon: int = 6):
        from ..trainhub import pipeline as _P
        from ..trainhub import registry as _R
        i = _th_inst(instrument)
        if base_tf not in ("M1", "M5", "M15", "M30"):
            raise HTTPException(400, "INVALID_TF")
        out = _R.root() / "exports" / f"{i}_dataset_{base_tf}_H{int(horizon)}.zip"
        try:
            _P.export_dataset_zip(i, {"base_tf": base_tf, "horizon": int(horizon)}, out)
        except FileNotFoundError as exc:
            raise HTTPException(404, str(exc)) from exc
        return FileResponse(out, media_type="application/zip", filename=out.name)

    @app.get("/api/v1/models/catalog")
    def models_catalog(instrument: str = Query("XAUUSD")):
        from ..modelhub import catalog as _CAT
        return _CAT.build(rt, _th_inst(instrument))

    @app.get("/api/v1/models/predictions")
    def models_predictions(instrument: str = Query("XAUUSD")):
        from ..modelhub import adapters as _AD
        i = _th_inst(instrument)
        return {"instrument": i, "items": _AD.all_predictions(rt, i), "contract": "PMW-PRED-1"}

    @app.get("/api/v1/models/evidence")
    def models_evidence(instrument: str = Query("XAUUSD"), strategy: str = Query("SCALPING")):
        from ..modelhub import aggregate as _AG
        i = _th_inst(instrument)
        if strategy not in ("SCALPING", "HEDGING"):
            raise HTTPException(400, "INVALID_STRATEGY")
        from ..modelhub import adapters as _AD
        return _AG.evidence(_AD.all_predictions(rt, i), strategy, i)

    # ------------------------------------------------------------------ Kronos (NeoQuasar/Kronos-small since 1.42.8; Kronos-base 1.37-1.42.7)
    _KR_TF = ("M1", "M5", "M15", "M30", "H1")

    def _kr_tf(tf: str) -> str:
        tf = (tf or "").upper()
        if tf not in _KR_TF:
            raise HTTPException(400, "TIMEFRAME_NOT_ALLOWED")
        return tf

    @app.get("/api/v1/kronos")
    def kronos_status():
        from kronos_runtime import lock as _KL
        kr = rt.kronos
        return {**kr.public(), "env": kr.env_status(), "settings": kr.settings.get().model_dump(mode="json"),
                "model": {"repo": _KL.MODEL["repo"], "revision": _KL.MODEL["revision"], "max_context": _KL.MAX_CONTEXT},
                "tokenizer": {"repo": _KL.TOKENIZER["repo"], "revision": _KL.TOKENIZER["revision"]}, "license": _KL.LICENSE,
                "data_kind": kr.data_kind()[0], "data_source": kr.data_kind()[1]}

    @app.get("/api/v1/kronos/forecast")
    def kronos_forecast(instrument: str = Query("XAUUSD"), tf: str = Query("M5")):
        return rt.kronos.forecast(_th_inst(instrument), _kr_tf(tf))

    @app.get("/api/v1/kronos/history")
    def kronos_history(instrument: str = Query("XAUUSD"), tf: str | None = Query(None), limit: int = Query(100, ge=1, le=2000)):
        return {"items": rt.kronos.history(_th_inst(instrument), _kr_tf(tf) if tf else None, limit)}

    @app.put("/api/v1/kronos/settings")
    def kronos_settings_put(body: dict = Body(...)):
        if "strategy_use" in body:
            raise HTTPException(400, "STRATEGY_USE_ONLY_VIA_/api/v1/kronos/strategy-use")
        try:
            s = rt.kronos.settings.update(body)
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(400, f"INVALID_SETTINGS: {exc}"[:500]) from exc
        rt.log.info("KRONOS", "SETTINGS", "Zmieniono ustawienia Kronos: " + ", ".join(sorted(body))[:200])
        return {"ok": True, "settings": s.model_dump(mode="json")}

    @app.post("/api/v1/kronos/enable")
    def kronos_enable(body: dict = Body(...)):
        on = bool(body.get("on"))
        rt.kronos.settings.update({"enabled": on})
        rt.log.info("KRONOS", "ENABLE", f"Kronos {'włączony' if on else 'wyłączony'} (tryb SHADOW).")
        return {"ok": True, "enabled": on}

    @app.post("/api/v1/kronos/install")
    def kronos_install(body: dict = Body(default={})):
        cuda = body.get("cuda")
        if cuda not in (None, "", "cu126", "cu128"):
            raise HTTPException(400, "CUDA_VARIANT_NOT_ALLOWED")
        r = rt.kronos.start_install(cuda or None)
        if not r.get("ok"):
            raise HTTPException(409, r.get("reason"))
        return r

    @app.post("/api/v1/kronos/verify")
    def kronos_verify():
        r = rt.kronos.start_verify(reference=True)
        if not r.get("ok"):
            raise HTTPException(409, r.get("reason"))
        return r

    @app.get("/api/v1/kronos/job/{name}")
    def kronos_job(name: str):
        if name not in ("install", "verify", "validation"):
            raise HTTPException(404, "UNKNOWN_JOB")
        return {"job": rt.kronos.job(name)}

    @app.post("/api/v1/kronos/refresh")
    def kronos_refresh(body: dict = Body(...)):
        r = rt.kronos.refresh(_th_inst(str(body.get("instrument", ""))), _kr_tf(str(body.get("tf", ""))))
        if not r.get("ok"):
            raise HTTPException(409, r.get("reason"))
        return r

    @app.post("/api/v1/kronos/validate")
    def kronos_validate(body: dict = Body(...)):
        n = int(body.get("max_origins", 300))
        if not 20 <= n <= 2000:
            raise HTTPException(400, "MAX_ORIGINS_OUT_OF_RANGE")
        r = rt.kronos.start_validation(_th_inst(str(body.get("instrument", ""))), _kr_tf(str(body.get("tf", ""))), n)
        if not r.get("ok"):
            raise HTTPException(409, r.get("reason"))
        return r

    @app.get("/api/v1/kronos/validation")
    def kronos_validation(instrument: str = Query("XAUUSD"), tf: str = Query("M5")):
        from ..kronos import validation as _KV
        rep = _KV.latest_report(_th_inst(instrument), _kr_tf(tf))
        if rep:
            rep = {k: v for k, v in rep.items() if k != "rows"} | {"rows_tail": (rep.get("rows") or [])[-50:]}
        return {"report": rep}

    @app.post("/api/v1/kronos/strategy-use")
    def kronos_strategy_use(body: dict = Body(...)):
        strat = str(body.get("strategy", "")).upper()
        use = str(body.get("use", "")).upper()
        tf = body.get("timeframe")
        r = rt.kronos.set_strategy_use(strat, use, timeframe=_kr_tf(tf) if tf else None, confirm=bool(body.get("confirm")))
        if not r.get("ok"):
            raise HTTPException(409, r.get("reason"))
        return r

    # ------------------------------------------------------------------ 1.37 Chronos-2 / 1.40 Granite TTM (+ three-model comparison with Kronos)
    _TS_TF = ("M1", "M3", "M5", "M15", "M30", "H1")

    def _ts_tf(tf: str) -> str:
        tf = (tf or "").upper()
        if tf not in _TS_TF:
            raise HTTPException(400, "TIMEFRAME_NOT_ALLOWED")
        return tf

    def _ts_mid(m: str, history: bool = False) -> str:
        m = (m or "").lower()
        if m not in ("chronos2", "granite_ttm", "tirex2") and not (history and m == "fincast"):   # fincast: RETIRED in 1.40 - history only
            raise HTTPException(400, "MODEL_RETIRED" if m == "fincast" else "MODEL_NOT_ALLOWED")
        return m

    # ------------------------------------------------------------------ 1.40 Memory Governor / AI scheduler (resources)
    @app.get("/api/v1/resources")
    def resources_get():
        """RAM of the computer, memory of the bot + every model process (current / peak), level, profile, inference p50 / p95, events."""
        if rt.governor is None:
            raise HTTPException(503, "GOVERNOR_UNAVAILABLE")
        return rt.governor.public()

    @app.put("/api/v1/resources/profile")
    def resources_profile(body: dict = Body(...)):
        from ..resources.governor import PROFILE_KEYS
        prof = str(body.get("profile") or "")
        if prof not in ("LOW_MEMORY_16GB", "LOW_MEMORY_12GB", "LOW_MEMORY_8GB", "AUTO", "ECO", "BALANCED", "MANUAL"):
            raise HTTPException(400, "PROFILE_UNKNOWN")
        manual = body.get("manual") or {}
        if not isinstance(manual, dict) or any(k not in PROFILE_KEYS for k in manual):
            raise HTTPException(400, "MANUAL_KEYS_UNKNOWN")
        before = rt.cfg.get().resources.model_dump(mode="json")
        try:
            rt.cfg.update({"resources": {"profile": prof, "manual": manual if prof == "MANUAL" else before.get("manual", {})}})
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(400, f"INVALID_RESOURCES: {exc}"[:300]) from exc
        rt.log.info("RESOURCES", "PROFILE", f"Profil zasobów: {before.get('profile')} → {prof}" + (f" ({manual})" if prof == "MANUAL" else ""))
        if rt.governor is None:
            raise HTTPException(503, "GOVERNOR_UNAVAILABLE")
        rt.governor._event("PROFILE", f"profil {before.get('profile')} → {prof}")
        return rt.governor.public()

    @app.get("/api/v1/models/foundation")
    def tsfm_status():
        """Status of the three foundation models in one place: Kronos (existing service) + Chronos-2 + Granite TTM (+ retired FinCast)."""
        from kronos_runtime import lock as _KL
        kr = rt.kronos
        return {**rt.tsfm.public(), "settings": rt.tsfm.settings.get().model_dump(mode="json"),
                "kronos": {"name": _KL.MODEL_NAME, "repo": _KL.MODEL["repo"], "revision": _KL.MODEL["revision"], "params_upstream": _KL.MODEL["params_upstream"],
                           "status": kr.state.get("status"), "reason": kr.state.get("reason"), "load": kr.load_info, "legacy": list(_KL.LEGACY),
                           "largest_public_note": "1.42.8: używany Kronos-small (24,7M, ok. 0,5 GB RAM) – prognoza dostępna także przy małej ilości wolnej pamięci; Kronos-base (102,3M) – historia 1.37–1.42.7"},
                "data_kind": rt.tsfm.data_kind()[0], "data_source": rt.tsfm.data_kind()[1]}

    @app.get("/api/v1/models/foundation/forecast")
    def tsfm_forecast(model: str = Query(...), instrument: str = Query("XAUUSD"), tf: str = Query("M5")):
        return rt.tsfm.forecast(_ts_mid(model), _th_inst(instrument), _ts_tf(tf))

    @app.get("/api/v1/models/foundation/compare")
    def tsfm_compare(instrument: str = Query("XAUUSD"), tf: str = Query("M5")):
        return rt.tsfm.compare(_th_inst(instrument), _ts_tf(tf))

    @app.get("/api/v1/models/foundation/history")
    def tsfm_history(model: str | None = Query(None), instrument: str = Query("XAUUSD"), tf: str | None = Query(None),
                     limit: int = Query(100, ge=1, le=2000)):
        return {"items": rt.tsfm.history(_ts_mid(model, history=True) if model else None, _th_inst(instrument), _ts_tf(tf) if tf else None, limit)}

    @app.put("/api/v1/models/foundation/settings")
    def tsfm_settings_put(body: dict = Body(...)):
        def has_use(d):
            return isinstance(d, dict) and any(k == "use" or has_use(v) for k, v in d.items())
        if has_use(body.get("models")):
            raise HTTPException(400, "USE_ONLY_VIA_/api/v1/models/foundation/use")
        if any(isinstance(v, dict) and "checkpoint" in v for v in (body.get("models") or {}).values()) or "retired" in body:
            raise HTTPException(400, "CHECKPOINT_ONLY_VIA_/api/v1/models/foundation/granite/activate")
        try:
            s = rt.tsfm.settings.update(body)
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(400, f"INVALID_SETTINGS: {exc}"[:500]) from exc
        rt.log.info("TSFM", "SETTINGS", "Zmieniono ustawienia Chronos-2/Granite TTM: " + ", ".join(sorted(body))[:200])
        return {"ok": True, "settings": s.model_dump(mode="json")}

    @app.post("/api/v1/models/foundation/install")
    def tsfm_install(body: dict = Body(...)):
        r = rt.tsfm.start_install(_ts_mid(body.get("model")))
        if not r.get("ok"):
            raise HTTPException(409, r.get("reason"))
        return r

    @app.post("/api/v1/models/foundation/verify")
    def tsfm_verify(body: dict = Body(...)):
        r = rt.tsfm.start_verify(_ts_mid(body.get("model")))
        if not r.get("ok"):
            raise HTTPException(409, r.get("reason"))
        return r

    @app.post("/api/v1/models/foundation/refresh")
    def tsfm_refresh(body: dict = Body(...)):
        r = rt.tsfm.refresh(_ts_mid(body.get("model")), _th_inst(str(body.get("instrument", ""))), _ts_tf(str(body.get("tf", ""))))
        if not r.get("ok"):
            raise HTTPException(409, r.get("reason"))
        return r

    @app.post("/api/v1/models/foundation/validate")
    def tsfm_validate(body: dict = Body(...)):
        n = int(body.get("max_origins", 200))
        if not 20 <= n <= 1000:
            raise HTTPException(400, "MAX_ORIGINS_OUT_OF_RANGE")
        r = rt.tsfm.start_validation(_th_inst(str(body.get("instrument", ""))), _ts_tf(str(body.get("tf", ""))), n)
        if not r.get("ok"):
            raise HTTPException(409, r.get("reason"))
        return r

    # ---- 1.40 Granite TTM in the Training Center (export, fine-tune job, versions, activation, rollback)
    @app.get("/api/v1/models/foundation/granite")
    def granite_get():
        from ..tsfm import granite_train as _GT
        c = rt.tsfm.settings.get().models["granite_ttm"]
        return {"checkpoint": c.checkpoint, "runs": _GT.runs(), "job": rt.tsfm.job("granite_train"),
                "rule": "trening nie startuje z botem; aktywacja tylko ręczna i tylko z werdyktem IMPROVED_VS_BASE na niewidzianych danych; powrót = BASE"}

    @app.post("/api/v1/models/foundation/granite/train")
    def granite_train(body: dict = Body(...)):
        from ..tsfm import granite_train as _GT
        epochs = int(body.get("epochs", 6))
        if not 1 <= epochs <= 30:
            raise HTTPException(400, "EPOCHS_OUT_OF_RANGE")
        trading = getattr(rt.modes, "mode", "SIGNALS") in ("AUTO_DEMO", "AUTO_LIVE")
        r = _GT.start(rt.tsfm, _th_inst(str(body.get("instrument", ""))), _ts_tf(str(body.get("tf", ""))), epochs=epochs,
                      confirm_during_trading=bool(body.get("confirm_during_trading")), trading_active=trading)
        if not r.get("ok"):
            raise HTTPException(409, r.get("reason"))
        return r

    @app.post("/api/v1/models/foundation/granite/cancel")
    def granite_cancel():
        from ..tsfm import granite_train as _GT
        r = _GT.cancel(rt.tsfm)
        if not r.get("ok"):
            raise HTTPException(409, r.get("reason"))
        return r

    @app.post("/api/v1/models/foundation/granite/activate")
    def granite_activate(body: dict = Body(...)):
        from ..tsfm import granite_train as _GT
        rid = str(body.get("run_id") or "")
        if not re.match(r"^GTR-[0-9A-Za-z_-]{6,64}$", rid):
            raise HTTPException(400, "RUN_ID_INVALID")
        r = _GT.activate(rt.tsfm, rid)
        if not r.get("ok"):
            raise HTTPException(409, r.get("reason"))
        return r

    @app.post("/api/v1/models/foundation/granite/rollback")
    def granite_rollback():
        from ..tsfm import granite_train as _GT
        return _GT.rollback(rt.tsfm)

    @app.get("/api/v1/models/foundation/job/{name}")
    def tsfm_job(name: str):
        if not re.match(r"^(install|verify)_(chronos2|granite_ttm|tirex2|tabicl)$|^validation$|^granite_train$", name):
            raise HTTPException(400, "JOB_UNKNOWN")
        return {"job": rt.tsfm.job(name)}

    @app.get("/api/v1/models/foundation/validation")
    def tsfm_validation(instrument: str = Query("XAUUSD"), tf: str = Query("M5")):
        from ..tsfm import validation as _TV
        rep = _TV.latest_report(_th_inst(instrument), _ts_tf(tf))
        if rep:
            rep = {k: v for k, v in rep.items() if k != "rows"} | {"rows_tail": (rep.get("rows") or [])[-50:]}
        return {"report": rep}

    @app.post("/api/v1/models/foundation/use")
    def tsfm_use(body: dict = Body(...)):
        r = rt.tsfm.set_use(_ts_mid(body.get("model")), str(body.get("path", "")).upper(), str(body.get("use", "")).upper(),
                            timeframe=_ts_tf(body["timeframe"]) if body.get("timeframe") else None, confirm=bool(body.get("confirm")))
        if not r.get("ok"):
            raise HTTPException(409, r.get("reason"))
        return r

    # ---------------------------------------------------------------- PMW-IND-1 indicators (1.33) - analytical, read-only
    def _ind_tf(tf):
        t = str(tf or "M5").upper()
        if t not in rt.cfg.get().indicators.avwap_tfs:
            raise HTTPException(400, f"TF_NOT_ENABLED_FOR_AVWAP:{t}")
        return t

    @app.get("/api/v1/indicators/status")
    def indicators_status():
        return rt.indicators.status()

    @app.get("/api/v1/indicators/snapshot")
    def indicators_snapshot(full: bool = Query(False)):
        s = rt.indicators.current_or_refresh()
        if s is None:
            return {"status": "NO_SNAPSHOT", "reason": rt.indicators.state.get("last_error")}
        return s if full else rt.indicators.compact(s)

    @app.post("/api/v1/indicators/refresh")
    def indicators_refresh():
        return rt.indicators.compact(rt.indicators.refresh())

    @app.get("/api/v1/indicators/chart")
    def indicators_chart(tf: str = Query("M5")):
        return rt.indicators.chart(_ind_tf(tf))

    @app.get("/api/v1/indicators/dxy")
    def indicators_dxy():
        s = rt.indicators.current_or_refresh() or {}
        return s.get("dxy") or {"status": "NO_SNAPSHOT"}

    @app.get("/api/v1/indicators/anchors")
    def indicators_anchors(tf: str | None = Query(None)):
        return {"items": rt.indicators.manual_anchors(_ind_tf(tf) if tf else None)}

    @app.post("/api/v1/indicators/anchors")
    def indicators_anchor_add(body: dict = Body(...)):
        tf = _ind_tf(body.get("tf"))
        st = body.get("source_time")
        if not st:
            raise HTTPException(400, "SOURCE_TIME_REQUIRED")
        try:
            from ..indicators import contract as _IC
            _IC.ts(st)
        except (TypeError, ValueError):
            raise HTTPException(400, "SOURCE_TIME_INVALID") from None
        label = str(body.get("label") or "")[:40] or None
        return rt.indicators.add_manual_anchor(tf, st, label)

    @app.delete("/api/v1/indicators/anchors/{anchor_id}")
    def indicators_anchor_del(anchor_id: str):
        if not rt.indicators.remove_manual_anchor(anchor_id):
            raise HTTPException(404, "ANCHOR_NOT_FOUND")
        return {"ok": True}

    @app.get("/api/v1/indicators/manifest")
    def indicators_manifest():
        return rt.indicators.manifest()

    # ---------------------------------------------------------------- Pepe Data & Training Studio: status + launch from the bot menu (1.33)
    def _studio_dirs() -> tuple[Path, Path]:
        bot = paths.data_dir()
        return bot, (bot.parent / "data_studio") if bot.name == "data" else (bot / "studio_data")

    def _studio_port(sdir: Path) -> int:
        try:
            return int(json.loads((sdir / "settings.json").read_text(encoding="utf-8")).get("port") or 8780)
        except (OSError, ValueError, TypeError):
            return 8780

    def _studio_probe() -> dict:
        import urllib.request
        _, sdir = _studio_dirs()
        port = _studio_port(sdir)
        out = {"port": port, "url": f"http://127.0.0.1:{port}/", "running": False, "health": None}
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/studio/health", timeout=0.8) as r:
                h = json.loads(r.read().decode("utf-8"))
            out.update(running=h.get("app") == "PepeTrainingStudio", health={k: h.get(k) for k in ("app", "studio", "version", "orders")})
        except Exception:  # noqa: BLE001 - not running / port taken by something else
            pass
        exe = os.environ.get("PMW_DESKTOP_EXE")
        st_exe = Path(exe).with_name("PepeTrainingStudio.exe") if exe else None
        out["launcher"] = "EXE" if st_exe is not None and st_exe.exists() else "PYTHON"
        return out

    @app.get("/api/v1/studio/status")
    def studio_status():
        return _studio_probe()

    @app.post("/api/v1/studio/launch")
    def studio_launch():
        """Start Pepe Training Studio as a SEPARATE process (never inside the bot). Already running -> its address."""
        import subprocess
        st = _studio_probe()
        if st["running"]:
            return {**st, "started": False, "note": "Studio już działa"}
        bot, sdir = _studio_dirs()
        sdir.mkdir(parents=True, exist_ok=True)
        flags = (getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)) if os.name == "nt" else 0
        if st["launcher"] == "EXE":
            cmd, env = [str(Path(os.environ["PMW_DESKTOP_EXE"]).with_name("PepeTrainingStudio.exe"))], dict(os.environ)
        else:
            env = {k: v for k, v in os.environ.items() if k not in ("MASTERQUO_DATA_DIR",)}
            env.update(MQ_BOT_DATA_DIR=str(bot), MQ_STUDIO_DATA_DIR=str(sdir), MASTERQUO_DATA_DIR=str(sdir))
            cmd = [sys.executable, "-m", "masterquo", "studio", "--port", str(st["port"])]
        try:
            p = subprocess.Popen(cmd, cwd=str(paths.BACKEND_DIR), env=env, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL, creationflags=flags, start_new_session=os.name != "nt")
        except OSError as exc:
            raise HTTPException(500, f"STUDIO_START_FAILED:{type(exc).__name__}") from None
        rt.log.info("STUDIO", "LAUNCH", f"Uruchomiono Pepe Training Studio ({st['launcher']}, pid {p.pid}, port {st['port']})")
        return {**st, "started": True, "pid": p.pid}

    # ---------------------------------------------------------------- Pepe Data & Training Studio import (1.33) - candidates only
    @app.post("/api/v1/studio/import")
    def studio_import(body: dict = Body(...)):
        from ..studio import importer as _IM
        r = _IM.import_package(str(body.get("package") or ""))
        if not r.get("ok"):
            raise HTTPException(409, r.get("reason"))
        return r

    @app.get("/api/v1/studio/imports")
    def studio_imports():
        from ..studio import importer as _IM
        return {"items": _IM.history(), "startup_inbox": getattr(rt, "studio_imports", [])}

    @app.delete("/api/v1/studio/import/{import_id}")
    def studio_import_rollback(import_id: str):
        from ..studio import importer as _IM
        r = _IM.rollback(import_id)
        if not r.get("ok"):
            raise HTTPException(409, r.get("reason"))
        return r

    # ---------------------------------------------------------------- PMW-FAM-1 model families (1.33)
    def _fam_inst(instrument):
        i = str(instrument or rt.cfg.get().assets.active).upper()
        if i not in ("XAUUSD", "BTC"):
            raise HTTPException(400, "INSTRUMENT_INVALID")
        return i

    def _fam(fn, *a, **k):
        try:
            return fn(*a, **k)
        except KeyError as exc:
            raise HTTPException(404, str(exc).strip("'")) from None
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from None

    @app.get("/api/v1/decision/status")
    def decision_status():
        """PMW-ARC-1: last decision of each path, live risk reservations, recent execution intents and decision records."""
        arc = getattr(rt, "arc", None)
        if arc is None:
            raise HTTPException(503, "DECISION_COORDINATOR_NOT_RUNNING")
        return arc.status()

    @app.get("/api/v1/decision/records/{record_id}")
    def decision_record(record_id: str):
        r = rt.db.one("SELECT record_json FROM decision_records WHERE record_id=?", (record_id,))
        if not r:
            raise HTTPException(404, "RECORD_NOT_FOUND")
        return json.loads(r["record_json"])

    @app.get("/api/v1/families")
    def families_catalog(instrument: str | None = Query(None)):
        inst = _fam_inst(instrument)
        return {"instrument": inst, "items": rt.families.catalog(inst),
                "axes": {"implementation": "dostępność kodu/zależności", "artifact": "artefakt i walidacja", "use": "OFF / SHADOW / ASSIST"},
                "note": "READY = zdolność zwrócenia wyniku, nie zgoda na handel ani dowód rentowności"}

    @app.get("/api/v1/families/{fid}/runs")
    def families_runs(fid: str, instrument: str | None = Query(None)):
        return {"items": _fam(rt.families.runs, fid, _fam_inst(instrument))}

    @app.post("/api/v1/families/{fid}/train")
    def families_train(fid: str, body: dict = Body(default={})):
        return _fam(rt.families.submit, fid, _fam_inst(body.get("instrument")), str(body.get("profile") or "smoke"))

    @app.post("/api/v1/families/train-all")
    def families_train_all(body: dict = Body(default={})):
        return _fam(rt.families.train_all, _fam_inst(body.get("instrument")), str(body.get("profile") or "smoke"))

    @app.post("/api/v1/families/{fid}/cancel")
    def families_cancel(fid: str, body: dict = Body(default={})):
        return _fam(rt.families.cancel, fid, _fam_inst(body.get("instrument")))

    @app.post("/api/v1/families/{fid}/activate")
    def families_activate(fid: str, body: dict = Body(...)):
        r = _fam(rt.families.activate, fid, _fam_inst(body.get("instrument")), str(body.get("run_id") or ""))
        if not r.get("ok"):
            raise HTTPException(409, r.get("reason"))
        return r

    @app.post("/api/v1/families/{fid}/rollback")
    def families_rollback(fid: str, body: dict = Body(default={})):
        return _fam(rt.families.rollback, fid, _fam_inst(body.get("instrument")))

    @app.post("/api/v1/families/{fid}/use")
    def families_use(fid: str, body: dict = Body(...)):
        return _fam(rt.families.set_use, fid, _fam_inst(body.get("instrument")), str(body.get("use") or "").upper())

    @app.get("/api/v1/families/predictions")
    def families_predictions(instrument: str | None = Query(None)):
        return {"items": rt.families.predictions(_fam_inst(instrument))}

    # ---------------------------------------------------------------- 1.35 PMW Quant Core (reads the published generation only)
    def _quant():
        q = getattr(rt, "quant", None)
        if q is None:
            raise HTTPException(503, "QUANT_CORE_NOT_RUNNING")
        return q

    @app.get("/api/v1/quant/status")
    def quant_status():
        """Mode, data state, model counts with reasons, meta-model artifacts, ledger evidence, timings - a cached snapshot (no compute)."""
        return _quant().status()

    @app.get("/api/v1/quant/predictions")
    def quant_predictions():
        return _quant().predictions()

    @app.get("/api/v1/quant/assessment")
    def quant_assessments(limit: int = Query(30, ge=1, le=200)):
        q = _quant()
        return {"items": q.ledger.assessments(limit), "mode": q.mode(),
                "note": "brak skalibrowanego wyniku = brak wytrenowanego modelu dla tego zdarzenia (nie 0 %, nie 50 %)"}

    @app.post("/api/v1/quant/assessment")
    def quant_assess(body: dict = Body(...)):
        """Assessment of a given SetupCandidate (evaluation contract) - read-only, not logged, never an order."""
        from ..evaluation import contract as EK
        try:
            c = EK.SetupCandidate(**{k: v for k, v in (body.get("candidate") or body).items() if k in EK.SetupCandidate.__dataclass_fields__}).validate()
        except (TypeError, EK.ContractError) as exc:
            raise HTTPException(400, f"CANDIDATE_INVALID: {exc}") from None
        return _quant().assess(c.to_dict(), log_row=False)

    @app.get("/api/v1/quant/jobs")
    def quant_jobs():
        q = _quant()
        return {"items": list(q.jobs.values())[-20:], "ledger": q.ledger.counts(q.instrument())}

    @app.post("/api/v1/quant/jobs")
    def quant_train(body: dict = Body(default={})):
        """Explicit training of the meta-model from the Quant ledger (never activates; activation = separate call after validation)."""
        q = _quant()
        if str(body.get("kind") or "TRAIN_METAMODEL") != "TRAIN_METAMODEL":
            raise HTTPException(400, "JOB_KIND_UNKNOWN")
        if any(j["state"] == "RUNNING" for j in q.jobs.values()):
            raise HTTPException(409, "QUANT_JOB_ALREADY_RUNNING")
        return q.train(body.get("instrument") or None, body.get("task_hash") or None)

    @app.post("/api/v1/quant/mode")
    def quant_mode(body: dict = Body(...)):
        r = _quant().set_mode(str(body.get("mode") or ""), confirm=bool(body.get("confirm")), by="PANEL")
        if not r.get("ok"):
            raise HTTPException(409, r.get("reason"))
        return r

    # ------------------------------------------------------------------ 1.41 TabICLv2 confidence estimator
    @app.get("/api/v1/quant/tabicl")
    def quant_tabicl():
        return _quant().tabicl.status()

    @app.put("/api/v1/quant/estimator")
    def quant_estimator(body: dict = Body(...)):
        r = _quant().set_estimator(str(body.get("estimator") or ""), by="PANEL")
        if not r.get("ok"):
            raise HTTPException(400, r.get("reason"))
        rt.log.info("QUANT", "ESTIMATOR", f"Estymator confidence: {r['estimator']} (panel).")
        return r

    @app.post("/api/v1/quant/tabicl/reconstruct")
    def quant_tabicl_reconstruct(body: dict = Body(default={})):
        days = int(body.get("days") or 30)
        if not 3 <= days <= 365:
            raise HTTPException(400, "DAYS_OUT_OF_RANGE (3..365)")
        r = _quant().tabicl.run_reconstruction(_quant().instrument(), days=days)
        if not r.get("ok"):
            raise HTTPException(409, r.get("reason"))
        return r

    @app.post("/api/v1/quant/tabicl/install")
    def quant_tabicl_install():
        import sys as _sys
        from .. import paths as _P
        from ..tsfm.settings import default_weights_root as _dwr
        argv = [_sys.executable, str(_P.ROOT_DIR / "tools" / "tsfm_setup.py"), "--model", "tabicl", "--root", str(_P.ROOT_DIR), "--weights-root", str(_dwr())]
        return rt.tsfm._run_job_proc("install_tabicl", argv)

    # ---- 1.41 research modules (SDformerFlow, cellular feature graph, COA, BChimp, G7 SMC radar, exponential trend channel)
    def _research():
        r = getattr(rt, "research", None)
        if r is None:
            raise HTTPException(503, "moduły badawcze niedostępne (błąd startu – patrz logs/engine_console.log)")
        return r

    @app.get("/api/v1/research-modules")
    def research_status():
        return _research().status()

    @app.get("/api/v1/research-modules/settings")
    def research_settings():
        return _research().settings()

    @app.put("/api/v1/research-modules/settings")
    def research_settings_put(body: dict = Body(...)):
        try:
            return _research().update_settings(body, who="panel")
        except ValueError as exc:
            raise HTTPException(400, str(exc))

    @app.get("/api/v1/research-modules/features")
    def research_features(t: float | None = None):
        r = _research()
        inst = rt.sh.instrument()
        return {"instrument": inst, "asof": t, "features": r.features_for(inst, t), "snapshot": r.latest(inst)}

    @app.get("/api/v1/research-modules/feature-graph")
    def research_graph(target: str = "BPC10"):
        return _research().feature_graph(target)

    @app.get("/api/v1/research-modules/optimizer/jobs")
    def research_opt_jobs():
        return {"jobs": _research().optimizer_jobs(), "history": _research().param_history[-50:]}

    @app.post("/api/v1/research-modules/optimizer/run")
    def research_opt_run():
        r = _research()
        c = r.ensure_main_context()
        rows = r._objective_rows(c) if c else []
        if len(rows) < int(r.settings()["optimizer"]["min_mature_examples"]):
            raise HTTPException(409, f"za mało dojrzałych etykiet ({len(rows)}) – optymalizator czeka na dane")
        return r.optimise(c, rows)

    @app.post("/api/v1/research-modules/parameters/rollback")
    def research_rollback():
        return _research().rollback_parameters()

    @app.post("/api/v1/research-modules/sdformerflow/train")
    def research_sdf_train(body: dict = Body(default={})):
        r = _research()
        c = r.ensure_main_context()
        op = str(body.get("op") or "from_scratch")
        if op not in ("from_scratch", "fine_tune", "resume"):
            raise HTTPException(400, "op: from_scratch | fine_tune | resume")
        h1 = c.bars_fn("H1", 6000) if c else []
        ck = body.get("checkpoint") or (r.settings()["sdformer"].get("active_run") if op != "from_scratch" else None)
        ckp = str(r._sdf_dir() / ck) if ck else None
        res = r.start_training(c, h1, op=op, checkpoint=ckp, reason="panel (DIRECT_USER_REQUEST)")
        if not res.get("ok"):
            raise HTTPException(409, res.get("reason"))
        return res

    @app.post("/api/v1/research-modules/sdformerflow/cancel")
    def research_sdf_cancel():
        return _research().cancel_training()

    # ---- 1.41 market profiles + 9 baskets / 90 strategies (signals, plans, manual tickets - no orders)
    def _baskets():
        b = getattr(rt, "baskets", None)
        if b is None:
            raise HTTPException(503, "koszyki niedostępne (błąd startu – patrz logs/engine_console.log)")
        return b

    @app.get("/api/v1/baskets")
    def baskets_list(basket: str | None = None):
        b = _baskets()
        return {"status": b.status(), "baskets": b.basket_view(basket)}

    @app.get("/api/v1/baskets/catalog")
    def baskets_catalog():
        from ..baskets import catalog as _BC
        return _BC.manifest()

    @app.get("/api/v1/baskets/settings")
    def baskets_settings():
        return _baskets().settings()

    @app.put("/api/v1/baskets/settings")
    def baskets_settings_put(body: dict = Body(...)):
        try:
            return _baskets().update_settings(body)
        except ValueError as exc:
            raise HTTPException(400, str(exc))

    @app.get("/api/v1/baskets/signals")
    def baskets_signals(basket: str | None = None, limit: int = 100):
        return {"signals": _baskets().ledger.recent(basket, min(500, max(1, limit)))}

    @app.get("/api/v1/baskets/declared/{profile}")
    def baskets_declared(profile: str):
        return {"items": _baskets().ledger.declared(profile)}

    @app.post("/api/v1/baskets/declared/{profile}")
    def baskets_declare(profile: str, body: dict = Body(...)):
        if profile not in ("CRYPTO_FOMO_PERPS", "OTC_GOLD_POCKETOPTION"):
            raise HTTPException(400, "deklaracja ekspozycji tylko dla FOMO / OTC (FOREX: pozycje z terminala)")
        need = ("instrument", "side", "size") if profile == "CRYPTO_FOMO_PERPS" else ("dir", "stake", "r", "strike", "expiry", "opened_at")
        miss = [k for k in need if body.get(k) in (None, "")]
        if miss:
            raise HTTPException(400, f"brak pól: {miss}")
        return {"id": _baskets().ledger.declare(profile, str(body.get("kind") or ("PERP" if profile.startswith("CRYPTO") else "OTC_CONTRACT")), body)}

    @app.delete("/api/v1/baskets/declared/{item_id}")
    def baskets_undeclare(item_id: str):
        _baskets().ledger.close_declared(item_id)
        return {"ok": True}

    @app.get("/api/v1/baskets/otc")
    def baskets_otc():
        b = _baskets()
        return {"state": b.otc.state(), "meta": b.otc.meta()}

    @app.put("/api/v1/baskets/otc/meta")
    def baskets_otc_meta(body: dict = Body(...)):
        try:
            return _baskets().otc.set_meta(body)
        except ValueError as exc:
            raise HTTPException(400, str(exc))

    @app.post("/api/v1/baskets/otc/ticks")
    def baskets_otc_ticks(body: dict = Body(...)):
        rows = body.get("ticks") or []
        if not isinstance(rows, list) or not rows:
            raise HTTPException(400, "ticks: [{t, price}]")
        return {"accepted": _baskets().otc.push_ticks(rows, str(body.get("source") or "CONNECTOR"))}

    @app.post("/api/v1/baskets/otc/payoff")
    def baskets_otc_payoff(body: dict = Body(...)):
        from ..baskets import payoff as _PO
        return _PO.table(body.get("legs") or [], float(body.get("extra_cost") or 0.0))

    @app.post("/api/v1/quant/models/activate")
    def quant_activate(body: dict = Body(...)):
        from ..quant import metamodel as QM
        q = _quant()
        try:
            p = QM.activate(body.get("instrument") or q.instrument(), str(body.get("task_hash") or ""), str(body.get("version") or ""))
        except (QM.MetaError, OSError, KeyError, ValueError) as exc:
            raise HTTPException(409, f"ACTIVATION_REFUSED: {exc}") from None
        return {"ok": True, "pointer": p}

    @app.post("/api/v1/quant/models/rollback")
    def quant_rollback(body: dict = Body(...)):
        from ..quant import metamodel as QM
        q = _quant()
        return {"ok": True, "pointer": QM.rollback(body.get("instrument") or q.instrument(), str(body.get("task_hash") or ""))}

    @app.get("/api/v1/quant/inventory")
    def quant_inventory():
        from ..quant import inventory as QI
        q = _quant()
        inv = QI.build(rt, q.instrument())
        return {"coverage": inv["coverage"], "entries": inv["entries"], "generated_at": inv["generated_at"]}

    # ---------------------------------------------------------------- PMW-SVP-1 Session Volume Profile + zones (1.33) - analytical
    def _svp(fn, *a, **k):
        try:
            return fn(*a, **k)
        except KeyError as exc:
            raise HTTPException(404, str(exc).strip("'")) from None
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from None

    @app.get("/api/v1/svp/status")
    def svp_status():
        return rt.svp.status()

    @app.get("/api/v1/svp/profiles")
    def svp_profiles():
        return {"items": rt.svp.profiles()}

    @app.post("/api/v1/svp/profiles")
    def svp_profile_create(body: dict = Body(...)):
        return _svp(rt.svp.create_profile, body)

    @app.patch("/api/v1/svp/profiles/{pid}")
    def svp_profile_update(pid: str, body: dict = Body(...)):
        return _svp(rt.svp.update_profile, pid, body)

    @app.delete("/api/v1/svp/profiles/{pid}")
    def svp_profile_delete(pid: str):
        if not rt.svp.delete_profile(pid):
            raise HTTPException(404, "PROFILE_NOT_FOUND")
        return {"ok": True}

    @app.post("/api/v1/svp/profiles/{pid}/copy-settings")
    def svp_profile_copy(pid: str, body: dict = Body(...)):
        return _svp(rt.svp.copy_settings, str(body.get("from") or ""), pid)

    @app.get("/api/v1/svp/profiles/{pid}/compute")
    def svp_profile_compute(pid: str):
        return _svp(rt.svp.compute, pid)

    @app.post("/api/v1/svp/profiles/{pid}/freeze")
    def svp_profile_freeze(pid: str):
        return _svp(rt.svp.freeze, pid)

    @app.post("/api/v1/svp/profiles/{pid}/live")
    def svp_profile_live(pid: str, body: dict = Body(...)):
        return _svp(rt.svp.set_live, pid, bool(body.get("on")))

    @app.post("/api/v1/svp/profiles/{pid}/ai-live")
    def svp_profile_ai_live(pid: str, body: dict = Body(...)):
        return _svp(rt.svp.set_ai_live, pid, bool(body.get("on")))

    @app.post("/api/v1/svp/profiles/{pid}/zones-now")
    def svp_zones_now(pid: str):
        return _svp(rt.svp.algo_now, pid)

    @app.post("/api/v1/svp/profiles/{pid}/ai-propose")
    async def svp_ai_propose(pid: str):
        if rt.svp.profile(pid) is None:
            raise HTTPException(404, "PROFILE_NOT_FOUND")
        return await rt.svp.ai_propose(pid)

    @app.get("/api/v1/svp/visible")
    def svp_visible(tf: str = Query("M5"), t0: str = Query(...), t1: str = Query(...), bin_ticks: int = Query(50, ge=1, le=100000),
                    va_pct: float = Query(0.70, gt=0.3, lt=1.0)):
        if tf not in TIMEFRAMES:
            raise HTTPException(400, "TF_INVALID")
        return _svp(rt.svp.visible, tf, t0, t1, bin_ticks=bin_ticks, va_pct=va_pct)

    @app.get("/api/v1/svp/zones")
    def svp_zones(source: str | None = Query(None), profile_id: str | None = Query(None), as_of: str | None = Query(None)):
        if source and source not in ("MANUAL", "ALGORITHM", "AI"):
            raise HTTPException(400, "SOURCE_INVALID")
        from ..svp import engine as _SE
        return {"items": rt.svp.zones(source=source, profile_id=profile_id, as_of=_SE._ts(as_of) if as_of else None)}

    @app.post("/api/v1/svp/zones")
    def svp_zone_create(body: dict = Body(...)):
        return _svp(rt.svp.create_manual, body)

    @app.patch("/api/v1/svp/zones/{zid}")
    def svp_zone_edit(zid: str, body: dict = Body(...)):
        return _svp(rt.svp.edit_zone, zid, body)

    @app.delete("/api/v1/svp/zones/{zid}")
    def svp_zone_delete(zid: str):
        if not rt.svp.delete_zone(zid):
            raise HTTPException(404, "ZONE_NOT_FOUND")
        return {"ok": True}

    @app.get("/api/v1/svp/zones/{zid}/history")
    def svp_zone_history(zid: str):
        return {"items": rt.svp.zone_history(zid)}

    @app.post("/api/v1/svp/clear-auto")
    def svp_clear_auto(body: dict = Body(default={})):
        return {"deactivated": rt.svp.clear_auto(body.get("profile_id"))}

    @app.get("/api/v1/svp/ai-jobs")
    def svp_ai_jobs(limit: int = Query(50, ge=1, le=500)):
        return {"items": rt.svp.ai_jobs(limit)}

    @app.get("/api/v1/zones/status")
    def zones_status():
        return rt.zones.status()

    @app.get("/api/v1/zones/events")
    def zones_events(limit: int = Query(100, ge=1, le=1000)):
        return {"items": rt.zones.events(limit)}

    @app.get("/api/v1/zones/profiles")
    def zones_profiles():
        zm = rt.zones.current_or_refresh()
        if zm is None:
            return {"status": "NO_MAP", "reason": rt.zones.state.get("last_error")}
        return {"profiles": zm.get("profiles"), "context": zm.get("context"), "volume_source": zm.get("volume_source"), "as_of": zm.get("as_of")}

    @app.get("/api/v1/zones/context")
    def zones_context(direction: str = Query(...), entry: float = Query(...), stop: float | None = Query(None), cost: float = Query(0.0)):
        if direction not in ("LONG", "SHORT"):
            raise HTTPException(400, "INVALID_DIRECTION")
        return rt.zones.context_for(direction=direction, entry=entry, stop=stop, cost_price=cost) or {"status": "NO_MAP"}

    @app.get("/api/v1/eval/status")
    def eval_status():
        return rt.evaluation.status()

    @app.get("/api/v1/eval/assessments")
    def eval_assessments(engine: str | None = Query(None), limit: int = Query(50, ge=1, le=500)):
        from ..evaluation.contract import ENGINES
        if engine is not None and engine not in ENGINES:
            raise HTTPException(400, "UNKNOWN_ENGINE")
        return {"items": rt.evaluation.assessments(engine, limit), "mode": "SHADOW"}

    @app.get("/api/v1/eval/report")
    def eval_report():
        return rt.evaluation.report()

    @app.get("/api/v1/eval/exposure")
    def eval_exposure():
        return rt.evaluation.exposure()

    @app.get("/api/v1/mm/live")
    def mm_live(instrument: str = Query("XAUUSD")):
        return rt.mm.live(_mm_inst(instrument))

    @app.get("/api/v1/mm/job")
    def mm_job(instrument: str = Query("XAUUSD"), job: str = Query(...)):
        from ..mm import inventory as mi
        from ..mm.orchestrator import GRAPH
        if job not in {g[0] for g in GRAPH}:
            raise HTTPException(400, "UNKNOWN_JOB")
        rep = mi.latest_report(_mm_inst(instrument))
        if not rep or not rep.get("run_dir"):
            return {"status": "NOT_RUN", "reason": "brak przebiegu master models dla instrumentu (trening: zadanie master_models)"}
        p = Path(rep["run_dir"]) / f"{job}.json"
        if not p.exists():
            return {"status": "NOT_RUN", "reason": f"zadanie {job} nie zostało wykonane w ostatnim przebiegu"}
        return {"status": "OK", "run_id": rep.get("run_id"), "data_kind": (rep.get("snapshot") or {}).get("data_kind"),
                "result": json.loads(p.read_text(encoding="utf-8"))}

    @app.get("/api/v1/mm/ledger")
    def mm_ledger(instrument: str = Query("XAUUSD"), model: str = Query("gpr_logret:LIVE"), limit: int = 200):
        led = rt.mm._ledger(_mm_inst(instrument))
        rows = led.rows(model, limit=min(max(limit, 1), 2000))
        return {"summary": led.summary(), "rows": rows[-min(max(limit, 1), 2000):]}

    @app.post("/api/v1/mm/rollback")
    def mm_rollback(body: dict = Body(...)):
        from ..mm import artifacts as ma
        try:
            return {"ok": True, "pointer": ma.rollback(_mm_inst(body.get("instrument", "")), str(body.get("model", "")))}
        except ma.ArtifactError as exc:
            return {"ok": False, "reason": str(exc)}

    @app.get("/api/v1/training/readiness")
    def training_readiness(instrument: str = Query(...)):
        from ..training import panel as tp
        if instrument not in ("XAUUSD", "BTC"):
            raise HTTPException(400, "UNKNOWN_INSTRUMENT")
        return tp.readiness(rt, instrument)

    @app.get("/api/v1/training/runs")
    def training_runs(limit: int = Query(50, ge=1, le=500)):
        from ..training import panel as tp
        return {"items": tp.runs(limit)}

    def _rid_ok(rid: str) -> str:
        from ..training import core as tc
        if not re.fullmatch(r"[A-Za-z0-9_\-]{6,80}", rid) or not (tc.runs_dir() / rid / "state.json").exists():
            raise HTTPException(404)
        return rid

    @app.get("/api/v1/training/runs/{rid}")
    def training_run(rid: str):
        from ..training import panel as tp
        return tp.run_detail(_rid_ok(rid))

    @app.get("/api/v1/training/runs/{rid}/log")
    def training_run_log(rid: str, task: str = Query(...), nbytes: int = Query(20000, ge=1000, le=500000)):
        from ..training import panel as tp
        try:
            return tp.task_log(_rid_ok(rid), task, nbytes)
        except StopIteration:
            raise HTTPException(404, "UNKNOWN_TASK")

    @app.get("/api/v1/training/runs/{rid}/report")
    def training_run_report(rid: str):
        from ..training import core as tc
        p = tc.runs_dir() / _rid_ok(rid) / "report.html"
        if not p.exists():
            raise HTTPException(404, "REPORT_NOT_READY")
        return FileResponse(p, media_type="text/html")

    @app.get("/api/v1/training/compare")
    def training_compare(a: str = Query(...), b: str = Query(...)):
        from ..training import panel as tp
        return tp.compare(_rid_ok(a), _rid_ok(b))

    @app.post("/api/v1/training/resume")
    def training_resume(body: dict = Body(default={})):
        import subprocess
        from ..training import core as tc
        from ..training import panel as tp
        h = tp.lock_holder()
        if h and h.get("alive"):
            return {"started": False, "reason": f"TRAINING_ALREADY_RUNNING:{h.get('run_id')}"}
        rid = body.get("run_id") or tc.Run.latest()
        if not rid:
            return {"started": False, "reason": "NO_RUN"}
        _rid_ok(rid)
        log = open(tc.training_dir() / "panel_start.log", "a", encoding="utf-8")
        kw = {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)} if os.name == "nt" else {"start_new_session": True}
        subprocess.Popen([sys.executable, "-m", "masterquo", "training", "resume", rid], cwd=str(paths.ROOT_DIR / "backend"),
                         env=dict(os.environ, MQ_NO_BROWSER="1"), stdout=log, stderr=subprocess.STDOUT, **kw)
        return {"started": True, "run_id": rid}

    @app.post("/api/v1/training/export")
    def training_export(body: dict = Body(...)):
        from ..training import panel as tp
        inst = body.get("instrument")
        if inst not in ("XAUUSD", "BTC"):
            raise HTTPException(400, "UNKNOWN_INSTRUMENT")
        try:
            r = tp.export_package(inst, str(body.get("scope") or "all"), body.get("run_id"))
        except ValueError as exc:
            raise HTTPException(400, str(exc))
        r["download"] = f"/api/v1/training/exports/{r['file']}"
        rt.log.info("TRAINING", "EXPORT", f"Pakiet treningowy {r['file']} ({r['files']} plików, braki: {len(r['missing'])})")
        return r

    @app.get("/api/v1/training/exports/{name}")
    def training_export_file(name: str):
        from ..training import panel as tp
        if not re.fullmatch(r"PMW_TRENING_[A-Za-z0-9_\-]+\.zip", name):
            raise HTTPException(404)
        p = tp.exports_dir() / name
        if not p.exists():
            raise HTTPException(404)
        return FileResponse(p, media_type="application/zip", filename=name)

    @app.post("/api/v1/training/import")
    async def training_import(request: Request):
        from ..training import panel as tp
        data = await request.body()
        if not data or len(data) > 512 * 2**20:
            raise HTTPException(400, "EMPTY_OR_TOO_LARGE")
        try:
            return tp.import_package(data)
        except ValueError as exc:
            raise HTTPException(400, str(exc))

    @app.post("/api/v1/training/sh/promote")
    def training_sh_promote(body: dict = Body(...)):
        from ..sh import tpmodel as TM
        inst, strat, rid = body.get("instrument"), body.get("strategy"), body.get("run_id")
        if inst not in ("XAUUSD", "BTC") or strat not in ("SCALPING", "HEDGING") or not rid:
            raise HTTPException(400, "BAD_REQUEST")
        try:
            r = TM.promote(inst, strat, str(rid))
        except ValueError as exc:
            return {"ok": False, "reason": str(exc)}
        rt.log.warn("TRAINING", "SH_PROMOTE", f"sh_tp_model {inst}/{strat}: aktywny {r['active']}")
        return {"ok": True, **r}

    @app.post("/api/v1/training/start")
    def training_start(body: dict):
        """Starts `masterquo training run` as a separate process (never inside the bot process; no orders, execution mode untouched)."""
        import subprocess
        from ..training import core as tc
        insts = ",".join(i for i in ("XAUUSD", "BTC") if i in (body.get("instruments") or []))
        if not insts:
            raise HTTPException(400, "NO_INSTRUMENT")
        prof = body.get("profile") or "PELNY_TRENING"
        if prof not in tc.profiles():
            raise HTTPException(400, "BAD_PROFILE")
        cmd = [sys.executable, "-m", "masterquo", "training", "run", "--instruments", insts, "--profile", prof, "--origin", "panel"]
        if body.get("tasks"):                                  # one model / a subset (export, QC, activation and bot always run)
            from ..training.runner import TASKS
            sel = [t for t in body["tasks"] if t in {k for k, _ in TASKS}]
            if not sel:
                raise HTTPException(400, "BAD_TASKS")
            cmd += ["--tasks", ",".join(sel)]
        for k, flag in (("months", "--months"), ("symbol_xauusd", "--symbol-xauusd"), ("symbol_btc", "--symbol-btc"),
                        ("commission_xauusd", "--commission-xauusd"), ("commission_btc", "--commission-btc")):
            if body.get(k) not in (None, ""):
                cmd += [flag, str(body[k])]
        for k, flag in (("dataset_xauusd", "--dataset-xauusd"), ("dataset_btc", "--dataset-btc")):   # export made in the panel
            if body.get(k):
                d = Path(str(body[k])).resolve()
                if paths.data_dir().resolve() not in d.parents:
                    raise HTTPException(400, "BAD_DIR")
                cmd += [flag, str(d)]
        if rt.demo:
            cmd.append("--demo")
        held = None
        try:
            import json as _j
            cur = _j.loads(tc.lock_path().read_text(encoding="utf-8"))
            held = cur.get("run_id") if tc._pid_alive(int(cur.get("pid", 0))) else None
        except (OSError, ValueError):
            pass
        if held:
            return {"started": False, "reason": f"TRAINING_ALREADY_RUNNING:{held}"}
        log = open(tc.training_dir() / "panel_start.log", "a", encoding="utf-8")
        kw = {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)} if os.name == "nt" else {"start_new_session": True}
        subprocess.Popen(cmd, cwd=str(paths.ROOT_DIR / "backend"), env=dict(os.environ, MQ_NO_BROWSER="1"), stdout=log, stderr=subprocess.STDOUT, **kw)
        return {"started": True}

    # ------------------------------------------------------------ 1.42.10 Centrum Treningowe Pepe (PMW-TCP-1): jeden widok + kolejka 1 naraz
    @app.get("/api/v1/pepe-training")
    def pepe_training_status():
        return rt.pepe_training.status()

    @app.post("/api/v1/pepe-training/train")
    def pepe_training_train(body: dict = Body(default={})):
        units = body.get("units")
        if units != "ALL" and not (isinstance(units, list) and units):
            raise HTTPException(400, "UNITS: lista identyfikatorów albo \"ALL\"")
        try:
            return rt.pepe_training.enqueue(units, body.get("instruments"))
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc

    @app.put("/api/v1/pepe-training/settings")
    def pepe_training_settings(body: dict = Body(default={})):
        try:
            return rt.pepe_training.set_settings(body)
        except ValueError as exc:
            raise HTTPException(400, str(exc)[:200])

    @app.post("/api/v1/pepe-training/cancel")
    def pepe_training_cancel():
        return rt.pepe_training.cancel()

    @app.post("/api/v1/pepe-training/remove")
    def pepe_training_remove(body: dict = Body(default={})):
        return rt.pepe_training.remove(str(body.get("id") or ""))

    @app.get("/api/v1/pepe-training/log")
    def pepe_training_log(lines: int = Query(80, ge=10, le=400)):
        from ..training import core as tc
        out = {}
        for name, f in (("center", tc.training_dir() / "pepe_center.log"),):
            try:
                out[name] = f.read_text(encoding="utf-8", errors="replace").splitlines()[-lines:]
            except OSError:
                out[name] = []
        return out

    # ------------------------------------------------------------ 1.25 export of MT5 history for training (own process, read only)
    def _default_symbol(inst: str):
        c = rt.cfg.get()
        m = c.assets.mappings.get(inst)
        return m.broker_symbol if m and m.broker_symbol else (c.mt5.symbol if inst == "XAUUSD" else None)

    @app.post("/api/v1/export/start")
    def export_start(body: dict):
        from ..training import export_job as EJ
        try:
            return EJ.start(body, demo=rt.demo, default_symbol=_default_symbol)
        except ValueError as exc:
            raise HTTPException(400, str(exc))

    @app.get("/api/v1/export/status")
    def export_status():
        from ..training import export_job as EJ
        return EJ.status()

    @app.post("/api/v1/export/cancel")
    def export_cancel():
        from ..training import export_job as EJ
        return EJ.cancel()

    @app.get("/api/v1/export/datasets")
    def export_datasets(instrument: str = Query(...)):
        from ..training import export_job as EJ
        if instrument not in ("XAUUSD", "BTC"):
            raise HTTPException(400, "UNKNOWN_INSTRUMENT")
        return {"instrument": instrument, "datasets": EJ.datasets(instrument), "default_symbol": _default_symbol(instrument)}

    @app.get("/api/v1/export/readiness")
    def export_readiness(dataset: str = Query(...)):
        from ..training import requirements as RQ
        d = Path(dataset).resolve()
        if paths.data_dir().resolve() not in d.parents:
            raise HTTPException(400, "BAD_DIR")
        return RQ.check_dataset(d)

    # ------------------------------------------------------------ 1.25 Monte Carlo of price paths (own thread, closed M1 bars of the bridge)
    @app.get("/api/v1/montecarlo/status")
    def montecarlo_status():
        return rt.montecarlo.status()

    @app.get("/api/v1/montecarlo/validations/{run_id}/report")
    def montecarlo_validation_report(run_id: str):
        """1.42: read-only - the stored report.json of one Monte Carlo validation run (reliability / Brier for the MODELS & BACKTEST
        screen). Only a run listed in the instrument's registry is served; nothing is computed or changed."""
        import json as _json
        import re as _re
        from ..montecarlo import validate as _MV
        if not _re.fullmatch(r"MC-[0-9A-Za-z\-]{8,64}", run_id):
            raise HTTPException(400, "INVALID_RUN_ID")
        inst, _ = rt.montecarlo._ctx()
        d = _MV.root(inst)
        try:
            reg = _json.loads((d / "registry.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            reg = {}
        if run_id not in (reg.get("runs") or {}):
            raise HTTPException(404, "NOT_RUN")
        f = d / "runs" / run_id / "report.json"
        try:
            return {"run_id": run_id, "instrument": inst, "summary": reg["runs"][run_id], "report": _json.loads(f.read_text(encoding="utf-8"))}
        except (OSError, ValueError):
            raise HTTPException(404, "REPORT_FILE_MISSING")

    @app.get("/api/v1/montecarlo/scenarios")
    def montecarlo_scenarios(horizon: int = Query(60, ge=5, le=240)):
        """P(price reaches +X / -X within the horizon) for X = 2.5 / 3 / 5 / 7.5 / 10 (price move, not account profit)."""
        return rt.montecarlo.compute(None, horizon=horizon)            # sync endpoint: FastAPI thread pool, computation in the MC thread

    @app.post("/api/v1/montecarlo/run")
    def montecarlo_run(body: dict):
        side = str(body.get("side") or "").upper()
        if side not in ("BUY", "SELL"):
            raise HTTPException(400, "BAD_SIDE")
        try:
            sl = float(body["sl_distance"])
            tps = [float(x) for x in (body.get("tp_distances") or [])]
            horizon = int(body.get("horizon") or 60)
            n_paths = int(body.get("n_paths") or 2000)
            entry = float(body["entry"]) if body.get("entry") not in (None, "") else None
        except (KeyError, TypeError, ValueError):
            raise HTTPException(400, "BAD_PLAN")
        if not (0 < sl <= 1e6 and tps and len(tps) <= 8 and all(0 < x <= 1e6 for x in tps) and 5 <= horizon <= 240 and 200 <= n_paths <= 20000):
            raise HTTPException(400, "BAD_PLAN")
        variant = body.get("variant")
        if variant not in (None, "IID", "BLOCK", "REGIME"):
            raise HTTPException(400, "BAD_VARIANT")
        plan = rt.montecarlo.plan_for(side, sl, tps, entry=entry, horizon=horizon)
        if plan is None:
            return {"status": "NO_QUOTE", "reason": "brak aktualnego notowania Bid/Ask – podaj cenę wejścia albo połącz MT5"}
        return rt.montecarlo.compute([plan], horizon=horizon, variant=variant, n_paths=n_paths)

    @app.post("/api/v1/training/cancel")
    def training_cancel():
        from ..training import core as tc
        rid = tc.Run.latest()
        if not rid:
            return {"ok": False, "reason": "NO_RUN"}
        (tc.runs_dir() / rid / "CANCEL").write_text(tc.now(), encoding="utf-8")
        return {"ok": True, "run_id": rid}

    @app.get("/api/v1/training/active")
    def training_active(instrument: str = Query(...)):
        import json as _j
        import mq_instruments as mi
        from ..lab.protocol import read_pointer
        from ..ml.router import ml_store
        if instrument not in mi.profiles():
            raise HTTPException(400, "UNKNOWN_INSTRUMENT")
        out = {}
        for fam in ("forecast", "scalp"):
            try:
                reg = _j.loads((mi.root(fam, instrument) / "registry.json").read_text(encoding="utf-8"))
                e = (reg.get("runs") or {}).get(reg.get("active") or "", {})
                out[fam] = {"active": reg.get("active"), "status": e.get("overall_status") or e.get("task_a_status"), "history": (reg.get("history") or [])[-3:]}
            except (OSError, ValueError):
                out[fam] = {"active": None}
        if instrument == rt.ml.inst:
            out["ml"] = {"active": rt.ml.registry.champion_id}
        else:
            db, root = ml_store(instrument, rt.db)
            row = db.one("SELECT model_id FROM ml_models WHERE status='CHAMPION'")
            out["ml"] = {"active": row["model_id"] if row else None}
        ptr = read_pointer(paths.data_dir() / "lab", instrument)
        out["lab"] = {"pinned": ptr["active"], "models": [{k: m.get(k) for k in ("model_id", "family", "role", "verdict")} for m in rt.lab.trainer.models(instrument)][:20]}
        return {"instrument": instrument, "families": out}

    @app.post("/api/v1/training/rollback")
    def training_rollback(body: dict):
        import subprocess
        inst, fam = body.get("instrument"), str(body.get("family") or "")
        if inst not in ("XAUUSD", "BTC") or not (fam in ("forecast", "scalp", "ml") or fam.startswith(("lab:", "sh:"))):
            raise HTTPException(400, "BAD_REQUEST")
        if fam.startswith("sh:"):
            from ..sh import tpmodel as TM
            if fam[3:] not in ("SCALPING", "HEDGING"):
                raise HTTPException(400, "BAD_REQUEST")
            try:
                return {"ok": True, "result": TM.rollback(inst, fam[3:])}
            except ValueError as exc:
                return {"ok": False, "reason": str(exc)}
        if fam == "ml" and inst == rt.ml.inst:
            try:
                return {"ok": True, "result": rt.ml.rollback()}
            except ValueError as exc:
                return {"ok": False, "reason": str(exc)}
        r = subprocess.run([sys.executable, "-m", "masterquo", "training", "rollback", "--instrument", inst, "--family", fam],
                           cwd=str(paths.ROOT_DIR / "backend"), capture_output=True, text=True, timeout=300)
        rt.forecast.reload()
        return {"ok": r.returncode == 0, "output": (r.stdout + r.stderr)[-800:]}

    # ------------------------------------------------------------ PMW-UPD-06 Session Sweep Boxes + Liquidation Heatmap
    @app.get("/api/v1/liquidity/sessions")
    def liq_sessions(tf: str = Query("M5"), profile: str | None = Query(None), days: int = Query(2, ge=0, le=5)):
        from ..analytics import session_engine as se
        if profile is not None and profile not in se.PROFILES:
            raise HTTPException(400, "UNKNOWN_PROFILE")
        if tf not in ("M1", "M5", "M15", "M30", "H1"):
            raise HTTPException(400, "UNKNOWN_TF")
        cfg = rt.cfg.get()
        base = cfg.liquidity.sessions_base_tf                          # geometry from ONE base TF; the chart TF only changes presentation
        bars = [b for b in rt.bridge.bars(base, 3000 if base == "M1" else 1000, include_forming=False) if b.get("open_utc")]
        r = rt.liquidity.sessions(bars, 60 if base == "M1" else 300, cfg.assets.active, None, profile, days)
        return dict(r, asset=cfg.assets.active, view_tf=tf, base_tf=base, session_epoch=str(getattr(rt.bridge, "session_epoch", None)),
                    history_from=bars[0]["open_utc"] if bars else None)

    @app.get("/api/v1/liquidity/heatmap")
    def liq_heatmap(asset: str | None = Query(None), as_of: str | None = Query(None), max_cells: int = Query(20000, ge=0, le=100000)):
        return rt.liquidity.heatmap_public(_asset(asset), as_of, max_cells)

    @app.get("/api/v1/liquidity/context")
    def liq_context(setup_side: str | None = Query(None)):
        from ..analytics import liquidity_context as lc
        cfg = rt.cfg.get()
        a = cfg.assets.active
        base = cfg.liquidity.sessions_base_tf
        bars = [b for b in rt.bridge.bars(base, 3000 if base == "M1" else 1000, include_forming=False) if b.get("open_utc")]
        sess = rt.liquidity.sessions(bars, 60 if base == "M1" else 300, a)
        hm = rt.liquidity.heatmap_public(a, None, 0)
        hm.pop("grid", None)
        m5 = [b for b in rt.bridge.bars("M5", 60, include_forming=False) if b.get("open_utc")]
        a5 = (sum(x["h"] - x["l"] for x in m5[-14:]) / 14) if len(m5) >= 14 else None
        return dict(lc.evaluate(boxes=sess["boxes"], heatmap=hm, price=m5[-1]["c"] if m5 else None, atr_m5=a5,
                                setup={"side": setup_side} if setup_side in ("BUY", "SELL") else None), asset=a, rules=lc.RULES)

    @app.put("/api/v1/liquidity/source")
    def liq_source(body: dict = Body(default={})):
        a = _asset(body.get("asset"))
        cur = rt.cfg.get().liquidity.sources.get(a)
        patch = {k: body[k] for k in ("enabled", "variant", "source_symbol", "exchange", "range", "contract_type") if k in body}
        if "mapping" in body and body["mapping"] != "UNMAPPED":
            raise HTTPException(400, "MAPPING_REQUIRES_VALIDATED_BASIS_ADAPTER")
        try:
            merged = dict(cur.model_dump() if cur else {}, **patch)
            rt.cfg.update({"liquidity": {"sources": {a: merged}}})
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(400, str(exc)[:300]) from None
        return {"ok": True, "source": rt.cfg.get().liquidity.sources[a].model_dump()}

    @app.put("/api/v1/liquidity/key")
    def liq_key(body: dict = Body(default={})):
        rt.secrets.set("COINGLASS_API_KEY", (body.get("key") or "").strip() or None)
        return {"ok": True, "key_status": rt.secrets.source("COINGLASS_API_KEY")}          # the key itself is never returned

    @app.post("/api/v1/liquidity/poll")
    def liq_poll():
        import time as _t
        return {"polled": rt.liquidity.poll_once(_t.monotonic() + 10**9), "imported": rt.liquidity.scan_inbox()}

    # ------------------------------------------------------------ PMW-UPD-05 Multi TimeFrame Scalping Dashboard
    @app.get("/api/v1/scalp/dashboard")
    def mtf_dashboard(asset: str | None = Query(None), snapshot_id: str | None = Query(None)):
        a = _asset(asset) if asset else rt.cfg.get().assets.active
        if a != rt.scalp.inst:
            return {"asset": a, "status": "ASSET_NOT_ACTIVE", "snapshot": None, "health": None}
        import mq_instruments
        if a not in mq_instruments.profiles():
            return {"asset": a, "status": "UNSUPPORTED_STRATEGY_PROFILE", "snapshot": None, "health": rt.mtf.health}
        snap = rt.mtf.get(snapshot_id)
        if snapshot_id and snap is None:
            return {"asset": a, "status": "ARCHIVE_SNAPSHOT_UNAVAILABLE", "snapshot_id": snapshot_id, "snapshot": None, "health": rt.mtf.health}
        if snap is not None and snap.get("asset") != a:
            snap = None
        return {"asset": a, "status": "OK" if snap else "NO_SNAPSHOT", "snapshot": snap, "health": rt.mtf.health or rt.mtf.heartbeat(),
                "scalp_status": rt.scalp.state.get("status"), "scalp_reason": rt.scalp.state.get("reason")}

    @app.get("/api/v1/scalp/dashboard/chart")
    def mtf_chart(tf: str = Query(...), snapshot_id: str = Query(...), bars: int = Query(400, ge=50, le=600)):
        r = rt.mtf.chart(tf, snapshot_id, bars)
        if r.get("status") == "SNAPSHOT_EXPIRED":
            return JSONResponse(r, status_code=410)
        return r

    @app.get("/api/v1/scalp/dashboard/snapshots")
    def mtf_snapshots(setup_id: str | None = Query(None), cursor: str | None = Query(None), limit: int = Query(50, ge=1, le=200)):
        rows = rt.mtf.snapshots(setup_id, limit, cursor)
        return {"asset": rt.scalp.inst, "rows": rows, "next_cursor": rows[-1]["computed_at"] if len(rows) == limit else None}

    @app.get("/api/v1/scalp/dashboard/snapshots/{sid}")
    def mtf_snapshot(sid: str):
        snap = rt.mtf.get(sid)
        if snap is None:
            raise HTTPException(404, "ARCHIVE_SNAPSHOT_UNAVAILABLE")
        return snap

    # ------------------------------------------------------------ PMW-UPD-04 Neural Scalp System (CAUSAL_MTF_TCN_V1)
    nss_jobs: dict = {}

    def _nss_job(args: list[str]):
        import subprocess
        from ..training import core as tc
        if any(pr.poll() is None for pr in nss_jobs.values()):
            return {"started": False, "reason": "JOB_RUNNING – jedno ciężkie zadanie NSS naraz"}
        jid = "NSSJ-" + __import__("uuid").uuid4().hex[:8]
        log = open(tc.training_dir() / f"nss_{jid}.log", "a", encoding="utf-8")
        kw = {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)} if os.name == "nt" else {"start_new_session": True}
        nss_jobs[jid] = subprocess.Popen([sys.executable, "-m", "masterquo", "neural-scalp", *args], cwd=str(paths.ROOT_DIR / "backend"), stdout=log,
                                         stderr=subprocess.STDOUT, **kw)
        return {"started": True, "job_id": jid, "args": args}

    @app.get("/api/v1/lab/neural")
    def nss_state(asset: str | None = Query(None)):
        return rt.nss.public(_asset(asset) if asset else rt.cfg.get().assets.active)

    @app.get("/api/v1/lab/neural/history")
    def nss_history(limit: int = Query(50, ge=1, le=500)):
        return {"asset": rt.nss.inst, "rows": rt.nss.history(limit)}

    @app.get("/api/v1/lab/neural/report")
    def nss_report(asset: str | None = Query(None), run_id: str | None = Query(None)):
        from ..lab import nss
        a = _asset(asset) if asset else rt.cfg.get().assets.active
        p = nss.root(a) / "registry.json"
        reg = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {"runs": {}}
        rid = run_id or (sorted(reg["runs"])[-1] if reg["runs"] else None)
        if not rid or rid not in reg["runs"]:
            return {"asset": a, "status": "NO_REPORT"}
        rep = json.loads((Path(reg["runs"][rid]["run_dir"]) / "report.json").read_text(encoding="utf-8"))
        return {"asset": a, "run_id": rid, "report": rep}

    @app.get("/api/v1/lab/neural/jobs")
    def nss_jobs_list():
        return {"jobs": [{"job_id": k, "pid": v.pid, "running": v.poll() is None, "returncode": v.poll()} for k, v in nss_jobs.items()]}

    @app.post("/api/v1/lab/neural/prepare")
    def nss_prepare(body: dict = Body(default={})):
        return _nss_job(["prepare", "--asset", _asset(body.get("asset") or rt.cfg.get().assets.active)])

    @app.post("/api/v1/lab/neural/doctor")
    def nss_doctor(body: dict = Body(default={})):
        import subprocess
        a = _asset(body.get("asset") or rt.cfg.get().assets.active)
        r = subprocess.run([sys.executable, "-m", "masterquo", "neural-scalp", "doctor", "--asset", a], cwd=str(paths.ROOT_DIR / "backend"),
                           capture_output=True, text=True, timeout=120)
        try:
            return json.loads(r.stdout)
        except ValueError:
            return {"status": "ERROR", "output": (r.stdout + r.stderr)[-2000:]}

    @app.post("/api/v1/lab/neural/train")
    def nss_train(body: dict = Body(default={})):
        return _nss_job(["train", "--asset", _asset(body.get("asset") or rt.cfg.get().assets.active), "--activate", "none"])

    @app.post("/api/v1/lab/neural/cancel")
    def nss_cancel(body: dict = Body(default={})):
        pr = nss_jobs.get(str(body.get("job_id")))
        if pr is None:
            raise HTTPException(404, "UNKNOWN_JOB")
        if pr.poll() is None:
            pr.terminate()
        return {"ok": True, "job_id": body.get("job_id"), "note": "anulowanie nie podmienia wybranego modelu"}

    @app.post("/api/v1/lab/neural/select")
    def nss_select(body: dict = Body(default={})):
        from ..lab import nss
        try:
            return {"ok": True, "selected": nss.select(_asset(body.get("asset") or rt.cfg.get().assets.active), str(body.get("run_id")), str(body.get("role") or "OBSERVE"))}
        except (ValueError, OSError, KeyError) as exc:
            return {"ok": False, "reason": str(exc)}

    @app.post("/api/v1/lab/neural/rollback")
    def nss_rollback(body: dict = Body(default={})):
        from ..lab import nss
        try:
            return {"ok": True, "selected": nss.rollback(_asset(body.get("asset") or rt.cfg.get().assets.active))}
        except (ValueError, OSError) as exc:
            return {"ok": False, "reason": str(exc)}

    # ------------------------------------------------------------ PMW-UPD-03 SCALP_NET_PROFIT_MARKET_V1
    @app.get("/api/v1/ml/scalp")
    def ml_scalp_status(asset: str | None = Query(None)):
        inst = asset or rt.cfg.get().assets.active
        if inst != rt.ml.inst:
            from ..ml.router import ml_store
            from ..ml.service import MLService
            db, root = ml_store(inst, rt.db)
            return MLService(rt.cfg, db, rt.bridge, rt.bus, rt.log, root=root, instrument=inst).scalp_status(inst)
        return rt.ml.scalp_status(inst)

    def _ml_scalp_job(args: list[str]):
        import subprocess
        from ..training import core as tc
        log = open(tc.training_dir() / "ml_scalp_jobs.log", "a", encoding="utf-8")
        kw = {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)} if os.name == "nt" else {"start_new_session": True}
        pr = subprocess.Popen([sys.executable, "-m", "masterquo", "ml-scalp", *args], cwd=str(paths.ROOT_DIR / "backend"), stdout=log,
                              stderr=subprocess.STDOUT, **kw)
        return {"started": True, "job_pid": pr.pid, "args": args}

    @app.post("/api/v1/ml/scalp/prepare")
    def ml_scalp_prepare(body: dict):
        inst = body.get("asset") or rt.cfg.get().assets.active
        if inst not in ("XAUUSD", "BTC"):
            raise HTTPException(400, "UNKNOWN_INSTRUMENT")
        return _ml_scalp_job(["prepare", "--asset", inst])

    @app.post("/api/v1/ml/scalp/train")
    def ml_scalp_train(body: dict):
        inst = body.get("asset") or rt.cfg.get().assets.active
        if inst not in ("XAUUSD", "BTC"):
            raise HTTPException(400, "UNKNOWN_INSTRUMENT")
        args = ["train", "--asset", inst, "--activate", "none"]
        if body.get("commission") is not None:
            args += ["--commission", str(float(body["commission"]))]
        return _ml_scalp_job(args)

    @app.get("/api/v1/ml/scalp/predictions")
    def ml_scalp_predictions(limit: int = Query(50, ge=1, le=500), before: str | None = Query(None)):
        q, prm = "SELECT * FROM ml_scalp_predictions WHERE instrument=?", [rt.ml.inst]
        if before:
            q += " AND computed_at < ?"
            prm.append(before)
        return {"predictions": rt.ml.db.query(q + " ORDER BY computed_at DESC LIMIT ?", (*prm, limit))}

    @app.get("/api/v1/ml/scalp/explain")
    def ml_scalp_explain(prediction_id: str = Query(...)):
        from ..ml import scalp_task as stk
        pr = rt.ml.db.one("SELECT * FROM ml_scalp_predictions WHERE prediction_id=?", (prediction_id,))
        if not pr:
            raise HTTPException(404, "UNKNOWN_PREDICTION")
        smp = rt.ml.db.one("SELECT features FROM ml_scalp_samples WHERE sample_id=?", (pr["sample_id"],))
        b, sel = stk.selected_bundle(pr["instrument"], pr["side"])
        if b is None or b.man["model_hash"] != pr["model_hash"]:
            return {"status": "MODEL_CHANGED", "reason": "model tej predykcji nie jest już wybrany – wyjaśnienie nie zostanie zmieszane z innym modelem"}
        return dict(b.explain(json.loads(smp["features"])), prediction_id=prediction_id, snapshot_hash=pr["snapshot_hash"])

    @app.post("/api/v1/ml/scalp/select")
    def ml_scalp_select(body: dict):
        from ..ml import scalp_task as stk
        try:
            return {"ok": True, "selected": stk.select(body.get("asset") or rt.ml.inst, str(body.get("run_id")), str(body.get("side")), str(body.get("role")))}
        except (ValueError, OSError, KeyError) as exc:
            return {"ok": False, "reason": str(exc)}

    @app.post("/api/v1/ml/scalp/rollback")
    def ml_scalp_rollback(body: dict):
        from ..ml import scalp_task as stk
        try:
            return {"ok": True, "selected": stk.rollback(body.get("asset") or rt.ml.inst, str(body.get("side")))}
        except (ValueError, OSError) as exc:
            return {"ok": False, "reason": str(exc)}

    @app.post("/api/v1/ml/reload")
    def ml_reload():
        """After offline training (training installer): re-read champion of the active instrument's ML registry."""
        rt.ml.registry.reload()
        rt.ml._pred_cache.clear()
        return {"ok": True, "instrument": rt.ml.inst, "champion": rt.ml.registry.champion_id}

    @app.post("/api/v1/ml/backfill")
    def ml_backfill(req: MLBackfillReq):
        return rt.ml.start_backfill(req.days)

    @app.post("/api/v1/ml/cancel")
    def ml_cancel():
        return rt.ml.cancel()

    @app.post("/api/v1/ml/resume")
    def ml_resume():
        return rt.ml.resume_interrupted()

    @app.post("/api/v1/ml/rollback")
    def ml_rollback():
        try:
            return rt.ml.rollback()
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc

    @app.get("/api/v1/ml/models")
    def ml_models():
        return {"models": rt.ml.registry.models(50), "events": rt.ml.registry.events(50)}

    @app.get("/api/v1/ml/report")
    def ml_report():
        return rt.ml.last_report() or {"available": False, "reason": "NO_COMPLETED_TRAINING"}

    @app.get("/api/v1/ml/explain")
    def ml_explain(setup_id: str = Query(...), version: int = Query(...)):
        return rt.ml.explain(setup_id, version)

    @app.get("/api/v1/ml/predict")
    def ml_predict(setup_id: str = Query(...)):
        row = rt.engine.active.tracker.get(setup_id)
        if not row:
            raise HTTPException(404, "UNKNOWN_SETUP")
        return rt.ml.predict(row, rt.engine.active.view)

    @app.post("/api/v1/strategy/toggle")
    def strategy_toggle(req: StrategyToggleReq):
        from ..strategies import registry as _reg
        if req.strategy_id not in _reg.STRATEGIES:
            raise HTTPException(400, "UNKNOWN_STRATEGY_ID")
        cur = rt.cfg.get().active.strategies.get(req.strategy_id)
        patch = {"scan": cur.scan if cur else True, "trade": cur.trade if cur else True}
        if req.scan is not None:
            patch["scan"] = req.scan
        if req.trade is not None:
            patch["trade"] = req.trade
        rt.cfg.update({"active": {"strategies": {req.strategy_id: patch}}})
        rt.log.info("AUTO", "STRATEGY_TOGGLE", f"{req.strategy_id}: skanuj={'TAK' if patch['scan'] else 'NIE'}, handel={'TAK' if patch['trade'] else 'NIE'}")
        rt.engine.mark_dirty()
        return rt.engine.active.status(compact=True)

    @app.post("/api/v1/strategy/profile")
    def strategy_profile(req: ProfileReq):
        rt.cfg.update({"active": {"profile": req.profile}})
        rt.engine.active.selector.reset("PROFILE_CHANGED")
        rt.log.info("AUTO", "PROFILE", f"Profil wykrywania: {req.profile}")
        rt.engine.mark_dirty()
        return rt.engine.active.status(compact=True)

    @app.get("/api/v1/strategy/selection-log")
    def selection_log(limit: int = 30):
        return {"log": rt.engine.active.selection_log(max(1, min(limit, 200)))}

    @app.get("/api/v1/playbook")
    def playbook(limit: int = 100):
        rows = rt.db.query("SELECT setup_id, strategy_id, strategy_version, direction, timeframe, stage, status, version, score, first_seen_at, first_price, "
                           "updated_at, terminal_reason, terminal_at, synthetic, record_json, history_json FROM strategy_setups ORDER BY first_seen_at DESC LIMIT ?",
                           (max(1, min(limit, 500)),))
        trades = {t["setup_id"]: t for t in rt.db.query("SELECT setup_id, mode, side, net_pnl, gross_pnl, opened_at, closed_at FROM trades WHERE setup_id LIKE 'MQA-%'")}
        out = []
        for r in rows:
            rec = json.loads(r.pop("record_json"))
            hist = json.loads(r.pop("history_json"))
            out.append({**r, "context": {"regime": rec.get("regime"), "horizon": rec.get("horizon"), "countertrend": rec.get("countertrend")},
                        "hypothesis": rec.get("strategy_name"), "plan": {k: rec.get(k) for k in ("entry_plan", "stop_loss", "targets", "invalidation_level", "exit_rules")},
                        "score": rec.get("score"), "missing": rec.get("missing_confirmations"), "history": hist, "result": trades.get(r["setup_id"]) or "brak danych"})
        return {"cards": out, "note": "Karty obejmują także setupy anulowane, unieważnione i wygasłe – nie tylko wybrane sukcesy."}

    @app.get("/api/v1/appearance/assets")
    def appearance_assets():
        out = {}
        for slot, (anim, static_name) in MEDIA_SLOTS.items():
            user = media_dir() / anim
            built = paths.FRONTEND_DIST / "assets" / "masterquo" / anim
            info = gif_info(user.read_bytes()) if user.is_file() else (gif_info(built.read_bytes()) if built.is_file() else None)
            out[slot] = {"animated_available": user.is_file() or built.is_file(), "source": "USER_UPLOAD" if user.is_file() else ("BUILT_IN" if built.is_file() else "NONE"),
                         "animated_url": f"/media/masterquo/{slot}?v={int(user.stat().st_mtime) if user.is_file() else 0}",
                         "static_url": f"/static/assets/masterquo/{static_name}", "gif": info}
        return out

    @app.post("/api/v1/appearance/upload")
    async def appearance_upload(request: Request, slot: str = Query(..., pattern="^(background|frog)$")):
        data = await request.body()
        if len(data) > MAX_GIF_BYTES:
            raise HTTPException(413, "FILE_TOO_LARGE")
        info = gif_info(data)
        if not info:
            raise HTTPException(400, "NOT_A_GIF")
        target = media_dir() / MEDIA_SLOTS[slot][0]
        tmp = target.with_suffix(".tmp")
        tmp.write_bytes(data)
        tmp.replace(target)
        rt.log.info("UI", "ASSET_UPLOADED", f"Wgrano GIF ({slot}): {info['width']}×{info['height']}, {info['frames']} klatek, pętla {info['loop_duration_ms']} ms")
        return {"ok": True, "slot": slot, "gif": info}

    @app.get("/media/masterquo/{slot}")
    def media(slot: str):
        if slot not in MEDIA_SLOTS:
            raise HTTPException(404)
        name = MEDIA_SLOTS[slot][0]
        for f in (media_dir() / name, paths.FRONTEND_DIST / "assets" / "masterquo" / name):
            if f.is_file():
                return FileResponse(f, media_type="image/gif", headers={"Cache-Control": "no-cache"})
        raise HTTPException(404)

    @app.post("/api/v1/auto")
    def set_auto(req: OnReq):
        try:
            return rt.modes.set_auto(req.on)
        except ModeError as exc:
            raise HTTPException(400, str(exc)) from exc

    @app.post("/api/v1/kill")
    def kill(req: OnReq):
        st = rt.modes.set_kill(req.on, req.reason)
        rt.engine.mark_dirty()
        return st

    @app.post("/api/v1/execute")
    def execute(req: ExecReq):
        return rt.gateway.execute(req.decision_id, initiated_by="USER")

    @app.post("/api/v1/positions/close")
    def close_positions(req: CloseReq):
        if req.confirm != "ZAMKNIJ":
            raise HTTPException(400, "CONFIRMATION_REQUIRED_TYPE_ZAMKNIJ")
        return rt.manager.close_positions(req.scope, req.ticket)

    @app.post("/api/v1/positions/{ticket}/adopt")
    def adopt(ticket: int, req: CloseReq):
        if req.confirm != "PRZEJMIJ":
            raise HTTPException(400, "CONFIRMATION_REQUIRED_TYPE_PRZEJMIJ")
        return rt.manager.adopt(ticket)

    @app.post("/api/v1/mt5/reconnect")
    def reconnect():
        rt.bridge.state = "RECONNECTING"
        rt.bridge.next_retry = 0
        return {"ok": True}

    @app.post("/api/v1/news/refresh")
    def news_refresh():
        rt.news.refresh_now()
        return {"ok": True}

    @app.get("/api/v1/diagnostics")
    def diagnostics():
        from ..runtime import platform_info
        b = rt.bridge
        raw = {tf: [x["t_raw"] for x in b.bars(tf, limit=4)] for tf in TIMEFRAMES}
        return {"app": {"version": APP_VERSION, "contract": API_CONTRACT_VERSION, "synthetic": rt.demo}, "platform": platform_info(),
                "connection": b.connection_status(), "symbol": b.symbol_status_dict(), "tf_meta": b.tf_meta(),
                "raw_last_bar_opens": raw, "quote": b.quote_status(), "pc_clock": rt.pcclock.snapshot(),
                "worker": {"calls": rt.worker.calls, "failures": rt.worker.failures, "module_error": rt.worker.module_error},
                "db_schema": rt.db.schema_versions(), "agent": rt.agent.status(), "news": {k: v for k, v in rt.news.summary().items() if k in ("status", "error", "failed_sources")},
                "engine": {"last_error": rt.engine.last_error, "cycle_ms": rt.engine.cycle_ms, "required_bars": rt.engine.required}}

    # ------------------------------------------------------------ Telegram (information only; token = local secret, never returned)
    @app.get("/api/v1/telegram")
    def telegram_status():
        return rt.telegram.status()

    @app.get("/api/v1/telegram/template")
    def telegram_template_get():
        """1.32 Message Studio: the saved signal template (own file, not config.json) and the allowed variables."""
        return rt.telegram.templates.info()

    @app.put("/api/v1/telegram/template")
    def telegram_template_put(req: TelegramTemplateReq):
        try:
            tpl = rt.telegram.templates.set(req.template)
        except ValueError as exc:
            raise HTTPException(400, f"TEMPLATE: {exc}") from exc
        rt.log.info("TELEGRAM", "TEMPLATE_SAVED", "Szablon sygnału Telegram: " + ("własny" if tpl else "format wbudowany"))
        return rt.telegram.templates.info()

    @app.post("/api/v1/telegram/preview")
    def telegram_preview(req: TelegramTemplateReq):
        """1.32 Message Studio: the signal message as it would be sent (last real signal, else an example marked as such)."""
        try:
            return rt.telegram.preview(req.template)
        except ValueError as exc:
            raise HTTPException(400, f"TEMPLATE: {exc}") from exc

    @app.post("/api/v1/telegram/test")
    def telegram_test(req: TelegramTemplateReq | None = None):
        try:
            r = rt.telegram.send_test(req.template if req and req.template is not None else None)
        except ValueError as exc:
            raise HTTPException(400, f"TEMPLATE: {exc}") from exc
        rt.log.info("TELEGRAM", "TEST", "Wiadomość testowa Telegram: " + ("dostarczona" if r["ok"] else f"błąd – {r['error']}"))
        return r

    @app.post("/api/v1/telegram/stats-now")
    def telegram_stats_now():
        return {"sent": rt.telegram.send_daily_stats(force=True), "status": rt.telegram.status()}

    # ------------------------------------------------------------ desktop application (Windows shell): window, autostart, restart
    # ---------------------------------------------------------------- 1.32 Control Tower: resources, strategy presets
    @app.get("/api/v1/system/resources")
    def system_resources():
        return sysres.snapshot()

    preset_store = presets.PresetStore(paths.data_dir())

    @app.get("/api/v1/presets/strategy")
    def presets_list():
        cur = rt.cfg.get().model_dump(mode="json")
        return {"items": preset_store.list(), "current": presets.snapshot(cur), "defaults": presets.defaults(),
                "fields": [f"{a}.{b}" for a, b in presets.FIELDS],
                "note": "Preset = nazwana kopia ustawień wyboru strategii, progów setupu i filtrów wejść. Wczytanie zapisuje je tą samą drogą co "
                        "Ustawienia (walidacja); tryb wykonania, limity ryzyka i dane rachunku nie są częścią presetu."}

    @app.post("/api/v1/presets/strategy")
    def presets_save(req: PresetReq):
        try:
            item = preset_store.save(req.name, rt.cfg.get().model_dump(mode="json"))
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc
        rt.log.info("CONFIG", "PRESET_SAVED", f"Zapisano preset strategii „{item['name']}”.")
        return item

    @app.post("/api/v1/presets/strategy/load")
    def presets_load(req: PresetReq):
        item = preset_store.get(req.name)
        if not item:
            raise HTTPException(404, "PRESET_NOT_FOUND")
        out = _apply_preset(item.get("values") or {})
        rt.log.info("CONFIG", "PRESET_LOADED", f"Wczytano preset strategii „{req.name}”.")
        return out

    @app.post("/api/v1/presets/strategy/reset")
    def presets_reset():
        out = _apply_preset(presets.defaults())
        rt.log.info("CONFIG", "PRESET_RESET", "Przywrócono domyślne ustawienia sterowania strategią.")
        return out

    def _apply_preset(values: dict) -> dict:
        """Strategy selection goes through its own endpoint (setup view + selector reset, as the panel switch does); the other
        fields through the validated config write."""
        values = dict(values)
        mode, manual = values.pop("active.strategy_mode", None), values.pop("active.manual_strategy_id", None)
        out = put_config(presets.patch_of(values))
        cur = rt.cfg.get().active
        if mode in ("AUTO", "MANUAL") and (mode, manual if mode == "MANUAL" else None) != (cur.strategy_mode, cur.manual_strategy_id):
            strategy_mode(StrategyModeReq(strategy_mode=mode, manual_strategy_id=manual if mode == "MANUAL" else None))
            out = get_config()
        return out

    @app.get("/api/v1/desktop")
    def desktop_get():
        return desktop.info()

    @app.post("/api/v1/desktop/prefs")
    def desktop_prefs(req: DesktopPrefsReq):
        try:
            out = desktop.save_prefs(req.close_action, req.autostart, req.start_minimized)
        except desktop.DesktopError as exc:
            raise HTTPException(400, str(exc)) from exc
        except OSError as exc:
            raise HTTPException(500, f"AUTOSTART_REGISTRY_ERROR: {exc}") from exc
        rt.log.info("APP", "DESKTOP_PREFS", f"Praca aplikacji: zamknięcie okna={req.close_action}, autostart={req.autostart}, "
                    f"start w tle={req.start_minimized}")
        return out

    @app.post("/api/v1/desktop/restart-engine")
    async def desktop_restart():
        try:
            desktop.request_restart()
        except desktop.DesktopError as exc:
            raise HTTPException(400, str(exc)) from exc
        rt.log.info("APP", "ENGINE_RESTART_REQUEST", "Ponowne uruchomienie silnika na żądanie panelu")
        asyncio.get_running_loop().call_later(0.5, rt.request_shutdown)
        return {"ok": True}

    @app.post("/api/v1/admin/shutdown")
    async def shutdown():
        rt.log.info("APP", "SHUTDOWN_REQUEST", "Żądanie zatrzymania aplikacji")
        loop = asyncio.get_running_loop()
        loop.call_later(0.5, rt.request_shutdown)
        return {"ok": True}

    # ------------------------------------------------------------ websocket
    @app.websocket("/api/v1/ws")
    async def ws(websocket: WebSocket):
        if not sec.host_ok(websocket.headers.get("host")) or not sec.origin_ok(websocket.headers.get("origin")):
            await websocket.close(code=4403)
            return
        sid = websocket.cookies.get(SESSION_COOKIE)
        await websocket.accept()
        try:
            hello = json.loads(await asyncio.wait_for(websocket.receive_text(), timeout=10))
        except (asyncio.TimeoutError, ValueError, WebSocketDisconnect):
            await websocket.close(code=4400)
            return
        if not sec.csrf_ok(sid, hello.get("csrf")):
            await websocket.close(code=4403)
            return
        queue: asyncio.Queue = asyncio.Queue(maxsize=2000)
        unsub = rt.bus.subscribe_async(asyncio.get_running_loop(), queue)
        try:
            last = hello.get("last_seq")
            replay = rt.bus.since(int(last)) if isinstance(last, int) and hello.get("boot_id") == rt.bus.boot_id else None
            if replay is None:
                await websocket.send_text(json.dumps({"type": "resync", "seq": rt.bus.seq, "boot_id": rt.bus.boot_id, "state": full_state()}, default=str))
            else:
                for ev in replay:
                    await websocket.send_text(json.dumps(ev, default=str))
            while True:
                ev = await queue.get()
                if ev.get("type") == "__overflow__":
                    while not queue.empty():
                        queue.get_nowait()
                    await websocket.send_text(json.dumps({"type": "resync", "seq": rt.bus.seq, "boot_id": rt.bus.boot_id, "state": full_state()}, default=str))
                    continue
                await websocket.send_text(json.dumps(ev, default=str))
        except (WebSocketDisconnect, RuntimeError):
            pass
        finally:
            unsub()

    return app
