"""HTTP + WebSocket API (contract /api/v1, version in version.API_CONTRACT_VERSION).

The built web monitor (frontend/dist) is served from the same origin. No CORS is enabled.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
from contextlib import asynccontextmanager

from fastapi import Body, FastAPI, HTTPException, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response
from pydantic import BaseModel, Field
from starlette.middleware.base import BaseHTTPMiddleware

from .. import paths, stats
from ..execution.modes import ModeError
from ..media.gifinfo import gif_info
from ..timeutil import TIMEFRAMES, iso, utcnow
from ..version import API_CONTRACT_VERSION, APP_NAME, APP_VERSION
from .security import SESSION_COOKIE, LocalSecurity

log = logging.getLogger("masterquo.api")


class AssetConfirmReq(BaseModel):
    asset: str
    broker_symbol: str


class AssetActiveReq(BaseModel):
    asset: str


class LockReq(BaseModel):
    lock: str
    phrase: str | None = None


class ModeReq(BaseModel):
    mode: str
    confirm: str = ""


class OnReq(BaseModel):
    on: bool
    reason: str = "user"


class ExecReq(BaseModel):
    decision_id: str


class CloseReq(BaseModel):
    scope: str = "BOT"
    ticket: int | None = None
    confirm: str


SYMBOL_RX = r"^[A-Za-z0-9._#&$!+\-]{1,40}$"


class AskReq(BaseModel):
    question: str = Field(min_length=2, max_length=2000)


class KeyReq(BaseModel):
    api_key: str = Field(min_length=10, max_length=300)


class SecretReq(BaseModel):
    name: str
    value: str | None = None


class MLModeReq(BaseModel):
    mode: str = Field(pattern="^(OFF|SHADOW|ASSIST)$")


class MLTrainReq(BaseModel):
    include_approx: bool | None = None          # per job only (training installer); config ml.use_backfill_approx stays untouched


class MLBackfillReq(BaseModel):
    days: int = Field(30, ge=5, le=180)


class MLFlagReq(BaseModel):
    on: bool


class StrategyModeReq(BaseModel):
    strategy_mode: str = Field(pattern="^(AUTO|MANUAL)$")
    manual_strategy_id: str | None = Field(default=None, max_length=4)


class StrategyToggleReq(BaseModel):
    strategy_id: str = Field(pattern="^S[0-9]{2}$")          # checked against the registry in the endpoint (S11, S12 included)
    scan: bool | None = None
    trade: bool | None = None


class ProfileReq(BaseModel):
    profile: str = Field(pattern="^(ACTIVE|ORIGINAL)$")


MEDIA_SLOTS = {"background": ("background-matrix.gif", "background-matrix-static.webp"), "frog": ("frog-dance.gif", "frog-dance-static.png")}
MAX_GIF_BYTES = 15 * 1024 * 1024


class SetupViewReq(BaseModel):
    mode: str = Field(pattern="^(AUTO|SELECTED|ALL)$")
    strategy_id: str | None = Field(default=None, max_length=4)
    focus_setup_id: str | None = Field(default=None, max_length=120)


class LeverageReq(BaseModel):
    mode: str = Field(pattern="^(AUTO|MANUAL)$")
    limit: int | None = Field(default=None, ge=1, le=1000)


class MemoryReq(BaseModel):
    status: str


def create_app(rt, port: int) -> FastAPI:
    sec = LocalSecurity(port)
    rt.security = sec

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        rt.attach_loop(asyncio.get_running_loop())
        yield

    app = FastAPI(title=APP_NAME, version=APP_VERSION, docs_url=None, redoc_url=None, openapi_url=None, lifespan=lifespan)

    class Guard(BaseHTTPMiddleware):
        async def dispatch(self, request: Request, call_next):
            if not sec.host_ok(request.headers.get("host")):
                return JSONResponse({"error": "HOST_NOT_ALLOWED"}, status_code=421)
            path = request.url.path
            if request.method not in ("GET", "HEAD", "OPTIONS"):
                if path == "/api/v1/admin/shutdown" and request.headers.get("x-mq-shutdown") == sec.shutdown_token:
                    return await call_next(request)
                if not sec.origin_ok(request.headers.get("origin")):
                    return JSONResponse({"error": "ORIGIN_NOT_ALLOWED"}, status_code=403)
                if not sec.csrf_ok(request.cookies.get(SESSION_COOKIE), request.headers.get("x-mq-csrf")):
                    return JSONResponse({"error": "CSRF_OR_SESSION_INVALID"}, status_code=403)
            elif path.startswith("/api/v1/") and path not in ("/api/v1/health",) and not sec.csrf_for(request.cookies.get(SESSION_COOKIE)):
                return JSONResponse({"error": "SESSION_REQUIRED_OPEN_MONITOR_PAGE"}, status_code=401)
            resp: Response = await call_next(request)
            resp.headers["X-Content-Type-Options"] = "nosniff"
            resp.headers["Referrer-Policy"] = "no-referrer"
            resp.headers["X-Frame-Options"] = "DENY"
            resp.headers["Cache-Control"] = "no-store" if path.startswith("/api/") else resp.headers.get("Cache-Control", "no-cache")
            return resp

    app.add_middleware(Guard)

    # ------------------------------------------------------------ page + session
    def _index() -> Response:
        idx = paths.FRONTEND_DIST / "index.html"
        if not idx.exists():
            resp: Response = HTMLResponse("<h1>MasterQUO AI</h1><p>Brak zbudowanego frontendu (frontend/dist). "
                                          "Paczka zawiera gotowy build – sprawdź, czy rozpakowano cały ZIP.</p>", status_code=503)
        else:
            resp = FileResponse(idx, headers={"Cache-Control": "no-cache"})
        sid, _ = sec.new_session()
        resp.set_cookie(SESSION_COOKIE, sid, httponly=True, samesite="strict", secure=False, path="/")
        resp.headers["Content-Security-Policy"] = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
                                                   "img-src 'self' data: blob:; connect-src 'self' ws://127.0.0.1:%d ws://localhost:%d; "
                                                   "frame-ancestors 'none'; base-uri 'none'" % (port, port))
        return resp

    @app.get("/")
    def index():
        return _index()

    @app.get("/assets/{name:path}")
    def assets(name: str):
        base = (paths.FRONTEND_DIST / "assets").resolve()
        f = (base / name).resolve()
        if base not in f.parents or not f.is_file():
            raise HTTPException(404)
        return FileResponse(f, headers={"Cache-Control": "public, max-age=31536000, immutable"})

    @app.get("/static/{name:path}")
    def static(name: str):
        base = paths.FRONTEND_DIST.resolve()
        f = (base / name).resolve()
        if base not in f.parents or not f.is_file() or f.suffix not in (".png", ".webp", ".svg", ".ico", ".jpg", ".gif"):
            raise HTTPException(404)
        return FileResponse(f)

    @app.get("/api/v1/health")
    def health():
        return {"ok": True, "app": APP_NAME, "version": APP_VERSION, "contract": API_CONTRACT_VERSION, "boot_id": rt.bus.boot_id,
                "synthetic": rt.demo, "mt5_state": rt.bridge.state, "time": iso(utcnow())}

    @app.get("/api/v1/session")
    def session(request: Request):
        sid = request.cookies.get(SESSION_COOKIE)
        return {"csrf": sec.csrf_for(sid), "contract": API_CONTRACT_VERSION, "boot_id": rt.bus.boot_id, "port": port}

    # ------------------------------------------------------------ state
    def full_state() -> dict:
        b = rt.bridge
        cfg = rt.cfg.get()
        acct = b.account_status()
        mode = rt.modes.status()
        return {"contract": API_CONTRACT_VERSION, "app_version": APP_VERSION, "seq": rt.bus.seq, "boot_id": rt.bus.boot_id,
                "synthetic": rt.demo or b.synthetic, "server_time": iso(utcnow()),
                "connection": b.connection_status(), "account": acct, "symbol": b.symbol_status_dict(), "quote": b.quote_status(),
                "tf_meta": b.tf_meta(), "analysis": rt.engine.analysis_summary(), "decision": rt.engine.current_decision(),
                "prefs": {**rt.prefs.all(), "exposure": rt.prefs.exposure_limit()},
                "engine": {"last_error": rt.engine.last_error, "cycle_ms": rt.engine.cycle_ms, "full_cycles": rt.engine.full_count},
                "agent": rt.agent.status(), "agent_last": rt.agent.public_result(rt.agent.last_result), "mode": mode,
                "risk_config": cfg.risk.model_dump(), "costs_config": cfg.costs.model_dump(), "strategy_config": cfg.strategy.model_dump(),
                "news": rt.news.summary(), "positions": {"positions": b.positions, "orders": b.orders},
                "managed": rt.db.query("SELECT * FROM managed_positions WHERE state='OPEN'"),
                "attempts": rt.gateway.recent_attempts(15), "paper": rt.paper.account() if mode["mode"] == "PAPER" else None,
                "logs": logs_list(60), "pc_clock": rt.pcclock.snapshot(), "manager": {"reconciled_epoch": rt.manager.reconciled_epoch,
                                                                                     "last_error": rt.manager.last_error},
                "first_run_completed": cfg.first_run_completed,
                "auto": rt.engine.active.status(compact=True), "active_config": cfg.active.model_dump(mode="json"),
                "ml": rt.ml.status(compact=True), "markets": rt.scanner.summary(),
                "bot_signals": {**rt.signals.status(), **rt.signals.list(limit=40)},
                "assets": rt.assets.state(), "execution_lock": cfg.execution.lock, "lab": rt.lab.summary(cfg.assets.active)}

    def logs_list(limit: int) -> list[dict]:
        return rt.db.query("SELECT id, ts, level, category, code, message FROM app_events ORDER BY id DESC LIMIT ?", (limit,))

    @app.get("/api/v1/state")
    def state():
        return full_state()

    @app.get("/api/v1/candles")
    def candles(tf: str = Query(...)):
        if tf not in TIMEFRAMES:
            raise HTTPException(400, "INVALID_TIMEFRAME")
        return rt.engine.chart(tf)

    @app.get("/api/v1/volatility")
    def volatility():
        return rt.engine.volatility()

    # ------------------------------------------------------------ 1.10: walls for strategies, IV import, structure (S/R, range, patterns)
    @app.get("/api/v1/timeframes")
    def timeframes():
        """TF registry (role per TF) + which TFs each strategy needs - the chart pages are built from this, never from a
        hard-coded list. Data status per TF from the engine's data-quality gate."""
        from ..strategies import registry as _reg
        from ..timeutil import TF_REGISTRY
        dq = (rt.engine.dq or {}).get("timeframes") or {}
        strat = {d["strategy_id"]: {"setup_tfs": d["setup_tfs"], "required_tfs": d["required_tfs"], "context_tf": d["context_tf"], "name": d["name"]}
                 for d in _reg.describe()}
        return {"timeframes": [{"tf": tf, "seconds": v["seconds"], "role": v["role"], "core": v["core"],
                                "data": (dq.get(tf) or {}).get("status"), "closed_bars": (dq.get(tf) or {}).get("closed_bars"),
                                "required": (dq.get(tf) or {}).get("required"), "used_by": sorted(sid for sid, x in strat.items()
                                                                                                     if tf in x["setup_tfs"] or tf in x["required_tfs"] or tf == x["context_tf"])}
                               for tf, v in TF_REGISTRY.items()], "strategies": strat}

    @app.get("/api/v1/forecast")
    def forecast_get():
        """SHADOW candle analytics + price forecasts 5/15/30 + Double Retest v2 research state. Never an order permission."""
        return {**rt.forecast.public(), "registry": rt.forecast.registry(), "training": rt.forecast.training_status(),
                "config": rt.cfg.get().forecast.model_dump(), "shadow_summary": rt.forecast.shadow_summary()}

    # ------------------------------------------------------------ 1.13 analytics + pattern library (observational)
    # ------------------------------------------------------------ 1.14 lab (XAUUSD / BTC)
    def _asset(asset: str | None) -> str:
        a = asset or rt.cfg.get().assets.active
        if a not in ("XAUUSD", "BTC"):
            raise HTTPException(403, f"ASSET_NOT_ALLOWED:{a}")
        return a

    @app.get("/api/v1/lab")
    def lab_state(asset: str | None = None):
        return rt.lab.public(_asset(asset))

    @app.get("/api/v1/lab/traceability")
    def lab_trace():
        from ..lab import traceability
        return {"rows": traceability.ROWS, "summary": traceability.summary()}

    @app.get("/api/v1/lab/memory")
    def lab_memory(tf: str = Query(...), t: str = Query(...)):
        from ..lab.sessions import memory_sequence
        if tf not in TIMEFRAMES:
            raise HTTPException(400, "INVALID_TIMEFRAME")
        by = {x: [b for b in rt.bridge.bars(x, 500, include_forming=False) if b.get("open_utc")] for x in ("M1", "M5", "M15", "M30", "H1", "H4", "D1")}
        return {"asset": rt.cfg.get().assets.active, **memory_sequence(by, tf, t)}

    @app.post("/api/v1/lab/train")
    def lab_train(body: dict = Body(default={})):
        from ..lab.protocol import default_protocol, FAMILIES, EXPERIMENTS
        a = _asset(body.get("asset"))
        if a != rt.cfg.get().assets.active:
            raise HTTPException(409, "TRAIN_ONLY_ACTIVE_ASSET")
        sym = rt.assets.check_asset(a, "TRAINING")
        if rt.bridge.state != "CONNECTED":
            raise HTTPException(409, "MT5_NOT_CONNECTED")
        fams = [f for f in (body.get("families") or FAMILIES) if f in FAMILIES]
        exps = [e for e in (body.get("experiments") if body.get("experiments") is not None else EXPERIMENTS) if e in EXPERIMENTS]
        bars = [b for b in rt.bridge.symbol_bars(sym, "M5", int(min(max(body.get("bars") or 20000, 2000), 100000))) if b.get("closed") and b.get("open_utc")]
        prot = default_protocol(a, families=fams, experiments=exps, min_events=int(body.get("min_events") or 600))
        meta = rt.bridge.symbol_meta(sym) or {}
        src = "SYNTHETIC" if (rt.demo or rt.bridge.synthetic or rt.cfg.get().synthetic_demo) else "MT5"
        return rt.lab.trainer.start(a, bars, point=float(meta.get("point") or 0.01), data_source=src,
                                    instrument_id=rt.assets.instrument(a)["instrument_id"], protocol=prot,
                                    artifact_family=body.get("artifact_family") if (body.get("artifact_family") in fams or body.get("artifact_family") == "ALL") else "auto")

    @app.get("/api/v1/lab/jobs")
    def lab_jobs():
        return {"jobs": rt.lab.trainer.public()}

    @app.post("/api/v1/lab/jobs/{jid}/cancel")
    def lab_cancel(jid: str):
        return rt.lab.trainer.cancel(jid)

    @app.get("/api/v1/lab/models")
    def lab_models(asset: str | None = None):
        a = _asset(asset)
        return {"asset": a, "models": rt.lab.trainer.models(a)}

    @app.get("/api/v1/lab/studies/{jid}")
    def lab_study(jid: str):
        if not _re.fullmatch(r"LJOB-[0-9TZ]+-[0-9a-f]{4}", jid):
            raise HTTPException(400, "INVALID_JOB_ID")
        f = rt.lab.trainer.root / "studies" / f"{jid}.json"
        if not f.exists():
            raise HTTPException(404, "NO_STUDY")
        return json.loads(f.read_text(encoding="utf-8"))

    @app.get("/api/v1/lab/trials")
    def lab_trials(asset: str | None = None):
        a = _asset(asset)
        return {"asset": a, "trials": rt.db.query("SELECT trial_id, created_at, horizon, model_family, protocol_id, data_hash, status, metrics, note "
                                                  "FROM lab_trials WHERE asset=? ORDER BY created_at DESC LIMIT 200", (a,)),
                "holdout_access": rt.db.query("SELECT * FROM lab_holdout_access WHERE asset=? ORDER BY at DESC LIMIT 50", (a,))}

    @app.get("/api/v1/lab/zones")
    def lab_zones(asset: str | None = None):
        a = _asset(asset)
        return {"asset": a, "zones": rt.lab.zones.load_db(a)[-100:], "events": rt.lab.zones.events[-10:]}

    @app.get("/api/v1/lab/repaint")
    def lab_repaint():
        return {"report": rt.lab.repaint.report(),
                "recent": rt.db.query("SELECT asset, module, tf, bar_open, observed_at, change FROM lab_repaint ORDER BY id DESC LIMIT 50")}

    @app.post("/api/v1/lab/tradepad")
    def lab_tradepad(body: dict = Body(...)):
        from ..lab.edge import trade_pad_plan
        a = rt.cfg.get().assets.active
        sym = rt.assets.check_asset(a, "TRADEPAD")
        meta = rt.bridge.symbol_meta(sym)
        if not meta:
            raise HTTPException(409, "NO_SYMBOL_METADATA")
        meta = {**meta, **{k: (rt.bridge.symbol_info or {}).get(k) for k in ("volume_min", "volume_step")}}
        try:
            plan = trade_pad_plan(side=str(body.get("side")), entry=float(body["entry"]), sl=float(body["sl"]), tp=float(body["tp"]),
                                  lots=float(body.get("lots") or 0.01), meta=meta, quote=rt.bridge.quote_status(),
                                  commission_per_lot_side=float(rt.cfg.get().scalp.commission_per_lot_side or 0))
        except (KeyError, ValueError) as exc:
            raise HTTPException(400, f"INVALID_PLAN: {exc}") from exc
        return {"asset": a, "broker_symbol": sym, **plan, "execution_lock": rt.cfg.get().execution.lock}

    @app.post("/api/v1/lab/tradepad/execute")
    def lab_tradepad_execute(body: dict = Body(default={})):
        # deliberately no order path: the trade pad is analytical in this release; refused below the UI too
        rt.log.warn("EXECUTION", "TRADEPAD_REFUSED", "Trade Pad: próba wykonania odrzucona (Execution Lock / tryb analityczny).")
        raise HTTPException(403, "EXECUTION_LOCKED_TRADEPAD_SIMULATION_ONLY")

    @app.get("/api/v1/analytics")
    def analytics_get():
        return {**rt.analytics.summary(), "config": rt.cfg.get().analytics.model_dump()}

    @app.get("/api/v1/analytics/tf/{tf}")
    def analytics_tf(tf: str):
        if tf not in rt.cfg.get().analytics.timeframes:
            raise HTTPException(404, "TF_NOT_CONFIGURED")
        return rt.analytics.tf_state(tf, full=True)

    @app.get("/api/v1/analytics/history")
    def analytics_history(module: str | None = None, tf: str | None = None, limit: int = Query(100, ge=1, le=1000)):
        return {"items": rt.analytics.history(module, tf, limit)}

    @app.get("/api/v1/analytics/diagnostics")
    def analytics_diag():
        return rt.analytics.diagnostics()

    @app.get("/api/v1/patterns/samples")
    def pat_list(symbol: str | None = None, tf: str | None = None, status: str | None = None, rules_version: str | None = None):
        return {"items": rt.analytics.library.list(symbol, tf, status, rules_version), "jobs": rt.analytics.library.jobs(10)}

    @app.post("/api/v1/patterns/samples")
    def pat_add(body: dict = Body(...)):
        """Sample from the chart selection: {tf, start_utc, end_utc, note} - closed bars of the bot's feed (raw OHLCV kept)."""
        tf = str(body.get("tf") or "")
        bars = [b for b in rt.bridge.bars(tf, None, include_forming=False) if b.get("open_utc")] if tf in ("M1", "M5", "M15", "M30", "H1", "H4", "D1") else []
        sel = [{k: b[k] for k in ("open_utc", "o", "h", "l", "c", "tv")} for b in bars if str(body.get("start_utc")) <= b["open_utc"] <= str(body.get("end_utc"))]
        if not sel:
            raise HTTPException(400, "NO_CLOSED_BARS_IN_RANGE")
        r = rt.analytics.library.add_sample(rt.cfg.get().mt5.symbol, tf, sel, "CHART_SELECTION" if not rt.bridge._synthetic else "CHART_SELECTION_SYNTHETIC",
                                            body.get("note"))
        if not r["ok"]:
            raise HTTPException(400, r["error"])
        return r

    @app.get("/api/v1/patterns/samples/{sid}")
    def pat_get(sid: int):
        s = rt.analytics.library.get(sid)
        if not s:
            raise HTTPException(404, "SAMPLE_NOT_FOUND")
        return s

    @app.delete("/api/v1/patterns/samples/{sid}")
    def pat_del(sid: int):
        return {"ok": rt.analytics.library.delete(sid)}

    @app.post("/api/v1/patterns/samples/{sid}/validate")
    def pat_validate_one(sid: int):
        r = rt.analytics.library.validate_one(sid)
        if not r["ok"]:
            raise HTTPException(404, r["error"])
        return r

    @app.post("/api/v1/patterns/validate")
    def pat_validate(body: dict = Body(...)):
        ids = body.get("ids")
        if ids is not None and (not isinstance(ids, list) or not all(isinstance(i, int) for i in ids)):
            raise HTTPException(400, "IDS_MUST_BE_INT_LIST_OR_NULL")
        return rt.analytics.library.start_job(ids)

    @app.get("/api/v1/patterns/jobs/{job_id}")
    def pat_job(job_id: str):
        j = rt.analytics.library.job(job_id)
        if not j:
            raise HTTPException(404, "JOB_NOT_FOUND")
        return j

    @app.post("/api/v1/patterns/jobs/{job_id}/cancel")
    def pat_cancel(job_id: str):
        return {"ok": rt.analytics.library.cancel(job_id)}

    @app.get("/api/v1/patterns/reports/{report_id}")
    def pat_report(report_id: str):
        r = rt.analytics.library.report(report_id)
        if not r:
            raise HTTPException(404, "REPORT_NOT_FOUND")
        return r

    @app.get("/api/v1/patterns/export")
    def pat_export():
        return rt.analytics.library.export_samples()

    @app.post("/api/v1/patterns/import")
    def pat_import(body: dict = Body(...)):
        return rt.analytics.library.import_samples(body)

    @app.get("/api/v1/patterns/live")
    def pat_live():
        a = rt.cfg.get().analytics
        return {"timeframes": {tf: (rt.analytics.state.get(tf) or {}).get("double_bottom") for tf in a.db_timeframes},
                "events": rt.analytics.events(50), "profile": a.db_profile}

    @app.get("/api/v1/scalp")
    def scalp_get():
        """Scalp profile (M5 Range -> M1 Sweep/Reclaim -> Retest) + hedge controller in SHADOW: MTF, setup, indicators, adapters,
        forecasts, hedge/risk, training and the separate validity statuses. Never an order permission."""
        return {**rt.scalp.public(), "config": rt.cfg.get().scalp.model_dump(), "profile": rt.scalp.prof, "registry": rt.scalp.registry()}

    @app.get("/api/v1/scalp/shadow")
    def scalp_shadow(limit: int = Query(100, ge=1, le=1000)):
        return {"items": rt.scalp.recent(limit), "summary": rt.scalp.summary()}

    @app.get("/api/v1/forecast/shadow")
    def forecast_shadow(limit: int = Query(100, ge=1, le=1000)):
        return {"items": rt.forecast.recent(limit)}

    @app.post("/api/v1/forecast/reload")
    def forecast_reload():
        rt.forecast.reload()
        rt.log.info("FORECAST", "RELOAD", "Przeładowanie modelu prognoz – nowa wersja od następnej zamkniętej świecy M5.")
        return {"ok": True}

    @app.get("/api/v1/walls")
    def walls_get():
        snap = {k: v for k, v in (rt.walls.last or {}).items() if not k.startswith("_")}
        return {"status": rt.walls.status(), "snapshot": snap,
                "note": "HV_PROXY = zmienność historyczna brokera jako przybliżenie – nie zmienność implikowana. Walls to pasma konwencji log-zwrotu, nie prognoza."}

    @app.post("/api/v1/walls/iv-import")
    def walls_iv_import(body: dict = Body(...)):
        from ..analysis import iv_import
        text = str(body.get("text") or "")
        if not text or len(text) > 1_000_000:
            raise HTTPException(400, "IV_IMPORT_EMPTY_OR_TOO_LARGE")
        try:
            rows = iv_import.parse_text(text, body.get("format"))
        except Exception as exc:
            raise HTTPException(400, f"IV_IMPORT_PARSE_ERROR: {type(exc).__name__}") from exc
        rep = iv_import.store(rt.db, rows, imported_by="MONITOR")
        rt.log.info("WALLS", "IV_IMPORT", f"Import IV: przyjęto {rep['accepted']}, odrzucono {len(rep['rejected'])}, już zapisane {rep['already_stored']} "
                    "(użycie od available_at; dotyczy przyszłych snapshotów).")
        rt.engine.mark_dirty()
        return rep

    @app.get("/api/v1/structure")
    def structure(tf: str = Query("M5")):
        if tf not in TIMEFRAMES:
            raise HTTPException(400, "INVALID_TIMEFRAME")
        return rt.engine.structure(tf)

    # ------------------------------------------------------------ markets (scanner) and AI signals
    import re as _re

    def _sym(symbol: str) -> str:
        if not _re.fullmatch(SYMBOL_RX, symbol or ""):
            raise HTTPException(400, "INVALID_SYMBOL")
        return symbol

    # ------------------------------------------------------------ 1.14 assets (XAUUSD / BTC) and Execution Lock
    @app.get("/api/v1/assets")
    def assets_state(refresh: bool = False):
        if refresh:
            rt.assets.refresh()
        return rt.assets.state()

    @app.get("/api/v1/assets/{asset}/candidates")
    def assets_candidates(asset: str):
        try:
            return {"asset": asset, "candidates": rt.assets.candidates(asset),
                    "note": "Kandydaci wg metadanych terminala (currency_base/profit). Nic nie jest wybierane automatycznie."}
        except PermissionError as exc:
            raise HTTPException(403, str(exc)) from exc
        except Exception as exc:
            raise HTTPException(409, f"{type(exc).__name__}: {exc}") from exc

    @app.post("/api/v1/assets/confirm")
    def assets_confirm(req: AssetConfirmReq):
        if not _re.fullmatch(SYMBOL_RX, req.broker_symbol or ""):
            raise HTTPException(400, "INVALID_SYMBOL")
        try:
            st = rt.assets.confirm(req.asset, req.broker_symbol)
        except PermissionError as exc:
            raise HTTPException(403, str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc
        rt.db.execute("INSERT INTO settings_audit(ts, change_json) VALUES (?,?)", (iso(utcnow()), json.dumps({"asset_confirm": req.model_dump()})))
        return st

    @app.post("/api/v1/assets/active")
    def assets_active(req: AssetActiveReq):
        old = rt.cfg.get().mt5.symbol
        try:
            st = rt.assets.switch(req.asset)
        except PermissionError as exc:
            raise HTTPException(409, str(exc)) from exc
        rt.db.execute("INSERT INTO settings_audit(ts, change_json) VALUES (?,?)", (iso(utcnow()), json.dumps({"active_asset": req.asset})))
        if rt.cfg.get().mt5.symbol != old:
            rt.modes.reset("ACTIVE_ASSET_CHANGED")
            rt.bridge.state = "RECONNECTING"
            rt.bridge.next_retry = 0
        rt.engine.mark_dirty()
        rt.bus.publish("assets", st)
        return st

    UNLOCK_PHRASE = "ODBLOKUJ WYKONANIE ZLECEN"

    @app.get("/api/v1/execution/lock")
    def exec_lock():
        c = rt.cfg.get().execution
        return {"lock": c.lock, "changed_at": c.lock_changed_at, "blocked_attempts": rt.worker.locked_attempts,
                "unlock_phrase_required": UNLOCK_PHRASE,
                "note": "LOCKED: żadna ścieżka (AUTO, zarządzanie pozycją, Trade Pad, API) nie wysyła order_send do terminala."}

    @app.post("/api/v1/execution/lock")
    def exec_lock_set(req: LockReq):
        if req.lock not in ("LOCKED", "UNLOCKED_BY_USER"):
            raise HTTPException(400, "INVALID_LOCK")
        if req.lock == "UNLOCKED_BY_USER" and (req.phrase or "").strip().upper() != UNLOCK_PHRASE:
            raise HTTPException(403, "UNLOCK_PHRASE_REQUIRED")
        rt.cfg.update({"execution": {"lock": req.lock, "lock_changed_at": iso(utcnow())}})
        rt.db.execute("INSERT INTO settings_audit(ts, change_json) VALUES (?,?)", (iso(utcnow()), json.dumps({"execution_lock": req.lock})))
        rt.log.warn("EXECUTION", "LOCK_" + req.lock, "Execution Lock: " + ("ZABLOKOWANE" if req.lock == "LOCKED" else "odblokowane przez użytkownika"))
        rt.engine.mark_dirty()
        rt.bus.publish("execution_lock", {"lock": req.lock})
        return exec_lock()

    @app.get("/api/v1/markets")
    def markets():
        return rt.scanner.summary()

    @app.post("/api/v1/markets/scan")
    def markets_scan():
        if rt.bridge.state != "CONNECTED":
            raise HTTPException(503, "MT5_NOT_CONNECTED")
        rt.scanner.scan_now()
        return {"queued": True}

    @app.get("/api/v1/markets/symbols")
    def markets_symbols(all: bool = False):
        try:
            return {"symbols": rt.bridge.list_symbols(visible_only=not all)}
        except Exception as exc:
            raise HTTPException(503, f"SYMBOLS_UNAVAILABLE: {exc}") from exc

    @app.get("/api/v1/markets/detail")
    def markets_detail(symbol: str = Query(...), fresh: bool = False):
        _sym(symbol)
        r = None if fresh else rt.scanner.get(symbol)
        if r is None:
            try:
                r = rt.scanner.analyze_symbol(symbol)
            except Exception as exc:
                raise HTTPException(404, f"SYMBOL_UNAVAILABLE: {exc}") from exc
        return r

    @app.get("/api/v1/markets/chart")
    def markets_chart(symbol: str = Query(...), tf: str = Query("H1"), bars: int = Query(300, ge=50, le=1500)):
        _sym(symbol)
        if tf not in TIMEFRAMES:
            raise HTTPException(400, "INVALID_TIMEFRAME")
        try:
            meta = rt.bridge.symbol_meta(symbol, select=rt.cfg.get().markets.source != "MARKET_WATCH")
            if meta is None:
                raise ValueError("SYMBOL_NOT_FOUND")
            data = rt.bridge.symbol_bars(symbol, tf, bars)
            from ..engine import volzones
            vol = volzones.compute(rt.bridge.symbol_bars(symbol, "D1", 420), rt.cfg.get().volatility, digits=int(meta.get("digits") or 5),
                                   quote=rt.bridge.symbol_quote(symbol, meta.get("point")))
        except Exception as exc:
            raise HTTPException(404, f"SYMBOL_UNAVAILABLE: {exc}") from exc
        sig = rt.signals.list(symbol=symbol, limit=10)["items"]
        return {"symbol": symbol, "tf": tf, "meta": meta, "bars": data, "volatility": vol,
                "bot_signals": [x for x in sig if x["status"] == "OPEN"][:3], "synthetic": rt.bridge.synthetic}

    @app.get("/api/v1/signal-history")
    def signal_history(strategy: str | None = None, status: str | None = None, tf: str | None = None, limit: int = Query(100, ge=1, le=1000)):
        where, args = ["synthetic=?"], [int(bool(rt.bridge.synthetic))]
        for col, val in (("strategy_id", strategy), ("status", status), ("entry_tf", tf)):
            if val:
                where.append(f"{col}=?")
                args.append(val)
        rows = rt.db.query(f"SELECT record_json FROM signal_history WHERE {' AND '.join(where)} ORDER BY updated_at DESC LIMIT ?", (*args, limit))
        return {"items": [json.loads(r["record_json"]) for r in rows]}

    @app.get("/api/v1/context-tf")
    def context_tf_view():
        d = rt.engine.current_decision() or {}
        return {"context": d.get("context_tf"), "signal": d.get("signal")}

    @app.get("/api/v1/bot-signals")
    def bot_signals(symbol: str | None = None, limit: int = Query(50, ge=1, le=500), rejected: bool = True):
        if symbol:
            _sym(symbol)
        return {**rt.signals.list(symbol=symbol, limit=limit, include_rejected=rejected), **rt.signals.status()}

    @app.get("/api/v1/bot-signals/{signal_id}")
    def bot_signal_get(signal_id: str):
        r = rt.signals.get(signal_id)
        if not r:
            raise HTTPException(404, "NOT_FOUND")
        return r

    @app.get("/api/v1/signals")
    def signals(limit: int = 30):
        from ..engine.lifecycle import public_setup
        legacy = [public_setup(r) for r in rt.engine.lifecycle.recent(min(limit, 100))]
        active = [{"setup_id": r["setup_id"], "created_at": r["first_seen_at"], "strategy_id": r["record"]["strategy_id"],
                   "profile": f"ACTIVE {r['record']['timeframe']}", "direction": r["record"]["direction"],
                   "state": r["stage"] if r["status"] == "ACTIVE" else r["status"], "invalidation_level": r["record"].get("invalidation_level"),
                   "terminal_reason": r.get("terminal_reason"), "synthetic": bool(r["record"].get("synthetic"))}
                  for r in rt.engine.active.tracker.recent(min(limit, 100))]
        setups = sorted(active + legacy, key=lambda x: x["created_at"] or "", reverse=True)[:limit]
        decs = rt.db.query("SELECT decision_id, created_at, setup_id, analysis_direction, signal_stage, decision, execution_permission FROM decisions "
                           "WHERE decision IN ('BUY','SELL') OR signal_stage IN ('CONFIRMED','INVALIDATED','EXPIRED') ORDER BY created_at DESC LIMIT 50")
        trades = rt.db.query("SELECT * FROM trades ORDER BY closed_at DESC LIMIT 50")
        return {"setups": setups, "decisions": decs, "attempts": rt.gateway.recent_attempts(30), "trades": trades}

    @app.get("/api/v1/decision")
    def decision():
        return rt.engine.current_decision()

    @app.get("/api/v1/stats")
    def get_stats(mode: str = "PAPER"):
        if mode not in ("PAPER", "AUTO_DEMO", "AUTO_LIVE"):
            raise HTTPException(400, "INVALID_MODE")
        b = rt.bridge
        with b._lock:
            deals = list(b.deals)
        ds = b.server_day_start_utc()
        ds_raw = ds.timestamp() + b.clock.offset if ds and b.clock.offset is not None else None
        return {"bot": stats.bot_stats(rt.db, mode, b.account_key), "equity": stats.equity_curve(rt.db, "PAPER" if mode == "PAPER" else "ACCOUNT", b.account_key),
                "account": stats.account_stats(deals, rt.cfg.get().mt5.symbol, ds_raw) if b.account_key else None,
                "account_roi": stats.account_roi(rt.db, b.account_key, deals, b.clock.offset)}

    @app.get("/api/v1/news")
    def news():
        return rt.news.summary()

    @app.get("/api/v1/logs")
    def logs(limit: int = 200):
        return logs_list(min(max(limit, 1), 2000))

    @app.get("/api/v1/config")
    def get_config():
        c = rt.cfg.get().model_dump(mode="json")
        return {"config": c, "secrets": {n: {"source": rt.secrets.source(n), "masked": rt.secrets.mask(n)}
                                         for n in ("ANTHROPIC_API_KEY", "TELEGRAM_BOT_TOKEN", "FRED_API_KEY", "MT5_PASSWORD")},
                "editable_note": "Klucze API są przechowywane lokalnie (Windows DPAPI) i nigdy nie są zwracane przez API."}

    @app.put("/api/v1/config")
    def put_config(patch: dict = Body(...)):
        patch.pop("server", None)
        # 1.14: asset mapping / active asset / Execution Lock change only through their dedicated, checked endpoints
        patch.pop("assets", None)
        m5 = patch.get("mt5") or {}
        m5.pop("analytical_alias", None)
        if m5.get("symbol"):                       # symbol typed in Ustawienia -> becomes the active asset's broker symbol
            patch.setdefault("assets", {})["mappings"] = {rt.cfg.get().assets.active: {"broker_symbol": m5["symbol"], "status": "USER_SPECIFIED"}}
        if isinstance(patch.get("execution"), dict) and ({"lock", "lock_changed_at"} & set(patch["execution"])):
            raise HTTPException(400, "USE_EXECUTION_LOCK_ENDPOINT")
        try:
            old = rt.cfg.get()
            new = rt.cfg.update(patch)
        except Exception as exc:
            raise HTTPException(400, f"INVALID_CONFIG: {exc}") from exc
        rt.db.execute("INSERT INTO settings_audit(ts, change_json) VALUES (?,?)", (iso(utcnow()), json.dumps({"config_patch": patch}, default=str)))
        rt.log.info("CONFIG", "UPDATED", "Zmieniono konfigurację: " + ", ".join(sorted(patch.keys())))
        if (old.mt5.symbol, old.mt5.terminal_path, old.mt5.dxy_symbol) != (new.mt5.symbol, new.mt5.terminal_path, new.mt5.dxy_symbol):
            rt.modes.reset("MT5_CONFIG_CHANGED")
            rt.bridge.state = "RECONNECTING"
            rt.bridge.next_retry = 0
        if old.risk != new.risk:
            rt.log.info("CONFIG", "RISK_LIMITS_CHANGED", "Zmieniono limity ryzyka – obowiązują od następnej decyzji.")
        rt.engine.mark_dirty()
        return get_config()

    @app.post("/api/v1/secrets/anthropic")
    def set_key(req: KeyReq):
        rt.secrets.set("ANTHROPIC_API_KEY", req.api_key)
        rt.log.info("AGENT", "KEY_SET", "Zapisano lokalnie klucz Anthropic (wartość nie jest logowana).")
        return {"ok": True, "masked": rt.secrets.mask("ANTHROPIC_API_KEY")}

    @app.post("/api/v1/secrets")
    def set_secret(req: SecretReq):
        if req.name not in ("TELEGRAM_BOT_TOKEN", "FRED_API_KEY", "ANTHROPIC_API_KEY", "MT5_PASSWORD"):
            raise HTTPException(400, "UNKNOWN_SECRET")
        rt.secrets.set(req.name, req.value)
        if req.name == "MT5_PASSWORD":                 # new password: try to connect again (value never logged)
            rt.log.info("MT5", "PASSWORD_SET", "Zapisano lokalnie hasło MT5 (wartość nie jest logowana).")
            if rt.bridge.state != "CONNECTED":
                rt.bridge.next_retry = 0
        return {"ok": True, "source": rt.secrets.source(req.name)}

    # ------------------------------------------------------------ agent
    @app.get("/api/v1/agent")
    def agent_status():
        runs = rt.db.query("SELECT run_id, started_at, finished_at, trigger, snapshot_id, setup_id, model_id, prompt_version, status, error_code, "
                           "latency_ms, input_tokens, output_tokens, est_cost_usd, tool_calls, question FROM agent_runs ORDER BY started_at DESC LIMIT 30")
        return {"status": rt.agent.status(), "last": rt.agent.public_result(rt.agent.last_result), "runs": runs}

    @app.get("/api/v1/agent/models")
    async def agent_models():
        return await rt.agent.list_models()

    @app.post("/api/v1/agent/test")
    async def agent_test():
        return await rt.agent.test_connection()

    @app.post("/api/v1/agent/ask")
    def agent_ask(req: AskReq):
        d = rt.engine.current_decision() or {}
        s = d.get("setup") or {}
        rid = rt.agent.request("USER_QUESTION", snapshot_id=d.get("snapshot_id"), setup_id=s.get("setup_id") if s.get("state") in
                               ("EARLY_SETUP", "QUALIFIED", "ARMED", "TRIGGERED", "CONFIRMED") else None, setup_state=s.get("state"), question=req.question)
        return {"queued": bool(rid), "request_id": rid}

    @app.post("/api/v1/agent/analyze")
    def agent_analyze():
        d = rt.engine.current_decision() or {}
        s = d.get("setup") or {}
        active = s.get("state") in ("EARLY_SETUP", "QUALIFIED", "ARMED", "TRIGGERED", "CONFIRMED")
        trig = "SETUP_CONFIRMED" if s.get("state") == "CONFIRMED" else "MANUAL"
        rid = rt.agent.request(trig, snapshot_id=d.get("snapshot_id"), setup_id=s.get("setup_id") if active else None, setup_state=s.get("state"))
        return {"queued": bool(rid), "request_id": rid}

    @app.get("/api/v1/agent/memory")
    def agent_memory():
        return rt.db.query("SELECT * FROM agent_memory ORDER BY id DESC LIMIT 100")

    @app.post("/api/v1/agent/memory/{mid}")
    def agent_memory_set(mid: int, req: MemoryReq):
        if req.status not in ("ACCEPTED_FOR_OOS_TEST", "REJECTED", "PROPOSED"):
            raise HTTPException(400, "INVALID_STATUS")
        rt.db.execute("UPDATE agent_memory SET status=? WHERE id=?", (req.status, mid))
        rt.log.info("AGENT", "MEMORY_STATUS", f"Propozycja {mid}: {req.status} (nie zmienia strategii LIVE)")
        return {"ok": True}

    # ------------------------------------------------------------ modes & execution
    @app.post("/api/v1/mode")
    def set_mode(req: ModeReq):
        try:
            return rt.modes.set_mode(req.mode, confirm=req.confirm, account=rt.bridge.account_status(), account_key=rt.bridge.account_key,
                                     synthetic=rt.bridge.synthetic)
        except ModeError as exc:
            raise HTTPException(400, str(exc)) from exc
        finally:
            rt.engine.mark_dirty()

    # ------------------------------------------------------------ AUTO strategy selection (separate from order execution)
    def media_dir():
        d = paths.data_dir() / "assets" / "masterquo"
        d.mkdir(parents=True, exist_ok=True)
        return d

    @app.get("/api/v1/strategy/auto")
    def strategy_auto():
        return rt.engine.active.status()

    @app.post("/api/v1/strategy/mode")
    def strategy_mode(req: StrategyModeReq):
        if req.strategy_mode == "MANUAL" and not req.manual_strategy_id:
            raise HTTPException(400, "MANUAL_REQUIRES_STRATEGY_ID")
        try:
            rt.cfg.update({"active": {"strategy_mode": req.strategy_mode,
                                      "manual_strategy_id": req.manual_strategy_id if req.strategy_mode == "MANUAL" else None}})
        except Exception as exc:
            raise HTTPException(400, f"INVALID: {exc}") from exc
        # legacy switch -> the same per-account setup view the engine uses (one source)
        rt.prefs.set("setup_view", {"mode": "SELECTED" if req.strategy_mode == "MANUAL" else "AUTO", "strategy_id": req.manual_strategy_id})
        rt.engine.active.selector.reset("STRATEGY_MODE_CHANGED")
        rt.log.info("AUTO", "STRATEGY_MODE", f"Wybór strategii: {req.strategy_mode}" + (f" ({req.manual_strategy_id})" if req.strategy_mode == "MANUAL" else "")
                    + ". Tryb wykonywania zleceń bez zmian.")
        rt.engine.mark_dirty()
        return rt.engine.active.status(compact=True)

    # ------------------------------------------------------------ setup view + leverage (per account) and scenario details
    @app.get("/api/v1/prefs")
    def prefs_get():
        from ..prefs import LEVERAGE_CHOICES
        return {**rt.prefs.all(), "exposure": rt.prefs.exposure_limit(), "leverage_choices": list(LEVERAGE_CHOICES)}

    @app.post("/api/v1/prefs/setup-view")
    def prefs_setup_view(req: SetupViewReq):
        from ..prefs import PrefsError
        try:
            v = rt.prefs.set("setup_view", req.model_dump())
        except PrefsError as exc:
            raise HTTPException(400, str(exc)) from exc
        if v["mode"] != "ALL":
            rt.engine.active.selector.reset("SETUP_VIEW_CHANGED")
        rt.log.info("AUTO", "SETUP_VIEW", f"Wybór setupu: {v['mode']}" + (f" {v['strategy_id']}" if v["mode"] == "SELECTED" else "")
                    + " (nie wymusza sygnału ani zlecenia; wszystkie filtry obowiązują).")
        return prefs_get()

    @app.post("/api/v1/prefs/leverage")
    def prefs_leverage(req: LeverageReq):
        from ..prefs import PrefsError
        try:
            v = rt.prefs.set("leverage", req.model_dump())
        except PrefsError as exc:
            raise HTTPException(400, str(exc)) from exc
        rt.log.info("RISK", "LEVERAGE_LIMIT", ("Limit ekspozycji: AUTO (dźwignia rachunku z MT5)" if v["mode"] == "AUTO" else f"Limit ekspozycji ustawiony w bocie: 1:{v['limit']}")
                    + " – nie zmienia dźwigni u brokera; dotyczy przyszłych decyzji, istniejące pozycje bez zmian.")
        return prefs_get()

    @app.get("/api/v1/setups")
    def setups_list(include_terminal: bool = True):
        from ..engine import setup_details
        return setup_details.scenarios(rt.engine, include_terminal=include_terminal)

    @app.get("/api/v1/setups/{setup_id}/details")
    def setup_detail(setup_id: str):
        from ..engine import setup_details
        if len(setup_id) > 120:
            raise HTTPException(400, "SETUP_ID_INVALID")
        out = setup_details.details(rt.engine, setup_id)
        if out is None:
            raise HTTPException(404, "SETUP_NOT_FOUND")
        return out

    # ------------------------------------------------------------ ML (Decision Tree + XGBoost)
    @app.get("/api/v1/ml/status")
    def ml_status():
        return rt.ml.status()

    @app.post("/api/v1/ml/mode")
    def ml_mode(req: MLModeReq):
        try:
            return rt.ml.set_mode(req.mode)
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc

    @app.post("/api/v1/ml/collect")
    def ml_collect(req: MLFlagReq):
        return rt.ml.set_collect(req.on)

    @app.post("/api/v1/ml/pause")
    def ml_pause(req: MLFlagReq):
        return rt.ml.set_paused(req.on)

    @app.post("/api/v1/ml/train")
    def ml_train(req: MLTrainReq | None = None):
        """'Trenuj teraz': skips the waiting time/new-label threshold but never the data minimums of the validation blocks."""
        if rt.cfg.get().ml.training_paused:
            raise HTTPException(409, "TRAINING_PAUSED")
        res = rt.ml.start_training("USER", force=True, include_approx=req.include_approx if req else None)
        rt.bus.publish("ml", rt.ml.status(compact=True))
        return res

    # ------------------------------------------------------------ training installer (same backend as the BAT launchers)
    @app.get("/api/v1/training")
    def training_state():
        from ..training import core as tc
        rid = tc.Run.latest()
        st = tc.Run.load(rid).state if rid else None
        if st:
            from ..training.report import summary
            st = dict(st, summary=summary(st))
        return {"run": st, "profiles": {k: v["label"] for k, v in tc.profiles().items()}}

    @app.post("/api/v1/training/start")
    def training_start(body: dict):
        """Starts `masterquo training run` as a separate process (never inside the bot process; no orders, lock untouched)."""
        import subprocess
        from ..training import core as tc
        insts = ",".join(i for i in ("XAUUSD", "BTC") if i in (body.get("instruments") or []))
        if not insts:
            raise HTTPException(400, "NO_INSTRUMENT")
        prof = body.get("profile") or "PELNY_TRENING"
        if prof not in tc.profiles():
            raise HTTPException(400, "BAD_PROFILE")
        cmd = [sys.executable, "-m", "masterquo", "training", "run", "--instruments", insts, "--profile", prof, "--origin", "panel"]
        for k, flag in (("months", "--months"), ("symbol_xauusd", "--symbol-xauusd"), ("symbol_btc", "--symbol-btc"),
                        ("commission_xauusd", "--commission-xauusd"), ("commission_btc", "--commission-btc")):
            if body.get(k) not in (None, ""):
                cmd += [flag, str(body[k])]
        if rt.demo:
            cmd.append("--demo")
        held = None
        try:
            import json as _j
            cur = _j.loads(tc.lock_path().read_text(encoding="utf-8"))
            held = cur.get("run_id") if tc._pid_alive(int(cur.get("pid", 0))) else None
        except (OSError, ValueError):
            pass
        if held:
            return {"started": False, "reason": f"TRAINING_ALREADY_RUNNING:{held}"}
        log = open(tc.training_dir() / "panel_start.log", "a", encoding="utf-8")
        kw = {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)} if os.name == "nt" else {"start_new_session": True}
        subprocess.Popen(cmd, cwd=str(paths.ROOT_DIR / "backend"), env=dict(os.environ, MQ_NO_BROWSER="1"), stdout=log, stderr=subprocess.STDOUT, **kw)
        return {"started": True}

    @app.post("/api/v1/training/cancel")
    def training_cancel():
        from ..training import core as tc
        rid = tc.Run.latest()
        if not rid:
            return {"ok": False, "reason": "NO_RUN"}
        (tc.runs_dir() / rid / "CANCEL").write_text(tc.now(), encoding="utf-8")
        return {"ok": True, "run_id": rid}

    @app.get("/api/v1/training/active")
    def training_active(instrument: str = Query(...)):
        import json as _j
        import mq_instruments as mi
        from ..lab.protocol import read_pointer
        from ..ml.router import ml_store
        if instrument not in mi.profiles():
            raise HTTPException(400, "UNKNOWN_INSTRUMENT")
        out = {}
        for fam in ("forecast", "scalp"):
            try:
                reg = _j.loads((mi.root(fam, instrument) / "registry.json").read_text(encoding="utf-8"))
                e = (reg.get("runs") or {}).get(reg.get("active") or "", {})
                out[fam] = {"active": reg.get("active"), "status": e.get("overall_status") or e.get("task_a_status"), "history": (reg.get("history") or [])[-3:]}
            except (OSError, ValueError):
                out[fam] = {"active": None}
        if instrument == rt.ml.inst:
            out["ml"] = {"active": rt.ml.registry.champion_id}
        else:
            db, root = ml_store(instrument, rt.db)
            row = db.one("SELECT model_id FROM ml_models WHERE status='CHAMPION'")
            out["ml"] = {"active": row["model_id"] if row else None}
        ptr = read_pointer(paths.data_dir() / "lab", instrument)
        out["lab"] = {"pinned": ptr["active"], "models": [{k: m.get(k) for k in ("model_id", "family", "role", "verdict")} for m in rt.lab.trainer.models(instrument)][:20]}
        return {"instrument": instrument, "families": out}

    @app.post("/api/v1/training/rollback")
    def training_rollback(body: dict):
        import subprocess
        inst, fam = body.get("instrument"), str(body.get("family") or "")
        if inst not in ("XAUUSD", "BTC") or not (fam in ("forecast", "scalp", "ml") or fam.startswith("lab:")):
            raise HTTPException(400, "BAD_REQUEST")
        if fam == "ml" and inst == rt.ml.inst:
            try:
                return {"ok": True, "result": rt.ml.rollback()}
            except ValueError as exc:
                return {"ok": False, "reason": str(exc)}
        r = subprocess.run([sys.executable, "-m", "masterquo", "training", "rollback", "--instrument", inst, "--family", fam],
                           cwd=str(paths.ROOT_DIR / "backend"), capture_output=True, text=True, timeout=300)
        rt.forecast.reload()
        return {"ok": r.returncode == 0, "output": (r.stdout + r.stderr)[-800:]}

    @app.post("/api/v1/ml/reload")
    def ml_reload():
        """After offline training (training installer): re-read champion of the active instrument's ML registry."""
        rt.ml.registry.reload()
        rt.ml._pred_cache.clear()
        return {"ok": True, "instrument": rt.ml.inst, "champion": rt.ml.registry.champion_id}

    @app.post("/api/v1/ml/backfill")
    def ml_backfill(req: MLBackfillReq):
        return rt.ml.start_backfill(req.days)

    @app.post("/api/v1/ml/cancel")
    def ml_cancel():
        return rt.ml.cancel()

    @app.post("/api/v1/ml/resume")
    def ml_resume():
        return rt.ml.resume_interrupted()

    @app.post("/api/v1/ml/rollback")
    def ml_rollback():
        try:
            return rt.ml.rollback()
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc

    @app.get("/api/v1/ml/models")
    def ml_models():
        return {"models": rt.ml.registry.models(50), "events": rt.ml.registry.events(50)}

    @app.get("/api/v1/ml/report")
    def ml_report():
        return rt.ml.last_report() or {"available": False, "reason": "NO_COMPLETED_TRAINING"}

    @app.get("/api/v1/ml/explain")
    def ml_explain(setup_id: str = Query(...), version: int = Query(...)):
        return rt.ml.explain(setup_id, version)

    @app.get("/api/v1/ml/predict")
    def ml_predict(setup_id: str = Query(...)):
        row = rt.engine.active.tracker.get(setup_id)
        if not row:
            raise HTTPException(404, "UNKNOWN_SETUP")
        return rt.ml.predict(row, rt.engine.active.view)

    @app.post("/api/v1/strategy/toggle")
    def strategy_toggle(req: StrategyToggleReq):
        from ..strategies import registry as _reg
        if req.strategy_id not in _reg.STRATEGIES:
            raise HTTPException(400, "UNKNOWN_STRATEGY_ID")
        cur = rt.cfg.get().active.strategies.get(req.strategy_id)
        patch = {"scan": cur.scan if cur else True, "trade": cur.trade if cur else True}
        if req.scan is not None:
            patch["scan"] = req.scan
        if req.trade is not None:
            patch["trade"] = req.trade
        rt.cfg.update({"active": {"strategies": {req.strategy_id: patch}}})
        rt.log.info("AUTO", "STRATEGY_TOGGLE", f"{req.strategy_id}: skanuj={'TAK' if patch['scan'] else 'NIE'}, handel={'TAK' if patch['trade'] else 'NIE'}")
        rt.engine.mark_dirty()
        return rt.engine.active.status(compact=True)

    @app.post("/api/v1/strategy/profile")
    def strategy_profile(req: ProfileReq):
        rt.cfg.update({"active": {"profile": req.profile}})
        rt.engine.active.selector.reset("PROFILE_CHANGED")
        rt.log.info("AUTO", "PROFILE", f"Profil wykrywania: {req.profile}")
        rt.engine.mark_dirty()
        return rt.engine.active.status(compact=True)

    @app.get("/api/v1/strategy/selection-log")
    def selection_log(limit: int = 30):
        return {"log": rt.engine.active.selection_log(max(1, min(limit, 200)))}

    @app.get("/api/v1/playbook")
    def playbook(limit: int = 100):
        rows = rt.db.query("SELECT setup_id, strategy_id, strategy_version, direction, timeframe, stage, status, version, score, first_seen_at, first_price, "
                           "updated_at, terminal_reason, terminal_at, synthetic, record_json, history_json FROM strategy_setups ORDER BY first_seen_at DESC LIMIT ?",
                           (max(1, min(limit, 500)),))
        trades = {t["setup_id"]: t for t in rt.db.query("SELECT setup_id, mode, side, net_pnl, gross_pnl, opened_at, closed_at FROM trades WHERE setup_id LIKE 'MQA-%'")}
        out = []
        for r in rows:
            rec = json.loads(r.pop("record_json"))
            hist = json.loads(r.pop("history_json"))
            out.append({**r, "context": {"regime": rec.get("regime"), "horizon": rec.get("horizon"), "countertrend": rec.get("countertrend")},
                        "hypothesis": rec.get("strategy_name"), "plan": {k: rec.get(k) for k in ("entry_plan", "stop_loss", "targets", "invalidation_level", "exit_rules")},
                        "score": rec.get("score"), "missing": rec.get("missing_confirmations"), "history": hist, "result": trades.get(r["setup_id"]) or "brak danych"})
        return {"cards": out, "note": "Karty obejmują także setupy anulowane, unieważnione i wygasłe – nie tylko wybrane sukcesy."}

    @app.get("/api/v1/appearance/assets")
    def appearance_assets():
        out = {}
        for slot, (anim, static_name) in MEDIA_SLOTS.items():
            user = media_dir() / anim
            built = paths.FRONTEND_DIST / "assets" / "masterquo" / anim
            info = gif_info(user.read_bytes()) if user.is_file() else (gif_info(built.read_bytes()) if built.is_file() else None)
            out[slot] = {"animated_available": user.is_file() or built.is_file(), "source": "USER_UPLOAD" if user.is_file() else ("BUILT_IN" if built.is_file() else "NONE"),
                         "animated_url": f"/media/masterquo/{slot}?v={int(user.stat().st_mtime) if user.is_file() else 0}",
                         "static_url": f"/static/assets/masterquo/{static_name}", "gif": info}
        return out

    @app.post("/api/v1/appearance/upload")
    async def appearance_upload(request: Request, slot: str = Query(..., pattern="^(background|frog)$")):
        data = await request.body()
        if len(data) > MAX_GIF_BYTES:
            raise HTTPException(413, "FILE_TOO_LARGE")
        info = gif_info(data)
        if not info:
            raise HTTPException(400, "NOT_A_GIF")
        target = media_dir() / MEDIA_SLOTS[slot][0]
        tmp = target.with_suffix(".tmp")
        tmp.write_bytes(data)
        tmp.replace(target)
        rt.log.info("UI", "ASSET_UPLOADED", f"Wgrano GIF ({slot}): {info['width']}×{info['height']}, {info['frames']} klatek, pętla {info['loop_duration_ms']} ms")
        return {"ok": True, "slot": slot, "gif": info}

    @app.get("/media/masterquo/{slot}")
    def media(slot: str):
        if slot not in MEDIA_SLOTS:
            raise HTTPException(404)
        name = MEDIA_SLOTS[slot][0]
        for f in (media_dir() / name, paths.FRONTEND_DIST / "assets" / "masterquo" / name):
            if f.is_file():
                return FileResponse(f, media_type="image/gif", headers={"Cache-Control": "no-cache"})
        raise HTTPException(404)

    @app.post("/api/v1/auto")
    def set_auto(req: OnReq):
        try:
            return rt.modes.set_auto(req.on)
        except ModeError as exc:
            raise HTTPException(400, str(exc)) from exc

    @app.post("/api/v1/kill")
    def kill(req: OnReq):
        st = rt.modes.set_kill(req.on, req.reason)
        rt.engine.mark_dirty()
        return st

    @app.post("/api/v1/execute")
    def execute(req: ExecReq):
        return rt.gateway.execute(req.decision_id, initiated_by="USER")

    @app.post("/api/v1/positions/close")
    def close_positions(req: CloseReq):
        if req.confirm != "ZAMKNIJ":
            raise HTTPException(400, "CONFIRMATION_REQUIRED_TYPE_ZAMKNIJ")
        return rt.manager.close_positions(req.scope, req.ticket)

    @app.post("/api/v1/positions/{ticket}/adopt")
    def adopt(ticket: int, req: CloseReq):
        if req.confirm != "PRZEJMIJ":
            raise HTTPException(400, "CONFIRMATION_REQUIRED_TYPE_PRZEJMIJ")
        return rt.manager.adopt(ticket)

    @app.post("/api/v1/mt5/reconnect")
    def reconnect():
        rt.bridge.state = "RECONNECTING"
        rt.bridge.next_retry = 0
        return {"ok": True}

    @app.post("/api/v1/news/refresh")
    def news_refresh():
        rt.news.refresh_now()
        return {"ok": True}

    @app.get("/api/v1/diagnostics")
    def diagnostics():
        from ..runtime import platform_info
        b = rt.bridge
        raw = {tf: [x["t_raw"] for x in b.bars(tf, limit=4)] for tf in TIMEFRAMES}
        return {"app": {"version": APP_VERSION, "contract": API_CONTRACT_VERSION, "synthetic": rt.demo}, "platform": platform_info(),
                "connection": b.connection_status(), "symbol": b.symbol_status_dict(), "tf_meta": b.tf_meta(),
                "raw_last_bar_opens": raw, "quote": b.quote_status(), "pc_clock": rt.pcclock.snapshot(),
                "worker": {"calls": rt.worker.calls, "failures": rt.worker.failures, "module_error": rt.worker.module_error},
                "db_schema": rt.db.schema_versions(), "agent": rt.agent.status(), "news": {k: v for k, v in rt.news.summary().items() if k in ("status", "error", "failed_sources")},
                "engine": {"last_error": rt.engine.last_error, "cycle_ms": rt.engine.cycle_ms, "required_bars": rt.engine.required}}

    @app.post("/api/v1/admin/shutdown")
    async def shutdown():
        rt.log.info("APP", "SHUTDOWN_REQUEST", "Żądanie zatrzymania aplikacji")
        loop = asyncio.get_running_loop()
        loop.call_later(0.5, rt.request_shutdown)
        return {"ok": True}

    # ------------------------------------------------------------ websocket
    @app.websocket("/api/v1/ws")
    async def ws(websocket: WebSocket):
        if not sec.host_ok(websocket.headers.get("host")) or not sec.origin_ok(websocket.headers.get("origin")):
            await websocket.close(code=4403)
            return
        sid = websocket.cookies.get(SESSION_COOKIE)
        await websocket.accept()
        try:
            hello = json.loads(await asyncio.wait_for(websocket.receive_text(), timeout=10))
        except (asyncio.TimeoutError, ValueError, WebSocketDisconnect):
            await websocket.close(code=4400)
            return
        if not sec.csrf_ok(sid, hello.get("csrf")):
            await websocket.close(code=4403)
            return
        queue: asyncio.Queue = asyncio.Queue(maxsize=2000)
        unsub = rt.bus.subscribe_async(asyncio.get_running_loop(), queue)
        try:
            last = hello.get("last_seq")
            replay = rt.bus.since(int(last)) if isinstance(last, int) and hello.get("boot_id") == rt.bus.boot_id else None
            if replay is None:
                await websocket.send_text(json.dumps({"type": "resync", "seq": rt.bus.seq, "boot_id": rt.bus.boot_id, "state": full_state()}, default=str))
            else:
                for ev in replay:
                    await websocket.send_text(json.dumps(ev, default=str))
            while True:
                ev = await queue.get()
                if ev.get("type") == "__overflow__":
                    while not queue.empty():
                        queue.get_nowait()
                    await websocket.send_text(json.dumps({"type": "resync", "seq": rt.bus.seq, "boot_id": rt.bus.boot_id, "state": full_state()}, default=str))
                    continue
                await websocket.send_text(json.dumps(ev, default=str))
        except (WebSocketDisconnect, RuntimeError):
            pass
        finally:
            unsub()

    return app
