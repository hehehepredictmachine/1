# Powrót do poprzedniej konfiguracji

## 0e. Wersja 1.40.0 → 1.39.0 (Granite TTM, Memory Governor, nowy WTC$PEPE)
1. **Bez cofania wersji**: Granite TTM wyłączysz w panelu „Modele prognoz” (lub `data/tsfm/settings.json` → `"granite_ttm": {"enabled": false}`);
   dotrenowany checkpoint → „Powrót do BASE”. Memory Governor: profil BALANCED albo MANUAL z `"auto_throttle": false`.
2. **Pełny powrót**: STOP, zamknij 1.40. Przywróć `data/config.v14.bak.json` jako `data/config.json` (1.39 nie zna sekcji `resources`) oraz
   `data/tsfm/settings.v139.bak.json` jako `data/tsfm/settings.json` (z wpisem FinCast). Uruchom folder 1.39.0 i, jeśli chcesz FinCast, zainstaluj go
   `38_MODELE_CHRONOS2_FINCAST.bat` z folderu 1.39 (wagi ~4 GB). Baza (`tsfm_forecasts`) jest zgodna – 1.40 nie zmienia jej schematu; prognozy Granite
   zostają w historii pod `granite_ttm` (1.39 je ignoruje).
3. Do usunięcia (opcjonalnie): `.venv_granite`, `data/tsfm/models/granite_ttm`, `data/tsfm/finetuned/granite_ttm`, `data/tsfm/granite_data`.
4. Kod: tag git `pre-1.40-restore-point` wskazuje wydanie 1.39.0.

## 0d. Wersja 1.39.0 → 1.38.0 (LIVE od startu, GARCH, menu Galaxy, WTC 2.1)
1. **Tylko wyłączenie LIVE (bez cofania wersji)**: przycisk STOP, potem w `data/config.json` → `"execution": {"start_mode": "SIGNALS",
   "live_autobind": false}` (albo `"start_mode": null` = ostatni zapisany tryb) i restart. Bramek walidacji nie da się przywrócić
   konfiguracją – do tego potrzebna jest wersja 1.38.
2. **GARCH**: panel Strategie → Pakiet 20 → „PMW_HG09 – zmienność” → „odchylenie 60 × M5” (albo `POST /api/v1/sh/strategies/config`
   z `volatility_method: "STD_LOGRET_60_M5"`). 1.38 nie zna wartości `VOL_GARCH` – przed powrotem przełącz z powrotem, inaczej katalog 1.38
   odrzuci nadpisanie (`data/sh/pack_override.json`).
3. **Pełny powrót**: STOP, zamknij 1.39, przywróć `data/config.v13.bak.json` jako `data/config.json` (1.38 nie czyta konfiguracji v14),
   uruchom folder 1.38. Baza bez nowych migracji w 1.39 – zgodna. Układ menu Galaxy (`PMW_GALAXY_LIVE_V1`) i presety Chart Lab
   (`mq.wtc.chartlab.*`) są w pamięci przeglądarki – 1.38 je ignoruje.
4. Menu: w 1.39 dawne menu Neural City jest pod `#/neural-city`; w 1.38 pod `#/menu`.

## 0c. Wersja 1.38.0 → 1.37.0 (pakiet 20 strategii)
1. Bez cofania wersji: wyłącz warianty w `POST /api/v1/sh/strategies/config` (`{"variants": {"PMW_SC01": {"enabled": false}, ...}}`) –
   wyłączony wariant nie generuje kandydatów; legacy SCALPING/HEDGING działają jak w 1.37. Otwarte plany pakietu są dalej zarządzane do
   zamknięcia (TP/SL/czas/koszyk) – nie są porzucane.
2. Pełny powrót: zamknij plany pakietu (panel Strategie → pozycja / `POST /api/v1/sh/plans/<id>/close`), zamknij 1.38 i uruchom 1.37.0.
   Migracja 0027 jest addytywna (kolumny `strategy_id`, `signal_tf`) – 1.37 je ignoruje. Plany pakietu w bazie 1.37 traktuje jak plany
   rodziny (strategy = SCALPING/HEDGING), ale nie zna ich polityk – dlatego zamknij je przed powrotem.
3. Pliki 1.38 do usunięcia (opcjonalnie): `data/sh/pack_override.json`, `data/sh/pack_validation/`.

## 0b. Wersja 1.37.0 → 1.36.0
1. Zamknij 1.37. Uruchom 1.36.0 z jej folderu – konfiguracja `config.json` jest wspólna (1.37 nie dodaje sekcji do `config.json`).
2. Baza może zostać: migracja 0026 (`tsfm_forecasts`) jest addytywna, 1.36 jej nie czyta. Plik `data/tsfm/settings.json` i raporty
   `data/tsfm/reports` 1.36 ignoruje.
3. **Kronos**: 1.37 przełącza manifest wag na Kronos-base. W 1.36 uruchom `33_KRONOS_INSTALUJ.bat` z folderu 1.36 – instalator 1.36 ponownie
   sprawdzi / pobierze Kronos-small i zapisze jego manifest. Do tego czasu 1.36 pokazuje „brak zweryfikowanych wag” (nie liczy na złym modelu).
4. Środowiska `.venv_chronos2`, `.venv_fincast` i wagi w `data/tsfm/models` można usunąć ręcznie (środowisko ok. 1,3–1,5 GB każde; wagi Chronos-2 ok. 0,5 GB, FinCast ok. 3,7 GB).
5. Wyłączenie bez cofania wersji: w panelu „Modele prognoz” zostaw rolę „obserwacja” (domyślna) albo wyłącz model w `data/tsfm/settings.json`
   (`"enabled": false`) – wtedy nie wpływa na żadną decyzję.

## 0a. Wersja 1.34.0 → 1.33.0
1.34 zmienia tylko interfejs (menu główne Neural City, launcher). Konfiguracja i baza danych są bez zmian, więc wystarczy uruchomić
1.33.0 z jej folderu. Ustawienia animacji menu leżą wyłącznie w pamięci przeglądarki / okna i 1.33 ich nie czyta.

## 0. Wersja 1.33.0 → 1.32.0
Pełna instrukcja: `docs/AKTUALIZACJA_1_33_PL.md`. W skrócie:
1. Zamknij 1.33.
2. W folderze danych zmień nazwę `config.json` na `config.v13.json` i skopiuj `config.v12.bak.json` jako `config.json`. 1.32 odrzuca nowe
   sekcje `indicators` / `families` / `decision`.
3. Uruchom 1.32.0. Baza może zostać: migracja 0025 jest addytywna, a 1.32 ignoruje nowe tabele.

## 1. Profil ORIGINAL (bez reinstalacji)
Wykrywanie wraca do dotychczasowego M07/M10A (jak w wersji 1.1). Tryb pracy, limity i historia zostają.
* w monitorze: ⚙ Ustawienia → **AUTO / ACTIVE** → Profil wykrywania = `ORIGINAL` → Zapisz, albo
* zatrzymaj program (`04_STOP_MASTERQUO.bat`) i uruchom `08_PROFIL_ORIGINAL.bat` (ponowne włączenie: `08_PROFIL_ORIGINAL.bat ACTIVE`).
Kopia ustawień obu profili: `config/profiles/ACTIVE.json`, `config/profiles/ORIGINAL.json` (fragmenty sekcji `active`).

## 2. Łagodne bramki 1.1 → ścisłe reguły MasterQUO 1.0
Ustawienia → Strategia M07 → Kierunek struktury `STRICT_H4_H1`; Ryzyko → RR 1,5 / 2,0 i „RR pomiędzy progami” wyłączone;
Agent Claude → Rola AI `REQUIRED`; Ryzyko → „Brak kalendarza makro blokuje wejścia” włączone.

## 3. Poprzednia wersja programu
Rozpakuj poprzedni ZIP do osobnego folderu. Baza `data/masterquo.sqlite` jest migrowana (0002 dodaje tabele, niczego nie usuwa);
kopia sprzed migracji: `data/backups/`. Wersja 1.1 ignoruje nowe tabele. Plik `data/config.json` z sekcją `active` należy w 1.1
zastąpić kopią z `data/backups/` albo usunąć sekcję `active` (1.1 odrzuca nieznane pola).

## 4. Wygląd
Ustawienia → Wygląd → OFF (statyczne kadry). Wgrane GIF-y: usuń pliki z `data/assets/masterquo/`.

## 5. Wersja 1.3.1 → 1.3.0
* Strefy można wyłączyć bez cofania wersji: przełącznik „IV walls / Daily” albo `"volatility": {"enabled": false}`.
* Powrót do 1.3.0: 1.3.1 zapisuje `config_version: 5` i sekcję `volatility` – przed uruchomieniem 1.3.0 usuń tę sekcję
  i ustaw `"config_version": 3` (albo przywróć `data\config.json` z kopii). Baza danych nie została zmieniona.

## 6. Wersja 1.6.0 → 1.3.1
* Bez cofania wersji: skaner i sygnały wyłączysz w **Ustawienia → Rynki / Sygnały bota** (`markets.enabled`, `signals.enabled`).
* Powrót do 1.3.1: usuń z `data\config.json` sekcje `markets` i `signals` i ustaw `"config_version": 5`. Tabela sygnałów (migracje 0005, 0006)
  nie przeszkadza wersji 1.3.1; kopia bazy sprzed migracji jest w `data\backups\`.

## 7. Wersja 1.7.0 → 1.6.0
* Punkt powrotu: przed migracją 0007 program kopiuje bazę do `data\backups\` (jak przy poprzednich migracjach); `data\config.json`
  z wersji 1.6 – zachowaj kopię przed pierwszym startem 1.7 (1.7 zapisuje `config_version: 8`, dodaje `license` i przełącznik S11).
* Powrót: rozpakuj ZIP 1.6.0 do osobnego folderu, przywróć `data\config.json` z kopii (albo usuń sekcję `license`, wpis `S11`
  w `active.strategies` i ustaw `"config_version": 6`). Tabela `signal_history` i kolumna `ai_verdict` (0007) nie przeszkadzają 1.6.

## 8. Wersja 1.9.0 → 1.8.0
* 1.9.0 usuwa licencjonowanie i zapisuje `config_version: 9` (bez sekcji `license`); baza bez nowych migracji.
* Powrót do 1.8.0 (wymaga licencji i serwera licencji): rozpakuj ZIP 1.8.0 do osobnego folderu i przywróć kopię `data\config.json`
  sprzed 1.9 albo ustaw `"config_version": 8` – 1.8 poprosi o konfigurację serwera licencji przy starcie.

## 9. Wersja 1.10.0 → 1.9.0
* 1.10.0 zapisuje `config_version: 10` (sekcja `walls`, wpis `S12` w `active.strategies`) i dodaje migracje bazy **0009** (polityka wyjścia,
  stan TP1, `trades.status`) i **0010** (`iv_observations`, `walls_snapshots`) – tylko nowe kolumny i tabele; kopia bazy sprzed migracji w `data\backups\`.
* Bez cofania wersji: S12 wyłączysz w Ustawienia → AUTO / ACTIVE (domyślnie i tak tylko skanuje); źródło walls ustawisz w `"walls": {"source": "HV_PROXY"}`
  (walls są wejściem tylko dla S12 i wykresów, nie zmieniają S01–S11).
* Powrót: rozpakuj ZIP 1.9.0 do osobnego folderu, przywróć `data\config.json` z kopii sprzed 1.10 (albo usuń sekcję `walls`, wpis `S12`
  i ustaw `"config_version": 9`) oraz bazę z `data\backups\` – 1.9 nie zna statusu OPEN_PARTIAL/UNSETTLED i liczyłaby je jak zamknięte.
* Preferencje monitora 1.10 (strony, układy, widoki `ai-*`/`bot-*`) są w przeglądarce; 1.9 ich nie używa, a jej widoki `panelN` zostały zachowane.

## 11. Wersja 1.25.0 → 1.24.1
* Punkt powrotu w repozytorium: commit `a10d97a` (wydanie 1.24.1). Kod eksportu sprzed zmian (użyty w porównaniu przed/po): `0a57370`.
  1.25 nie zmienia schematu konfiguracji (`config_version` 12) ani nie dodaje migracji bazy – powrót = uruchomienie paczki 1.24.1 na tych
  samych danych.
* Nowe pliki danych, które 1.24.1 ignoruje: `data\montecarlo\` (walidacje i kalibracje Monte Carlo), w eksportach `EXPORT_STATUS.json`,
  `MODEL_DATA_READINESS.json`, `ticks\`. Eksport 1.25 ma dodatkową kolumnę `real_volume` na końcu CSV – czytniki 1.24 biorą kolumny po
  nazwie i jej nie używają.
* Bez cofania wersji: kalibracja Monte Carlo – `python -m masterquo montecarlo rollback --instrument XAUUSD` (wraca do poprzedniej
  aktywnej albo do „bez kalibracji”); TP3 SCALPING – Strategie → Ustawienia SCALPING → TP3 5 USD albo „Przywróć poprzednią”
  (`POST /api/v1/sh/config/rollback`). Scenariusz 2,5–10 USD niczego nie zleca – nie wymaga wyłączania.

## 10. Wersja 1.24.0 → 1.23.x
* Punkt powrotu w repozytorium: commit `ba7a5d5` (stan przed przebudową desktop; lokalny tag `pre-desktop-1.23.0`). 1.24 nie dodaje migracji bazy.
* Konfiguracja: 1.24 zapisuje `config_version: 12` (Execution Lock wycofany, pole `execution.mode_note`, Telegram: `send_trades`,
  `send_stats`, `stats_hour_utc`, `language`). Kopia sprzed migracji: `data\config.v11.bak.json` – przed uruchomieniem 1.23 przywróć ją
  jako `data\config.json` (1.23 odrzuca nieznane pola).
* Aplikacja `PepeMarketWizardDesktop.exe` pracuje na kopii danych w `%LOCALAPPDATA%\PepeMarketWizard\data` – stary folder
  instalacji zostaje bez zmian, więc powrót = uruchomienie poprzedniej wersji z tamtego folderu. Kopie danych sprzed aktualizacji
  aplikacji: `%LOCALAPPDATA%\PepeMarketWizard\backups\<RRRRMMDD_GGMMSS>_<etykieta>`. Usunięcie aplikacji: Centrum sterowania → Praca aplikacji →
  wyłącz autostart, zamknij aplikację (ikona przy zegarze → Zamknij aplikację) i usuń jej folder; dane w `%LOCALAPPDATA%` usuń ręcznie,
  jeśli nie są potrzebne.
* Bez cofania wersji: strategie „tylko sygnały” (S11, S12) i przełączniki handlu per strategia – Ustawienia → AUTO / ACTIVE;
  polityka AI – Ustawienia → Agent Claude (`VETO` / `REQUIRED`); Telegram – Centrum sterowania → MT5 i połączenia (wyłącz).

## 1.42.8 → 1.42.7 (Kronos-small → Kronos-base)
Wagi Kronos-base zostają w folderze wag (`NeoQuasar__Kronos-base@2b55…`). Po powrocie do 1.42.7 uruchom `33_KRONOS_INSTALUJ.bat` z folderu 1.42.7 –
instalator 1.42.7 pobierze i sprawdzi parę Kronos-base (ok. 420 MB) i zapisze jej manifest.
