"""Local MT5 bridge: connection supervision, exact-symbol checks, quotes, six-timeframe bars,
account/positions/history and heartbeat. All terminal calls go through MT5Worker.

Bars are always collected for M1, M5, M15, H1, H4 and D1 regardless of what the user views.
Closed-bar confirmation rule (unchanged intent of the FUTURE_CANDLE_AVAILABILITY fix): a bar is
CLOSED only when the *next* bar of the same timeframe has actually been observed in the
terminal. `available_at` is the moment we observed that next bar (basis OBSERVED); for bars that
were already closed in the initial history load it is the next bar's open time
(basis HISTORICAL_ESTIMATE - the earliest moment the close could have been known).
"""
from __future__ import annotations

import logging
import os
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Callable

from ..config import ConfigStore
from ..timeutil import TF_REGISTRY, TF_SECONDS, TIMEFRAMES, UTC, from_epoch, iso, utcnow
from .clock import ServerClock
from .worker import PRIO_HISTORY, PRIO_QUOTE, MT5Busy, MT5CallTimeout, MT5Worker, MT5WorkerUnavailable

log = logging.getLogger("masterquo.mt5.bridge")

TF_CONST = {tf: v["mt5"] for tf, v in TF_REGISTRY.items()}       # MetaTrader5 constants (never minutes as an enum)
# Poll cadence per timeframe (seconds). Higher TFs change rarely.
TF_POLL = {"M1": 1.0, "M3": 1.5, "M5": 2.0, "M15": 3.0, "M30": 4.0, "H1": 5.0, "H4": 10.0, "H8": 12.0, "D1": 15.0}
# Controlled fallback when the terminal returns no native bars for a timeframe: (source TF, bars per bucket).
# Buckets are anchored on the broker server day (raw server epochs), like MT5's own H8 bars (00/08/16 server time).
RESAMPLE_FROM = {"H8": ("H1", 8), "M3": ("M1", 3)}     # fallback only when the terminal has no native series
TRADE_MODE = {0: "DEMO", 1: "CONTEST", 2: "REAL"}
MARGIN_MODE = {0: "NETTING", 1: "EXCHANGE", 2: "HEDGING"}


def _row(r) -> dict:
    if hasattr(r, "_asdict"):
        return r._asdict()
    if hasattr(r, "dtype") and getattr(r.dtype, "names", None):
        return {k: (r[k].item() if hasattr(r[k], "item") else r[k]) for k in r.dtype.names}
    return dict(r)


@dataclass
class Bar:
    t_raw: int
    o: float
    h: float
    l: float
    c: float
    tv: int
    rv: int
    spread: int
    closed: bool = False
    available_raw_next_open: int | None = None  # raw open of the observed next bar
    observed_close_utc: datetime | None = None   # when we observed the next bar (live)
    basis: str = "FORMING"                       # FORMING | OBSERVED | HISTORICAL_ESTIMATE
    revision: int = 0
    source: str = "native"                       # native | resampled (see RESAMPLE_FROM)
    parts: int | None = None                     # resampled: number of source bars in the bucket
    complete: bool | None = None                 # resampled: all source bars of the bucket present (None = native bar)

    def same_values(self, other: "Bar") -> bool:
        return (self.o, self.h, self.l, self.c, self.tv) == (other.o, other.h, other.l, other.c, other.tv)


@dataclass
class TFState:
    bars: list[Bar] = field(default_factory=list)
    last_poll: float = 0.0
    revisions: int = 0
    gap_fills: int = 0
    last_error: str | None = None
    loaded: bool = False


class BridgeError(RuntimeError):
    pass


class _NoLogin:
    """Config view without login/server: attach to the terminal's own logged-in session."""
    def __init__(self, cfg):
        self.terminal_path = cfg.terminal_path
        self.login = self.server = None


class MarketBridge:
    def __init__(self, config: ConfigStore, worker: MT5Worker, db, bus, applog,
                 clock_fn: Callable[[], datetime] = utcnow, required_bars: dict[str, int] | None = None):
        self.cfg_store = config
        self.worker = worker
        self.db = db
        self.bus = bus
        self.log = applog
        self.now = clock_fn
        self.required_bars = required_bars or {tf: 260 for tf in TIMEFRAMES}
        self.clock = ServerClock()
        self._lock = threading.RLock()
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self.state = "DISCONNECTED"
        self.state_reason: str | None = "NOT_STARTED"
        self.session_epoch = 0
        self.terminal: dict | None = None
        self.account: dict | None = None
        self.account_key: str | None = None
        self.symbol_info: dict | None = None
        self.symbol_status = "UNKNOWN"
        self.symbol_candidates: list[str] = []
        self.quote: dict | None = None
        self.tfs: dict[str, TFState] = {tf: TFState() for tf in TIMEFRAMES}
        self.dxy: TFState = TFState()
        self.dxy_status = "NOT_CONFIGURED"
        self.positions: list[dict] = []
        self.orders: list[dict] = []
        self.deals: list[dict] = []
        self.deals_loaded_at: datetime | None = None
        self.last_heartbeat: datetime | None = None
        self.connected_since: datetime | None = None
        self.attempts = 0
        self.next_retry = 0.0
        self.consecutive_errors = 0
        self._last_ok = time.monotonic()
        self.disconnect_grace_s = 20.0
        self.busy_waits = 0
        self.errors: list[dict] = []
        self.listeners: list[Callable[[str, dict], None]] = []
        self._last_quote_pub = 0.0
        self._last_bar_pub: dict[str, float] = {}
        self._t_account = self._t_quote = self._t_hist = self._t_hb = 0.0
        self._synthetic = False
        self.secrets = None                       # SecretStore (runtime) - only for the optional MT5_PASSWORD
        self.login_info: dict = {"mode": "TERMINAL_SESSION", "terminal_path": None, "credentials_rejected": False,
                                 "running_terminals": [], "hint": None}
        self._rejected_creds: str | None = None
        self._detected_path: str | None = None
        self._running: tuple[float, list[str]] = (0.0, [])
        self.assets = None                        # AssetRegistry (runtime): two-asset allowlist on every data input
        self.buffer_symbol: str | None = None     # symbol the TF buffers belong to (None while (re)loading)

    # ---------------------------------------------------------------- helpers
    @property
    def cfg(self):
        return self.cfg_store.get().mt5

    def _call(self, fn, prio=PRIO_QUOTE):
        return self.worker.call(fn, priority=prio, timeout=self.cfg.call_timeout_seconds)

    def add_listener(self, fn: Callable[[str, dict], None]) -> None:
        self.listeners.append(fn)

    def _notify(self, kind: str, data: dict) -> None:
        for fn in list(self.listeners):
            try:
                fn(kind, data)
            except Exception:
                log.exception("bridge listener failed")

    def _error(self, code: str, detail: str | None = None) -> None:
        with self._lock:
            self.errors.append({"ts": iso(self.now()), "code": code, "detail": detail})
            self.errors = self.errors[-50:]

    def _set_state(self, state: str, reason: str | None) -> None:
        changed = (state, reason) != (self.state, self.state_reason)
        self.state, self.state_reason = state, reason
        if changed:
            self.bus.publish("connection", self.connection_status())
            level = "INFO" if state == "CONNECTED" else "WARNING"
            self.log.write(level, "MT5", state, f"MT5: {state}" + (f" ({reason})" if reason else ""))

    # ---------------------------------------------------------------- lifecycle
    def start(self) -> None:
        self._thread = threading.Thread(target=self._loop, name="mt5-bridge", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
        try:
            self._call(lambda m: m.shutdown())
        except Exception:
            pass

    def _loop(self) -> None:
        while not self._stop.is_set():
            mono = time.monotonic()
            try:
                if self.state != "CONNECTED":
                    if mono >= self.next_retry:
                        self.connect()
                else:
                    self.poll(mono)
                    self.consecutive_errors = 0
            except MT5Busy:
                self.busy_waits += 1                    # long history job in progress: the terminal is alive, not a failure
            except (MT5CallTimeout,) as exc:
                self._handle_failure("TERMINAL_UNRESPONSIVE", str(exc))
            except (BridgeError, MT5WorkerUnavailable) as exc:
                self._handle_failure(type(exc).__name__, str(exc))
            except Exception as exc:  # never let the supervision thread die
                log.exception("bridge loop error")
                self._handle_failure(type(exc).__name__, str(exc))
            self._stop.wait(0.2)

    def _handle_failure(self, code: str, detail: str) -> None:
        self.consecutive_errors += 1
        self._error(code, detail)
        if self.state == "CONNECTED":
            # Slow answers are tolerated: the connection is dropped only when there was no good heartbeat for
            # disconnect_grace_seconds AND a direct terminal probe fails too (no reconnect storm that would
            # reload the whole history and slow the terminal further).
            if time.monotonic() - self._last_ok < self.disconnect_grace_s:
                return
            if self._probe_ok():
                self.consecutive_errors = 0
                self._last_ok = time.monotonic()
                self.log.write("WARNING", "MT5", "MT5_SLOW", f"MT5 odpowiadał wolno ({code}); terminal żyje – połączenie utrzymane.")
                return
        self.attempts += 1
        delay = min(self.cfg.reconnect_max_backoff_seconds, 2.0 ** min(self.attempts, 6))
        self.next_retry = time.monotonic() + delay
        if self.worker.module is None:
            self._set_state("MODULE_MISSING", self.worker.module_error or "MetaTrader5 package not importable")
        else:
            self._set_state("RECONNECTING" if self.connected_since else "DISCONNECTED", f"{code}: {detail}"[:240])
        self.quote = None

    def _probe_ok(self) -> bool:
        try:
            t = self.worker.call(lambda m: m.terminal_info(), priority=0, timeout=max(5.0, self.cfg.call_timeout_seconds))
            return t is not None and bool(_row(t).get("connected"))
        except Exception:  # noqa: BLE001
            return False

    # ---------------------------------------------------------------- connect
    def _password(self) -> str | None:
        try:
            return self.secrets.get("MT5_PASSWORD") if self.secrets is not None else None
        except KeyError:
            return None

    def _running_terminals(self) -> list[str]:
        from . import login as lg
        t, lst = self._running
        if time.monotonic() - t > 60:
            lst = lg.running_terminals()
            self._running = (time.monotonic(), lst)
        return lst

    def _initialize(self) -> None:
        """Attach to the terminal (mt5/login.py): configured path or the remembered detected one; optional explicit
        login (password only from the local secret store); after an authorization / IPC failure without a fixed path,
        every RUNNING terminal64.exe is tried (never starts another installation). A rejected login is not repeated
        until the login, server or password changes."""
        from . import login as lg
        cfg = self.cfg
        pw = self._password()
        ck = lg.credentials_key(cfg, pw)
        use_creds = bool(cfg.login and cfg.server) and self._rejected_creds != ck
        info = {"mode": "CONFIG_LOGIN" if use_creds else "TERMINAL_SESSION", "credentials_rejected": self._rejected_creds == ck and bool(cfg.login),
                "terminal_path": None, "running_terminals": self._running[1], "hint": None}

        def attempt(path: str | None, creds: bool):
            kw = lg.init_kwargs(cfg if creds else _NoLogin(cfg), pw if creds else None, path=path)
            ok = self._call(lambda m: m.initialize(**kw))
            return (True, None) if ok else (False, self._call(lambda m: m.last_error()))

        first_path = cfg.terminal_path or self._detected_path
        ok, err = False, None
        if use_creds:
            # attach to the running session first: re-sending login/password makes MT5 log the account in again, which drops
            # the trade-server connection on every reconnect. Credentials only if another (or no) account is logged in.
            ok, err = attempt(first_path, False)
            if ok:
                acc = self._call(lambda m: m.account_info())
                if acc is None or int(_row(acc).get("login") or 0) != int(cfg.login):
                    ok = False
        if not ok:
            ok, err = attempt(first_path, use_creds)
        if not ok and use_creds and lg.error_code(err) == lg.AUTH_FAILED:
            self._rejected_creds = ck                       # never hammer the broker with a wrong password
            self.log.write("WARNING", "MT5", "LOGIN_REJECTED", f"MT5: logowanie na rachunek {cfg.login} ({cfg.server}) odrzucone – "
                           "nie ponawiam z tymi danymi, dopóki nie zmienisz loginu, serwera lub hasła. Próba z sesją terminala.")
            info.update(mode="TERMINAL_SESSION", credentials_rejected=True)
            use_creds = False
            ok, err = attempt(first_path, False)
        if not ok and not cfg.terminal_path and lg.error_code(err) in (lg.AUTH_FAILED, *lg.IPC_CODES):
            running = self._running_terminals()
            info["running_terminals"] = running
            for p in running:
                if first_path and os.path.normcase(p) == os.path.normcase(first_path):
                    continue
                ok2, err2 = attempt(p, use_creds)
                if ok2:
                    ok, err = True, None
                    if self._detected_path != p:
                        self.log.write("INFO", "MT5", "TERMINAL_DETECTED", f"MT5: połączono z uruchomionym terminalem {p} (wykryty automatycznie).")
                    self._detected_path = p
                    break
                err = err2 if lg.error_code(err2) == lg.AUTH_FAILED else err
        if not ok:
            info["hint"] = lg.hint(err) or None
            if len(info["running_terminals"]) > 1:
                info["hint"] = (info["hint"] or "") + f" Uruchomione terminale: {len(info['running_terminals'])} – wskaż właściwy w Ustawienia → MT5."
            self.login_info = info
            raise BridgeError(f"MT5_INITIALIZE_FAILED:{err}" + (f" – {info['hint']}" if info["hint"] else ""))
        info["terminal_path"] = cfg.terminal_path or self._detected_path
        self.login_info = info

    def request_reconnect(self, reason: str | None = None) -> None:
        """A reconnect asked by the API (asset / MT5 settings changed, button): the same effect as the former direct write
        `state = "RECONNECTING"; next_retry = 0` (1.45 connection behaviour); 1.46 only adds the reason to the state, the log and the
        connection event."""
        self._set_state("RECONNECTING", reason or "RECONNECT_REQUESTED")
        self.next_retry = 0

    def connect(self) -> None:
        self._set_state("CONNECTING", None)
        self._initialize()
        from .fake import is_fake
        self._synthetic = bool(self._call(lambda m: is_fake(m)))
        term = self._call(lambda m: m.terminal_info())
        acct = self._call(lambda m: m.account_info())
        if term is None:
            raise BridgeError("TERMINAL_INFO_UNAVAILABLE")
        if acct is None:
            raise BridgeError("ACCOUNT_NOT_LOGGED_IN")
        terminal = _row(term)
        account = self._account_dict(_row(acct))
        new_key = f"{account['server']}:{account['login']}"
        prev_key, prev_path = self.account_key, (self.terminal or {}).get("path")
        with self._lock:
            self.terminal = {k: terminal.get(k) for k in ("name", "company", "path", "build", "connected", "trade_allowed", "tradeapi_disabled", "ping_last")}
            self.account = account
            self.account_key = new_key
            self.session_epoch += 1
        self._record_account(account)
        if prev_key is not None and (prev_key != new_key or prev_path != terminal.get("path")):
            self.log.warn("MT5", "ACCOUNT_OR_TERMINAL_CHANGED", f"Zmiana rachunku/terminala: {prev_key} -> {new_key}")
            self._notify("account_changed", {"previous": prev_key, "current": new_key})
        self.clock.reset()
        self._load_stored_offset(account["server"])
        self._check_symbol()
        self._load_all_history()
        self._load_dxy()
        self.connected_since = self.now()
        self._last_ok = time.monotonic()
        self.attempts = 0
        self._set_state("CONNECTED", None)
        self._notify("connected", {"account_key": new_key, "session_epoch": self.session_epoch})
        self.bus.publish("account", self.account_status())

    def _account_dict(self, a: dict) -> dict:
        return {"login": a.get("login"), "server": a.get("server"), "company": a.get("company"), "name": a.get("name"),
                "currency": a.get("currency"), "trade_mode": TRADE_MODE.get(a.get("trade_mode"), str(a.get("trade_mode"))),
                "margin_mode": MARGIN_MODE.get(a.get("margin_mode"), str(a.get("margin_mode"))),
                "leverage": a.get("leverage"), "balance": a.get("balance"), "equity": a.get("equity"),
                "margin": a.get("margin"), "free_margin": a.get("margin_free"), "margin_level": a.get("margin_level"),
                "profit": a.get("profit"), "trade_allowed": a.get("trade_allowed"), "trade_expert": a.get("trade_expert")}

    def _record_account(self, a: dict) -> None:
        now = iso(self.now())
        key = f"{a['server']}:{a['login']}"
        self.db.execute("""INSERT INTO accounts_seen(account_key, login, server, company, currency, trade_mode, margin_mode, first_seen, last_seen)
                           VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(account_key) DO UPDATE SET last_seen=excluded.last_seen,
                           currency=excluded.currency, trade_mode=excluded.trade_mode, margin_mode=excluded.margin_mode""",
                        (key, a["login"], a["server"], a.get("company"), a.get("currency"), a["trade_mode"], a.get("margin_mode"), now, now))

    def _load_stored_offset(self, server: str) -> None:
        row = self.db.one("SELECT offset_seconds, measured_at FROM clock_offsets WHERE server=?", (server,))
        if row:
            from ..timeutil import parse_iso
            self.clock.load_stored(row["offset_seconds"], parse_iso(row["measured_at"]))

    def _guard(self, symbol: str, path: str = "DATA") -> None:
        if self.assets is not None:
            self.assets.check_symbol(symbol, path)

    def _check_symbol(self) -> None:
        sym = self.cfg.symbol
        self._guard(sym)
        info = self._call(lambda m: m.symbol_info(sym))
        if info is None and self.assets is not None:
            got = self.assets.autodetect(self.cfg_store.get().assets.active)     # symbol enabled on the broker account
            if got:
                sym = got
                info = self._call(lambda m: m.symbol_info(sym))
        if info is None:
            # 1.46: candidates of the ACTIVE asset (BTC showed gold symbols); name hints of the asset registry
            hints = (getattr(self.assets, "NAME_HINTS", None) or {}).get(self.cfg_store.get().assets.active) if self.assets is not None else None
            group = ",".join(f"*{h}*" for h in hints) if hints else "*XAU*,*GOLD*"
            cands = self._call(lambda m: m.symbols_get(group=group)) or ()
            self.symbol_candidates = sorted({_row(c)["name"] for c in cands})[:30]
            self.symbol_status = "NOT_FOUND"
            self.symbol_info = None
            self.bus.publish("symbol", self.symbol_status_dict())
            raise BridgeError(f"SYMBOL_NOT_FOUND:{sym}:candidates={','.join(self.symbol_candidates) or 'none'}")
        info = _row(info)
        if not info.get("visible"):
            if not self._call(lambda m: m.symbol_select(sym, True)):
                self.symbol_status = "NOT_VISIBLE_SELECT_FAILED"
                raise BridgeError(f"SYMBOL_SELECT_FAILED:{sym}")
            info = _row(self._call(lambda m: m.symbol_info(sym)))
        if info.get("name") != sym:
            raise BridgeError(f"SYMBOL_NAME_MISMATCH:{info.get('name')}!={sym}")
        if self.assets is not None:
            try:
                self.assets.verify_main(sym, info)            # informational only
            except Exception:
                log.exception("asset metadata note failed")
        keep = ("name", "description", "path", "point", "digits", "trade_tick_size", "trade_tick_value", "trade_contract_size",
                "volume_min", "volume_max", "volume_step", "trade_stops_level", "trade_freeze_level", "trade_mode",
                "filling_mode", "currency_base", "currency_profit", "currency_margin", "spread", "spread_float")
        with self._lock:
            self.symbol_info = {k: info.get(k) for k in keep}
            tm = info.get("trade_mode")
            self.symbol_status = "OK" if tm == 4 else {0: "TRADE_DISABLED", 1: "LONG_ONLY", 2: "SHORT_ONLY", 3: "CLOSE_ONLY"}.get(tm, f"TRADE_MODE_{tm}")
        self.bus.publish("symbol", self.symbol_status_dict())

    # ---------------------------------------------------------------- history
    def _fetch(self, symbol: str, tf: str, count: int) -> list[Bar]:
        name = TF_CONST[tf]
        raw = self._call(lambda m: m.copy_rates_from_pos(symbol, getattr(m, name, None), 0, count) if getattr(m, name, None) is not None
                         else None, PRIO_HISTORY)
        if (raw is None or len(raw) == 0) and tf in RESAMPLE_FROM:
            return self._resample(symbol, tf, count)
        if raw is None:
            err = self._call(lambda m: m.last_error())
            raise BridgeError(f"COPY_RATES_FAILED:{tf}:{err}")
        out = []
        for r in raw:
            d = _row(r)
            out.append(Bar(int(d["time"]), float(d["open"]), float(d["high"]), float(d["low"]), float(d["close"]),
                           int(d.get("tick_volume") or 0), int(d.get("real_volume") or 0), int(d.get("spread") or 0)))
        out.sort(key=lambda b: b.t_raw)
        return out

    def _resample(self, symbol: str, tf: str, count: int) -> list[Bar]:
        """Build `tf` bars from closed+forming source bars when the terminal has no native series.

        Bucket = floor(raw server epoch / tf seconds): aligned with the broker's server day (as MT5's own H8),
        open = first source open, high = max, low = min, close = last close, tick volume = sum. The newest bucket
        stays FORMING (it is closed only when a later bucket is observed, the bridge's general rule). A bucket is
        marked with the number of source bars it contains (`parts`) - session breaks make fewer bars normal,
        so `parts` is evidence for the quality report, never padded."""
        src, per = RESAMPLE_FROM[tf]
        sec = TF_SECONDS[tf]
        base = self._fetch(symbol, src, min(5000, count * per + per * 2))
        out: list[Bar] = []
        for b in base:
            k = b.t_raw - (b.t_raw % sec)
            if out and out[-1].t_raw == k:
                x = out[-1]
                x.h, x.l, x.c, x.tv, x.rv = max(x.h, b.h), min(x.l, b.l), b.c, x.tv + b.tv, x.rv + b.rv
                x.parts = (x.parts or 0) + 1
            else:
                out.append(Bar(k, b.o, b.h, b.l, b.c, b.tv, b.rv, b.spread, source="resampled", parts=1))
        for x in out:
            x.complete = x.parts == per                 # M3 from M1: a triple with a missing minute is marked, never padded
        return out[-count:]

    def buffer_size(self, tf: str) -> int:
        return min(2000, max(self.cfg.chart_bars, self.required_bars.get(tf, 260) + 60))

    def _load_all_history(self) -> None:
        with self._lock:
            self.buffer_symbol = None             # buffers of the previous symbol are never served as the new one
        for tf in TIMEFRAMES:
            bars = self._fetch(self.cfg.symbol, tf, self.buffer_size(tf) + 1)
            for i in range(len(bars) - 1):
                bars[i].closed = True
                bars[i].available_raw_next_open = bars[i + 1].t_raw
                bars[i].basis = "HISTORICAL_ESTIMATE"
            with self._lock:
                st = self.tfs[tf]
                st.bars, st.loaded, st.last_poll, st.last_error = bars, True, time.monotonic(), None
            self.bus.publish("bars_reloaded", {"tf": tf, "count": len(bars)})
        with self._lock:
            self.buffer_symbol = self.cfg.symbol

    def _load_dxy(self) -> None:
        sym = self.cfg.dxy_symbol
        if not sym:
            self.dxy_status = "NOT_CONFIGURED"
            return
        try:
            if self._call(lambda m: m.symbol_info(sym)) is None or not self._call(lambda m: m.symbol_select(sym, True)):
                self.dxy_status = "SYMBOL_NOT_FOUND"
                return
            bars = self._fetch(sym, "H1", 300)
            for i in range(len(bars) - 1):
                bars[i].closed, bars[i].available_raw_next_open, bars[i].basis = True, bars[i + 1].t_raw, "HISTORICAL_ESTIMATE"
            with self._lock:
                self.dxy.bars, self.dxy.loaded = bars, True
            self.dxy_status = "OK"
        except (BridgeError, MT5CallTimeout) as exc:
            self.dxy_status = "ERROR:" + str(exc)[:80]

    # ---------------------------------------------------------------- other symbols (market scanner, AI signals; read-only)
    _META_KEYS = ("name", "description", "path", "point", "digits", "trade_mode", "currency_base", "currency_profit",
                  "trade_contract_size", "visible", "spread", "trade_calc_mode", "currency_margin")

    def list_symbols(self, visible_only: bool = True) -> list[dict]:
        """Symbols of the connected terminal. visible_only=True -> Market Watch only (no side effects)."""
        if self.state != "CONNECTED":
            raise BridgeError("NOT_CONNECTED")
        raw = self._call(lambda m: m.symbols_get(), PRIO_HISTORY) or ()
        out = []
        for r in raw:
            d = _row(r)
            if visible_only and not d.get("visible"):
                continue
            out.append({k: d.get(k) for k in self._META_KEYS})
        out.sort(key=lambda x: str(x.get("name")))
        return out

    def symbol_meta(self, symbol: str, select: bool = False, guard: bool = True) -> dict | None:
        if guard:
            self._guard(symbol)
        info = self._call(lambda m: m.symbol_info(symbol), PRIO_HISTORY)
        if info is None:
            return None
        d = _row(info)
        if select and not d.get("visible"):
            if not self._call(lambda m: m.symbol_select(symbol, True), PRIO_HISTORY):
                return None
            d = _row(self._call(lambda m: m.symbol_info(symbol), PRIO_HISTORY))
        return {k: d.get(k) for k in self._META_KEYS}

    def symbol_quote(self, symbol: str, point: float | None = None) -> dict | None:
        self._guard(symbol)
        tick = self._call(lambda m: m.symbol_info_tick(symbol), PRIO_HISTORY)
        if tick is None:
            return None
        t = _row(tick)
        bid, ask = float(t["bid"]), float(t["ask"])
        msc = int(t.get("time_msc") or int(t["time"]) * 1000)
        utc = self.clock.raw_to_utc(msc / 1000.0) if self.clock.offset is not None else None
        return {"symbol": symbol, "bid": bid, "ask": ask, "spread": round(ask - bid, 10),
                "spread_points": round((ask - bid) / point, 1) if point else None, "time_utc": iso(utc) if utc else None,
                "age_seconds": round((self.now() - utc).total_seconds(), 1) if utc else None, "source": "MT5"}

    def symbol_bars(self, symbol: str, tf: str, count: int) -> list[dict]:
        """Bars of any symbol (oldest first). The newest bar is 'forming' unless its period has already ended
        by the server clock; without a known server offset it is always treated as forming (conservative)."""
        self._guard(symbol)
        bars = self._fetch(symbol, tf, count)
        off = self.clock.offset
        raw_now = self.now().timestamp() + off if off is not None else None
        out = []
        for i, b in enumerate(bars):
            last = i == len(bars) - 1
            closed = not last or (raw_now is not None and b.t_raw + TF_SECONDS[tf] <= raw_now)
            out.append({"open_utc": iso(from_epoch(b.t_raw - off)) if off is not None else None, "t_raw": b.t_raw,
                        "o": b.o, "h": b.h, "l": b.l, "c": b.c, "tv": b.tv, "rv": b.rv, "spread": b.spread, "closed": closed})
        return out

    def ticks_range(self, symbol: str, from_utc: float, to_utc: float, max_count: int = 500_000) -> dict:
        """Bounded range read for the tick archive (PMW-UPD-08): same worker queue, ticks with from <= t <= to (UTC seconds)."""
        return self.ticks(symbol, max_count=max_count, from_utc=from_utc, to_utc=to_utc)

    def ticks(self, symbol: str, seconds: int = 3600, max_count: int = 200_000, from_utc: float | None = None, to_utc: float | None = None) -> dict:
        """Quote ticks of an allowed symbol (copy_ticks_from, COPY_TICKS_INFO = bid/ask changes). Times converted from
        server time to UTC with the measured offset; received_at = when this read returned. Without the offset -> no ticks."""
        self._guard(symbol, "DATA_TICKS")
        off = self.clock.offset
        if off is None:
            return {"status": "missing_data", "reason": "SERVER_OFFSET_UNKNOWN", "ticks": []}
        raw_from = (from_utc + off) if from_utc is not None else self.now().timestamp() + off - seconds

        def job(m):
            fn = getattr(m, "copy_ticks_from", None)
            if fn is None:
                return None
            return fn(symbol, raw_from, int(max_count), getattr(m, "COPY_TICKS_INFO", 1))
        arr = self._call(job, PRIO_HISTORY)
        recv = iso(self.now())
        if arr is None:
            return {"status": "unsupported", "reason": "COPY_TICKS_UNAVAILABLE", "ticks": []}
        # 1.46: the terminal returns at most max_count ticks from raw_from; a full answer that ends before to_utc (or a full "last N
        # seconds" answer) is cut - reported from the RAW answer, because dropped duplicates / invalid quotes made the length check miss it
        raw_count = len(arr)
        truncated = raw_count > 0 and raw_count >= int(max_count) and (to_utc is None or int(arr[raw_count - 1]["time_msc"]) / 1000.0 - off <= to_utc)
        out, last = [], None
        for r in arr:
            msc = int(r["time_msc"])
            key = (msc, float(r["bid"]), float(r["ask"]))
            if key == last:                                  # duplicate after re-read
                continue
            last = key
            if not (r["bid"] > 0 and r["ask"] > 0 and r["ask"] >= r["bid"]):
                continue                                     # invalid quote is dropped, never turned into 0
            if to_utc is not None and (msc / 1000.0) - off > to_utc:
                break
            out.append({"t": (msc / 1000.0) - off, "bid": float(r["bid"]), "ask": float(r["ask"]), "flags": int(r["flags"]),
                        "time_msc": msc, "t_ms": int(round(msc - off * 1000.0)), "ord": len(out)})   # raw source time kept (PMW-UPD-08)
        return {"status": "ok" if out else "missing_data", "symbol": symbol, "received_at_utc": recv, "count": len(out), "ticks": out,
                "raw_count": raw_count, "truncated": bool(truncated),
                "source": "SYNTHETIC" if self._synthetic else "MT5", "clock_transform": f"t_ms = time_msc - server_offset ({off} s)"}

    def _merge_tail(self, st: TFState, tf: str, tail: list[Bar], symbol: str) -> list[Bar]:
        """Merge the newest bars. Returns newly *closed* bars. Fills gaps by refetching."""
        if not tail:
            return []
        newly_closed: list[Bar] = []
        with self._lock:
            bars = st.bars
            last_known = bars[-1].t_raw if bars else None
        if last_known is not None and tail[0].t_raw > last_known:
            # More than len(tail) bars appeared since the previous poll -> gap fill from the terminal.
            need = min(2000, int((tail[-1].t_raw - last_known) / TF_SECONDS[tf]) + 5)
            tail = self._fetch(symbol, tf, need)
            st.gap_fills += 1
        observed = self.now()
        with self._lock:
            bars = st.bars
            index = {b.t_raw: i for i, b in enumerate(bars[-len(tail) - 5:], start=max(0, len(bars) - len(tail) - 5))}
            for nb in tail:
                i = index.get(nb.t_raw)
                if i is not None:
                    old = bars[i]
                    if old.closed:
                        if not old.same_values(nb):
                            old.o, old.h, old.l, old.c, old.tv = nb.o, nb.h, nb.l, nb.c, nb.tv
                            old.revision += 1
                            st.revisions += 1
                    else:
                        old.o, old.h, old.l, old.c, old.tv, old.rv, old.spread = nb.o, nb.h, nb.l, nb.c, nb.tv, nb.rv, nb.spread
                elif not bars or nb.t_raw > bars[-1].t_raw:
                    if bars and not bars[-1].closed:
                        prev = bars[-1]
                        prev.closed = True
                        prev.available_raw_next_open = nb.t_raw
                        prev.observed_close_utc = observed
                        prev.basis = "OBSERVED"
                        newly_closed.append(prev)
                    bars.append(nb)
            keep = self.buffer_size(tf) + 1
            if len(bars) > keep:
                del bars[: len(bars) - keep]
        return newly_closed

    # ---------------------------------------------------------------- polling
    def poll(self, mono: float) -> None:
        c = self.cfg
        if mono - self._t_hb >= c.heartbeat_seconds:
            self._t_hb = mono
            term = self._call(lambda m: m.terminal_info())
            if term is None:
                raise BridgeError("TERMINAL_INFO_NONE")
            t = _row(term)
            if t.get("path") != (self.terminal or {}).get("path"):
                raise BridgeError("TERMINAL_PATH_CHANGED")
            with self._lock:
                self.terminal.update({"connected": t.get("connected"), "trade_allowed": t.get("trade_allowed"),
                                      "tradeapi_disabled": t.get("tradeapi_disabled"), "ping_last": t.get("ping_last")})
            self.last_heartbeat = self.now()
            if t.get("connected"):
                self._last_ok = time.monotonic()              # liveness = a good heartbeat, not an idle loop
            if not t.get("connected"):
                self._error("TERMINAL_NOT_CONNECTED_TO_TRADE_SERVER")
        if mono - self._t_quote >= c.quote_poll_seconds:
            self._t_quote = mono
            self._poll_quote()
        for tf in TIMEFRAMES:
            st = self.tfs[tf]
            if mono - st.last_poll >= max(TF_POLL[tf], c.bars_poll_seconds if tf != "M1" else TF_POLL[tf]):
                st.last_poll = mono
                tail = self._fetch(c.symbol, tf, 3)
                closed = self._merge_tail(st, tf, tail, c.symbol)
                with self._lock:
                    current = self._bar_json(st.bars[-1], tf) if st.bars else None
                if closed:
                    for b in closed:
                        self.bus.publish("bar_closed", {"tf": tf, "bar": self._bar_json(b, tf)})
                    self._notify("bars_closed", {"tf": tf, "count": len(closed)})
                if current and (mono - self._last_bar_pub.get(tf, 0) >= 1.0 or closed):
                    self._last_bar_pub[tf] = mono
                    self.bus.publish("bar", {"tf": tf, "bar": current})
        if c.dxy_symbol and self.dxy.loaded and mono - self.dxy.last_poll >= 15:
            self.dxy.last_poll = mono
            closed = self._merge_tail(self.dxy, "H1", self._fetch(c.dxy_symbol, "H1", 3), c.dxy_symbol)
            if closed:
                self._notify("bars_closed", {"tf": "DXY_H1", "count": len(closed)})
        if mono - self._t_account >= c.account_poll_seconds:
            self._t_account = mono
            self._poll_account()
        if mono - self._t_hist >= c.history_poll_seconds:
            self._t_hist = mono
            self._poll_deals()

    def _poll_quote(self) -> None:
        sym = self.cfg.symbol
        tick = self._call(lambda m: m.symbol_info_tick(sym))
        received = self.now()
        if tick is None:
            raise BridgeError("TICK_UNAVAILABLE")
        t = _row(tick)
        msc = int(t.get("time_msc") or int(t["time"]) * 1000)
        prev_status = self.clock.evidence.status
        prev_offset = self.clock.evidence.offset_seconds
        is_new = self.quote is None or msc != self.quote.get("time_msc")
        ev = self.clock.observe_tick(msc, received) if is_new else self.clock.evidence
        if ev.status == "VERIFIED" and (prev_status != "VERIFIED" or prev_offset != ev.offset_seconds) and self.account:
            self.db.execute("""INSERT INTO clock_offsets(server, offset_seconds, measured_at, samples, residual_seconds) VALUES (?,?,?,?,?)
                               ON CONFLICT(server) DO UPDATE SET offset_seconds=excluded.offset_seconds, measured_at=excluded.measured_at,
                               samples=excluded.samples, residual_seconds=excluded.residual_seconds""",
                            (self.account["server"], ev.offset_seconds, iso(received), ev.samples, ev.residual_seconds or 0.0))
            self.bus.publish("clock", ev.as_dict())
        bid, ask = float(t["bid"]), float(t["ask"])
        point = (self.symbol_info or {}).get("point") or None
        last_new = received if is_new else (self.quote or {}).get("_last_new_received", received)
        q = {"symbol": sym, "bid": bid, "ask": ask, "spread": round(ask - bid, 10),
             "spread_points": round((ask - bid) / point, 1) if point else None,
             "time_raw": int(t["time"]), "time_msc": msc,
             "time_utc": iso(self.clock.raw_to_utc(msc / 1000.0)) if self.clock.offset is not None else None,
             "received_at": iso(received), "_last_new_received": last_new, "source": "MT5"}
        with self._lock:
            self.quote = q
        mono = time.monotonic()
        if mono - self._last_quote_pub >= 0.25:
            self._last_quote_pub = mono
            self.bus.publish("quote", self.quote_status())

    def _poll_account(self) -> None:
        acct = self._call(lambda m: m.account_info())
        if acct is None:
            raise BridgeError("ACCOUNT_INFO_NONE")
        a = self._account_dict(_row(acct))
        key = f"{a['server']}:{a['login']}"
        if key != self.account_key:
            prev = self.account_key
            with self._lock:
                self.account, self.account_key = a, key
                self.session_epoch += 1
            self._record_account(a)
            self.log.warn("MT5", "ACCOUNT_CHANGED", f"Zmieniono rachunek w terminalu: {prev} -> {key}. Decyzje wygaszone; wysyłka zleceń zablokowana do zgodności rachunku z trybem.")
            self.clock.reset()
            self._load_stored_offset(a["server"])
            self._load_all_history()
            self._notify("account_changed", {"previous": prev, "current": key})
        sym = self.cfg.symbol
        pos = self._call(lambda m: m.positions_get()) or ()
        ords = self._call(lambda m: m.orders_get()) or ()
        with self._lock:
            self.account = a
            self.positions = [self._pos_dict(_row(p)) for p in pos]
            self.orders = [{k: v for k, v in _row(o).items() if k in ("ticket", "time_setup", "type", "symbol", "volume_current", "price_open", "sl", "tp", "magic", "comment")} for o in ords]
        self.bus.publish("account", self.account_status())
        self.bus.publish("positions", {"positions": self.positions, "orders": self.orders, "symbol": sym})

    def _pos_dict(self, p: dict) -> dict:
        return {"ticket": p.get("ticket"), "symbol": p.get("symbol"), "side": "BUY" if p.get("type") == 0 else "SELL",
                "volume": p.get("volume"), "price_open": p.get("price_open"), "sl": p.get("sl") or None, "tp": p.get("tp") or None,
                "price_current": p.get("price_current"), "profit": p.get("profit"), "swap": p.get("swap"),
                "magic": p.get("magic"), "comment": p.get("comment"), "time_raw": p.get("time"), "identifier": p.get("identifier")}

    def _poll_deals(self) -> None:
        days = self.cfg.deals_history_days
        now_raw = self.now().timestamp() + (self.clock.offset or 0)
        frm = datetime.fromtimestamp(now_raw - days * 86400, UTC)
        to = datetime.fromtimestamp(now_raw + 86400, UTC)
        deals = self._call(lambda m: m.history_deals_get(frm, to), PRIO_HISTORY)
        if deals is None:
            self._error("HISTORY_DEALS_UNAVAILABLE")
            return
        out = []
        for d in deals:
            r = _row(d)
            out.append({k: r.get(k) for k in ("ticket", "order", "time", "type", "entry", "magic", "position_id", "volume",
                                              "price", "commission", "swap", "profit", "fee", "symbol", "comment", "reason")})
        with self._lock:
            self.deals = out
            self.deals_loaded_at = self.now()
        self._notify("deals", {"count": len(out)})

    # ---------------------------------------------------------------- read API
    def _bar_json(self, b: Bar, tf: str) -> dict:
        off = self.clock.offset
        open_utc = from_epoch(b.t_raw - off) if off is not None else None
        if b.closed:
            if b.basis == "OBSERVED" and b.observed_close_utc is not None:
                avail = b.observed_close_utc
            elif off is not None and b.available_raw_next_open is not None:
                avail = from_epoch(b.available_raw_next_open - off)
            else:
                avail = None
        else:
            avail = None
        return {"t_raw": b.t_raw, "open_utc": iso(open_utc), "o": b.o, "h": b.h, "l": b.l, "c": b.c, "tv": b.tv, "rv": b.rv,
                "spread": b.spread, "closed": b.closed,
                "close_confirmed_utc": iso(from_epoch(b.available_raw_next_open - off)) if (b.closed and off is not None and b.available_raw_next_open) else None,
                "available_at": iso(avail), "basis": b.basis, "revision": b.revision, "source": b.source,
                **({"parts": b.parts, "complete": b.complete} if b.parts is not None else {})}

    def bars(self, tf: str, limit: int | None = None, include_forming: bool = True) -> list[dict]:
        with self._lock:
            if tf != "DXY_H1" and self.buffer_symbol != self.cfg.symbol:
                return []                          # asset switch in progress: no bars of the old symbol under the new name
            src = self.dxy.bars if tf == "DXY_H1" else self.tfs[tf].bars
            seq = src if include_forming else [b for b in src if b.closed]
            if limit:
                seq = seq[-limit:]
            return [self._bar_json(b, "H1" if tf == "DXY_H1" else tf) for b in seq]

    def tf_meta(self) -> dict:
        with self._lock:
            return {tf: {"loaded": st.loaded, "bars": len(st.bars), "closed": sum(1 for b in st.bars if b.closed),
                         "revisions": st.revisions, "gap_fills": st.gap_fills, "buffer": self.buffer_size(tf),
                         "required": self.required_bars.get(tf)} for tf, st in self.tfs.items()}

    def quote_status(self) -> dict | None:
        with self._lock:
            if not self.quote:
                return None
            q = {k: v for k, v in self.quote.items() if not k.startswith("_")}
            last_new = self.quote.get("_last_new_received")
        now = self.now()
        q["age_seconds"] = round((now - last_new).total_seconds(), 3) if isinstance(last_new, datetime) else None
        if q.get("time_utc"):
            from ..timeutil import parse_iso
            q["source_age_seconds"] = round((now - parse_iso(q["time_utc"])).total_seconds(), 3)
        else:
            q["source_age_seconds"] = None
        return q

    def connection_status(self) -> dict:
        return {"state": self.state, "reason": self.state_reason, "session_epoch": self.session_epoch,
                "connected_since": iso(self.connected_since), "last_heartbeat": iso(self.last_heartbeat), "busy_waits": self.busy_waits,
                "terminal": self.terminal, "account_key": self.account_key, "synthetic": self._synthetic,
                "attempts": self.attempts, "module_error": self.worker.module_error,
                "worker_wedged_seconds": round(self.worker.wedged_seconds, 1), "errors": self.errors[-8:], "login": self.login_info,
                "clock": self.clock.evidence.as_dict()}

    def account_status(self) -> dict | None:
        with self._lock:
            return dict(self.account) if self.account else None

    def symbol_status_dict(self) -> dict:
        return {"symbol": self.cfg.symbol, "status": self.symbol_status, "info": self.symbol_info,
                "candidates": self.symbol_candidates, "dxy_symbol": self.cfg.dxy_symbol, "dxy_status": self.dxy_status}

    @property
    def synthetic(self) -> bool:
        return self._synthetic

    # ---------------------------------------------------------------- broker calculators
    def calc_profit(self, side: str, volume: float, price_open: float, price_close: float) -> float | None:
        sym = self.cfg.symbol
        return self._call(lambda m: m.order_calc_profit(m.ORDER_TYPE_BUY if side == "BUY" else m.ORDER_TYPE_SELL,
                                                         sym, volume, price_open, price_close))

    def calc_margin(self, side: str, volume: float, price: float) -> float | None:
        sym = self.cfg.symbol
        return self._call(lambda m: m.order_calc_margin(m.ORDER_TYPE_BUY if side == "BUY" else m.ORDER_TYPE_SELL, sym, volume, price))

    def calc_profit_sym(self, symbol: str, side: str, volume: float, price_open: float, price_close: float) -> float | None:
        """Broker profit calculator for ANY symbol (open positions / pending orders on other instruments)."""
        return self._call(lambda m: m.order_calc_profit(m.ORDER_TYPE_BUY if side == "BUY" else m.ORDER_TYPE_SELL, symbol, volume, price_open, price_close))

    def calc_margin_sym(self, symbol: str, side: str, volume: float, price: float) -> float | None:
        return self._call(lambda m: m.order_calc_margin(m.ORDER_TYPE_BUY if side == "BUY" else m.ORDER_TYPE_SELL, symbol, volume, price))

    def raw_call(self, fn, prio=PRIO_QUOTE, timeout: float | None = None) -> Any:
        return self.worker.call(fn, priority=prio, timeout=timeout or self.cfg.call_timeout_seconds)

    def server_day_start_utc(self) -> datetime | None:
        """Start of the current broker-server day, in UTC (daily-loss boundary)."""
        off = self.clock.offset
        if off is None:
            return None
        server_now = self.now() + timedelta(seconds=off)
        midnight = server_now.replace(hour=0, minute=0, second=0, microsecond=0)
        return midnight - timedelta(seconds=off)
