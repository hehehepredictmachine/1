"""Statistics from settled, stored events only - no demo numbers.

* bot statistics per mode (PAPER / AUTO_DEMO / AUTO_LIVE) from `trades` with status CLOSED only
  (one row per position; partial fills grouped; commission, swap, fee included). Positions with partial exits that are
  still open (OPEN_PARTIAL) and positions whose P/L could not be calculated (UNSETTLED) are counted separately and never
  enter winrate / PF / R;
* account statistics from MT5 deal history: trading result separated from balance operations
  (deposits/withdrawals are not strategy profit);
* equity curve from stored equity snapshots (labelled with the first snapshot date) - it is not
  reconstructed from closed P/L.
"""
from __future__ import annotations

from datetime import timedelta

from .timeutil import iso, parse_iso, utcnow


def _from_epoch(t):
    from datetime import datetime, timezone
    return datetime.fromtimestamp(float(t), timezone.utc) if t is not None else None

DEAL_TYPE_BALANCE = 2
# external flows for ROI: balance, credit, charge, correction, bonus (MT5 ENUM_DEAL_TYPE 2..6) - never trading profit
EXTERNAL_FLOW_TYPES = (2, 3, 4, 5, 6)


BE_BAND_R = 0.05          # |R| <= 0.05 after costs = breakeven (reported separately, not a win and not a loss)
DEFINITIONS = {
    "win_rate": "wygrane / (wygrane + przegrane), po kosztach (prowizja, swap, opłaty); breakeven osobno",
    "win_rate_all_closed": "wygrane / wszystkie zamknięte pozycje (z BE w mianowniku) - podawane obok, bez ukrywania zmiany mianownika",
    "closed_only": "tylko całkowicie zamknięte i rozliczone pozycje; częściowe wyjścia przy otwartej reszcie i pozycje nierozliczone są poza statystyką",
    "breakeven": "|wynik| <= 0,05 R po kosztach (bez R: wynik netto = 0)",
    "profit_factor": "suma zysków netto / |suma strat netto|; brak strat = brak wartości (nie nieskończoność)",
    "expectancy_r": "średni wynik netto w R (R = ryzyko planowane do SL przy otwarciu)",
    "roi": "ROI liczone metodą Dietza z uwzględnieniem wpłat/wypłat (roi_modified_dietz); wpłaty nie są zyskiem",
    "max_drawdown": "największy spadek krzywej zrealizowanego wyniku netto (kolejność zamknięć); max_drawdown_r to samo w R",
    "expectancy_r_se": "błąd standardowy średniego R – przy małej próbie przedział niepewności jest szeroki",
}


def _outcome(r: dict) -> str:
    rm = r.get("r_multiple")
    if rm is not None:
        return "BE" if abs(rm) <= BE_BAND_R else ("WIN" if rm > 0 else "LOSS")
    return "BE" if r["net_pnl"] == 0 else ("WIN" if r["net_pnl"] > 0 else "LOSS")


def _agg(rows: list[dict]) -> dict:
    n = len(rows)
    if n == 0:
        return {"trades": 0, "net": 0.0, "win_rate": None, "profit_factor": None, "avg_r": None, "expectancy_r": None, "status": "NO_DATA"}
    oc = [_outcome(r) for r in rows]
    wins, losses, be = oc.count("WIN"), oc.count("LOSS"), oc.count("BE")
    gp = sum(r["net_pnl"] for r in rows if r["net_pnl"] > 0)
    gl = -sum(r["net_pnl"] for r in rows if r["net_pnl"] < 0)
    rs = [r["r_multiple"] for r in rows if r.get("r_multiple") is not None]
    exp_r = round(sum(rs) / len(rs), 3) if rs else None
    eq = peak = dd = 0.0
    eq_r = peak_r = dd_r = 0.0
    for r in rows:                                     # rows are in closing order: drawdown of the realised result curve
        eq += r["net_pnl"]
        peak = max(peak, eq)
        dd = max(dd, peak - eq)
        if r.get("r_multiple") is not None:
            eq_r += r["r_multiple"]
            peak_r = max(peak_r, eq_r)
            dd_r = max(dd_r, peak_r - eq_r)
    win_v = [r["net_pnl"] for r in rows if _outcome(r) == "WIN"]
    loss_v = [r["net_pnl"] for r in rows if _outcome(r) == "LOSS"]
    sd_r = (sum((x - exp_r) ** 2 for x in rs) / (len(rs) - 1)) ** 0.5 if exp_r is not None and len(rs) > 1 else None
    return {"trades": n, "wins": wins, "losses": losses, "breakeven": be, "net": round(sum(r["net_pnl"] for r in rows), 2),
            "avg_win": round(sum(win_v) / len(win_v), 2) if win_v else None, "avg_loss": round(sum(loss_v) / len(loss_v), 2) if loss_v else None,
            "max_drawdown": round(dd, 2), "max_drawdown_r": round(dd_r, 3) if rs else None,
            "expectancy_r_se": round(sd_r / len(rs) ** 0.5, 3) if sd_r is not None else None,
            "win_rate": round(wins / (wins + losses) * 100, 1) if (wins + losses) else None,
            "win_rate_all_closed": round(wins / n * 100, 1),
            "profit_factor": round(gp / gl, 2) if gl > 0 else None, "profit_factor_note": None if gl > 0 else "BRAK_STRAT",
            "gross_profit": round(gp, 2), "gross_loss": round(gl, 2),
            "commission": round(sum(r["commission"] for r in rows), 2), "swap": round(sum(r["swap"] for r in rows), 2),
            "avg_r": exp_r, "expectancy_r": exp_r, "status": "OK" if n >= 30 else "SMALL_SAMPLE", "definitions": DEFINITIONS}


def roi_modified_dietz(start_equity: float, end_equity: float, flows: list[tuple[float, float]]) -> float | None:
    """Return over a period with external cash flows (deposits +, withdrawals -). flows = [(amount, weight)] where weight
    = fraction of the period REMAINING after the flow (0..1). ROI = (E1 - E0 - sum F) / (E0 + sum w*F). Deposits are
    therefore never counted as profit."""
    f = sum(a for a, _ in flows)
    denom = start_equity + sum(a * w for a, w in flows)
    if denom <= 0:
        return None
    return round(100 * (end_equity - start_equity - f) / denom, 3)


def bot_stats(db, mode: str, account_key: str | None = None) -> dict:
    q = "SELECT * FROM trades WHERE mode=? AND source IN ('BOT','ADOPTED')"
    args: list = [mode]
    if mode != "PAPER" and account_key:
        q += " AND account_key=?"
        args.append(account_key)
    open_partial = db.query(q.replace("SELECT *", "SELECT COUNT(*) AS n") + " AND status='OPEN_PARTIAL'", args)[0]["n"]
    unsettled = db.query(q.replace("SELECT *", "SELECT COUNT(*) AS n") + " AND status='UNSETTLED'", args)[0]["n"]
    rows = db.query(q + " AND status='CLOSED' ORDER BY closed_at", args)
    comm_unknown = sum(1 for r in rows if '"commission_unknown":true' in (r.get("deals_json") or "").replace(" ", ""))
    now = utcnow()
    day0 = now.replace(hour=0, minute=0, second=0, microsecond=0)
    week0 = day0 - timedelta(days=day0.weekday())
    month0 = day0.replace(day=1)

    def since(t):
        return [r for r in rows if parse_iso(r["closed_at"]) >= t]
    cur = rows[-1]["currency"] if rows else None
    return {"mode": mode, "currency": cur, "all": _agg(rows), "day": _agg(since(day0)), "week": _agg(since(week0)),
            "month": _agg(since(month0)), "recent": rows[-20:][::-1],
            "open_partial_positions": open_partial, "unsettled_positions": unsettled, "commission_unknown_trades": comm_unknown,
            "note": "Wyniki z rozliczonych transakcji bota w tym trybie. Mała próba nie pozwala wnioskować o skuteczności."}


def engine_stats(db, mode: str, account_key: str | None = None) -> dict:
    """Per execution path and combined (AR-04): S01-S12 from `trades` (as bot_stats), SCALPING / HEDGING from closed `sh_plans`
    (one plan = one result for the whole cycle incl. the hedge leg; spread/slippage inside the fill prices; commission when known;
    swap is not tracked by SH). Reporting only - no limit or decision reads this."""
    q = "SELECT * FROM trades WHERE mode=? AND source IN ('BOT','ADOPTED') AND status='CLOSED'"
    args: list = [mode]
    if mode != "PAPER" and account_key:
        q += " AND account_key=?"
        args.append(account_key)
    legacy = db.query(q + " ORDER BY closed_at", args)
    sq = "SELECT strategy, symbol, state, result, closed_at FROM sh_plans WHERE exec_mode=? AND state IN ('CLOSED','ERROR_CLOSED')"
    sargs: list = [mode]
    if mode != "PAPER" and account_key:
        sq += " AND account_key=?"
        sargs.append(account_key)
    import json
    sh: dict[str, list[dict]] = {"SCALPING": [], "HEDGING": []}
    unsettled, comm_unknown = 0, 0
    for r in db.query(sq + " ORDER BY closed_at", sargs):
        res = json.loads(r["result"]) if r.get("result") else {}
        if r["state"] != "CLOSED" or res.get("net_money") is None:
            unsettled += 1
            continue
        comm_unknown += 0 if res.get("commission_known") else 1
        sh.setdefault(r["strategy"], []).append({"net_pnl": float(res["net_money"]), "r_multiple": res.get("r_multiple"),
                                                  "commission": float(res.get("commission_money") or 0.0), "swap": 0.0,
                                                  "strategy_id": r["strategy"], "symbol": r.get("symbol"), "closed_at": iso(_from_epoch(r["closed_at"]))})
    per = {"ACTIVE_S01_S12": _agg(legacy), **{"SH_" + k: _agg(v) for k, v in sh.items()}}
    allr = sorted(legacy + [x for v in sh.values() for x in v], key=lambda r: str(r.get("closed_at") or ""))
    by_strategy: dict[str, list] = {}
    by_month: dict[str, list] = {}
    by_symbol: dict[str, list] = {}
    for r in allr:
        by_strategy.setdefault(str(r.get("strategy_id") or "?"), []).append(r)
        by_symbol.setdefault(str(r.get("symbol") or "?"), []).append(r)
        by_month.setdefault(str(r.get("closed_at") or "")[:7] or "?", []).append(r)
    return {"mode": mode, "per_engine": per, "combined": _agg(allr),
            "per_strategy": {k: _agg(v) for k, v in sorted(by_strategy.items())},
            "per_symbol": {k: _agg(v) for k, v in sorted(by_symbol.items())},
            "per_month": {k: {x: _agg(v)[x] for x in ("trades", "net", "expectancy_r", "win_rate", "max_drawdown")} for k, v in sorted(by_month.items())},
            "sh_unsettled_or_error_closed": unsettled, "sh_commission_unknown_plans": comm_unknown,
            "note": "S01–S12 z tabeli trades, SCALPING/HEDGING z zamkniętych planów sh_plans (cały cykl = jeden wynik). "
                    "Mała próba nie pozwala wnioskować o skuteczności."}


def equity_curve(db, mode: str, account_key: str | None, days: int = 30) -> dict:
    frm = iso(utcnow() - timedelta(days=days))
    if mode == "PAPER":
        rows = db.query("SELECT ts, balance, equity FROM equity_snapshots WHERE mode='PAPER' AND ts>=? ORDER BY ts", (frm,))
    else:
        rows = db.query("SELECT ts, balance, equity FROM equity_snapshots WHERE mode='ACCOUNT' AND account_key=? AND ts>=? ORDER BY ts", (account_key, frm))
    if len(rows) > 600:
        step = len(rows) // 600 + 1
        rows = rows[::step] + [rows[-1]]
    first = db.one("SELECT MIN(ts) AS t FROM equity_snapshots WHERE mode=?" + ("" if mode == "PAPER" else " AND account_key=?"),
                   ("PAPER",) if mode == "PAPER" else ("ACCOUNT", account_key))
    return {"mode": mode, "points": rows, "first_snapshot": (first or {}).get("t"),
            "label": "Equity z zapisanych snapshotów (co 60 s, od " + str((first or {}).get("t") or "—") + ")",
            "status": "OK" if len(rows) >= 2 else "NO_DATA"}


def account_stats(deals: list[dict], symbol: str, day_start_raw: float | None) -> dict:
    trading = [d for d in deals if d.get("type") in (0, 1)]
    balance_ops = [d for d in deals if d.get("type") == DEAL_TYPE_BALANCE]
    other_flows = [d for d in deals if d.get("type") in EXTERNAL_FLOW_TYPES and d.get("type") != DEAL_TYPE_BALANCE]

    def net(ds):
        return round(sum(float(d.get("profit") or 0) + float(d.get("commission") or 0) + float(d.get("swap") or 0) + float(d.get("fee") or 0) for d in ds), 2)
    today = [d for d in trading if day_start_raw is not None and d.get("time", 0) >= day_start_raw]
    return {"trading_net_all_symbols": net(trading), "trading_net_symbol": net([d for d in trading if d.get("symbol") == symbol]),
            "trading_net_today": net(today) if day_start_raw is not None else None,
            "balance_operations": round(sum(float(d.get("profit") or 0) for d in balance_ops), 2),
            "deposits": round(sum(float(d.get("profit") or 0) for d in balance_ops if float(d.get("profit") or 0) > 0), 2),
            "withdrawals": round(sum(float(d.get("profit") or 0) for d in balance_ops if float(d.get("profit") or 0) < 0), 2),
            "balance_operations_count": len(balance_ops), "deals": len(trading),
            "credit_bonus_other_flows": round(sum(float(d.get("profit") or 0) for d in other_flows), 2),
            "note": "Wpłaty/wypłaty (operacje balance) są wykazane osobno i nie są zyskiem strategii."}


def account_roi(db, account_key: str | None, deals: list[dict], server_offset: float | None, days: int = 30) -> dict:
    """ROI of the MT5 account over the stored equity history (equity snapshots every 60 s while the program runs),
    modified Dietz: deposits / withdrawals (balance deals) are external flows, never profit. Without at least two
    snapshots, or without the server time offset (deal times are server time), there is no ROI - never a guess."""
    if not account_key:
        return {"status": "NO_ACCOUNT"}
    frm = iso(utcnow() - timedelta(days=days))
    rows = db.query("SELECT ts, equity FROM equity_snapshots WHERE mode='ACCOUNT' AND account_key=? AND ts>=? ORDER BY ts", (account_key, frm))
    if len(rows) < 2:
        return {"status": "NO_DATA", "note": "za mało zapisanych snapshotów equity (zapis co 60 s podczas pracy programu)"}
    if server_offset is None:
        return {"status": "NO_DATA", "note": "nieznany offset czasu serwera – nie można przypisać wpłat/wypłat do okresu"}
    t0, t1 = parse_iso(rows[0]["ts"]).timestamp(), parse_iso(rows[-1]["ts"]).timestamp()
    span = max(1.0, t1 - t0)
    flows = []
    for d in deals:
        if d.get("type") not in EXTERNAL_FLOW_TYPES:
            continue
        t = float(d.get("time") or 0) - server_offset
        if t0 < t <= t1:
            flows.append((float(d.get("profit") or 0), (t1 - t) / span))
    e0, e1 = float(rows[0]["equity"]), float(rows[-1]["equity"])
    roi = roi_modified_dietz(e0, e1, flows)
    return {"status": "OK" if roi is not None else "NO_DATA", "roi_pct": roi, "period_from": rows[0]["ts"], "period_to": rows[-1]["ts"],
            "start_equity": round(e0, 2), "end_equity": round(e1, 2), "net_flows": round(sum(a for a, _ in flows), 2), "flows_count": len(flows),
            "method": "modified Dietz – wpłaty/wypłaty, credit/bonus i korekty jako przepływy zewnętrzne, nie zysk", "snapshots": len(rows),
            "scope": "cały rachunek (także transakcje ręczne) – to nie jest ROI samego bota",
            "sampling_note": "equity próbkowane co 60 s podczas pracy programu – głębsze obsunięcia wewnątrz minuty i poza pracą programu nie są widoczne"}
